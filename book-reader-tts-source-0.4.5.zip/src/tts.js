import {t} from './i18n.js';
import { mountReaderPopover } from './reader-popover.js';
import { mountVoiceManager } from "./voice-manager.js";
import { detectSpeechLanguage, chooseSpeechVoice, voiceFamily } from "./speech-voices.js";
// Independent speech controller: no book markup or annotation files are changed.
export function splitSpeech(text, limit = 220) {
  const sentences = String(text).trim().match(/[^。！？.!?\n]+[。！？.!?\n]*|[。！？.!?]+/gu) || [];
  return sentences.flatMap(sentence => {
    const chars = Array.from(sentence.trim());
    const parts = [];
    while (chars.length) parts.push(chars.splice(0, limit).join(''));
    return parts.filter(Boolean);
  });
}

export class SpeechQueue {
  constructor(synth, Utterance, update = () => {}) {
    this.synth = synth; this.Utterance = Utterance; this.update = update;
    this.generation = 0; this.state = 'idle'; this.items = []; this.index = 0;
    this.rate = 1; this.voice = null; this.language = "";
  }
  start(items, index = 0) {
    this.stop(); this.items = items; this.index = Math.max(0, Math.min(index, items.length - 1));
    if (!items.length) return;
    this.state = 'playing'; this.speak();
  }
  speak() {
    if (this.state !== 'playing') return;
    if (this.index >= this.items.length) { this.state = 'finished'; this.update(this); return; }
    const generation = this.generation;
    const utterance = new this.Utterance(this.items[this.index].text);
    utterance.rate = Math.max(0.5, Math.min(3, Number(this.rate) || 1));
    const resolved=this.resolveVoice?.(utterance.text);
    const language=resolved?.language || this.language;
    const voice=resolved ? resolved.voice : this.voice;
    if (language && language!=='auto') utterance.lang = language;
    if (voice) { utterance.voice = voice; utterance.lang = voice.lang; }
    utterance.onend = () => {
      if (generation !== this.generation || this.state !== 'playing') return;
      this.index++; this.speak();
    };
    utterance.onerror = event => {
      if (generation !== this.generation) return;
      this.error = event.error || 'speech-error'; this.state = 'error'; this.update(this);
    };
    this.utterance = utterance; // Keep a strong reference on mobile.
    this.update(this);
    try { this.synth.speak(utterance); }
    catch (e) { this.error = e.message; this.state = 'error'; this.update(this); }
  }
  pause() {
    if (this.state !== 'playing') return;
    this.generation++; this.state = 'paused'; this.synth.cancel(); this.update(this);
  }
  resume() { if (this.state === 'paused') { this.state = 'playing'; this.speak(); } }
  seek(index) {
    if (!this.items.length) return;
    this.generation++; this.synth.cancel();
    this.index = Math.max(0, Math.min(index, this.items.length - 1));
    this.state = 'playing'; this.speak();
  }
  stop() {
    const owned = this.state === 'playing' || this.state === 'paused';
    this.generation++; this.state = 'idle'; if (owned) this.synth.cancel(); this.utterance = null; this.update(this);
  }
}

let activeReader = null;
export function mountSpeech(view, root, top) {
  view._tts?.dispose();
  const doc = root.ownerDocument, win = doc.defaultView;
  const synth = win.speechSynthesis;
  const row = doc.createElement('div'); row.className = 'brtts-controls';
  top.after(row);
  const button = (label, run) => {
    const el = doc.createElement('button'); el.type = 'button'; el.textContent = label;
    el.addEventListener('click', run); row.append(el); return el;
  };
  const status = doc.createElement('span'); status.className = 'brtts-status'; status.setAttribute('role', 'status');
  let marked = null, disposed = false, follow = true, deadline = 0, sleepTimer = null;
  const storageKey = () => `book-reader-tts:${view.app.vault.getName()}:${view.file?.path}`;
  const prefsKey = `book-reader-tts-preferences:${view.app.vault.getName()}`;
  const readPrefs = () => { try { return JSON.parse(win.localStorage.getItem(prefsKey) || '{}'); } catch { return {}; } };
  const readSaved = () => { const shared=view.plugin.settings?.readerSyncPreferences&&view.plugin.settings.sharedSpeechRate?{rate:view.plugin.settings.sharedSpeechRate}:{};try { return {...readPrefs(),...JSON.parse(win.localStorage.getItem(storageKey()) || '{}'),...shared}; } catch { return {...readPrefs(),...shared}; } };
  const savePrefs = patch => { try { win.localStorage.setItem(prefsKey,JSON.stringify({...readPrefs(),...patch})); } catch {} };
  const save = state => { try { win.localStorage.setItem(storageKey(), JSON.stringify(state)); } catch { /* unavailable storage */ } };
  const clearMark = () => { marked?.classList.remove('brtts-speaking'); marked = null; };
  const reveal = () => {
    const item = queue?.items[queue.index]; if (!item) return;
    const [cur,total] = view.pager.jumpTo(view.pager.spreadForBlock(item.block));
    (view.updateUI || view._updateUI)?.call(view,cur,total);
  };
  const cancelSleep = () => { if (sleepTimer) win.clearTimeout(sleepTimer); sleepTimer = null; deadline = 0; };
  const update = q => {
    if (disposed) return;
    const labels = {idle:t("Ready"), playing:t("Reading aloud"), paused:t("Paused (resumes from current phrase)"), finished:t("Reading complete"), error:t("Speech error: {0}",q.error)};
    status.textContent = labels[q.state];
    playButton.textContent = q.state === 'playing' ? t("Ⅱ Pause") : q.state === 'paused' ? t("▶ Continue") : t("▶ Resume");
    playButton.setAttribute('aria-label', q.state === 'playing' ? t("Pause speech") : t("Resume speech"));
    row.dataset.state = q.state;
    if (q.state === 'finished') { cancelSleep(); sleepSelect.value = '0'; }
    if (q.state === 'idle' || q.state === 'finished' || q.state === 'error') clearMark();
    const item = q.items[q.index];
    if (q.state === 'playing' && item) {
      clearMark(); marked = view.pager.blockEl(item.block); if (highlightSelect.value !== 'none') marked?.classList.add('brtts-speaking');
      if (follow) reveal();
      save({...readSaved(), block:item.block, chunk:item.chunk, text:item.text, finished:false, rate:q.rate, voice:voiceSelect.value});
    }
    const total = view.pager._blocks().length;
    progress.textContent = item ? t("Paragraph {0} / {1}",item.block + 1,total) : q.state === 'finished' ? t("Finished listening") : '';
    if (deadline) progress.textContent += t(" · Pauses in {0} min",Math.max(1,Math.ceil((deadline-Date.now())/60000)));
    if (q.state === 'finished') save({...readSaved(),finished:true, rate:q.rate, voice:voiceSelect.value});
  };
  const queue = synth && win.SpeechSynthesisUtterance ? new SpeechQueue(synth, win.SpeechSynthesisUtterance, update) : null;
  const start = resume => {
    if (!queue) return;
    preview?.stop();
    if (view.ext !== 'epub') { row.dataset.state='error'; status.textContent = t("This preview supports EPUB speech only"); return; }
    const blocks = Array.from(view.pager._blocks());
    if (!blocks.length) { row.dataset.state='error'; status.textContent = t("Book text has not loaded"); return; }
    let block = view.pager.currentBlockIndex();
    const selected = doc.getSelection()?.anchorNode;
    const el = selected?.nodeType === 1 ? selected : selected?.parentElement;
    const selectedBlock = el?.closest('p,h1,h2,h3,h4');
    if (!resume && selectedBlock && blocks.includes(selectedBlock)) block = blocks.indexOf(selectedBlock);
    const saved = readSaved();
    if (resume && Number.isInteger(saved.block) && !saved.finished) block = saved.block;
    block = Math.max(0, Math.min(block, blocks.length - 1));
    const items = blocks.flatMap((el, idx) => splitSpeech(el.textContent).map((text, chunk) => ({text, block:idx, chunk})));
    let index = Math.max(0,items.findIndex(i=>i.block >= block));
    if (resume) { const found = items.findIndex(i => i.block === saved.block && i.chunk === saved.chunk && i.text === saved.text); if (found >= 0) index = found; }
    if (activeReader && activeReader !== queue) activeReader.stop();
    activeReader = queue;
    queue.rate = Number(rateSelect.value);
    queue.language = languageSelect.value;
    refreshVoices();
    queue.start(items, index);
  };
  button(t("Listen from here"), () => start(false)).title = t("Start from the current page or selected paragraph");
  const playButton = button(t("▶ Resume"), () => { preview?.stop();if (queue?.state === 'playing') queue.pause(); else if (queue?.state === 'paused') queue.resume(); else start(true); });
  playButton.className = 'brtts-primary';
  const skip = direction => {
    preview?.stop();
    if (!queue?.items.length) { start(false); if (!queue?.items.length) return; }
    const current = queue.items[Math.min(queue.index,queue.items.length-1)].block;
    let idx = direction > 0 ? queue.items.findIndex(i=>i.block>current) : -1;
    if (direction < 0) { const prev = [...queue.items].reverse().find(i=>i.block<current); idx=prev ? queue.items.findIndex(i=>i.block===prev.block) : 0; }
    if (idx>=0) queue.seek(idx);
  };
  const prevButton=button(t("Previous paragraph"), () => skip(-1));prevButton.className='brtts-skip';
  const nextButton=button(t("Next paragraph"), () => skip(1));nextButton.className='brtts-skip';
  button(t("Stop"), () => { preview?.stop();cancelSleep(); sleepSelect.value='0'; queue?.stop(); });
  const progress = doc.createElement('span'); progress.className='brtts-progress'; row.append(progress);
  const options = doc.createElement('details'); options.className='brtts-options';
  const summary = doc.createElement('summary'); summary.textContent=t("Voice and reading"); options.append(summary);
  const settings = doc.createElement('div'); settings.className='brtts-settings'; options.append(settings); row.append(options);
  const rateSelect = doc.createElement('select'); rateSelect.setAttribute('aria-label', t("Speech speed"));
  for (const rate of [...new Set([...Array.from({length:26},(_,i)=>Number((0.5+i*0.1).toFixed(1))),0.85,1.15,1.75])].sort((a,b)=>a-b)) { const option = doc.createElement('option'); option.value = String(rate); option.textContent = `${rate}×`; rateSelect.append(option); }
  const field = (label,control) => { const wrapper=doc.createElement('label'); wrapper.textContent=label; wrapper.append(control); settings.append(wrapper); };
  rateSelect.value = '1'; field(t("Speed"),rateSelect);
  const voiceSelect = doc.createElement('select'); voiceSelect.setAttribute('aria-label', t("Reading voice")); field(t("Voice"),voiceSelect);
  const languageSelect=doc.createElement('select');languageSelect.setAttribute('aria-label',t("Voice language"));field(t("Speech language"),languageSelect);
  const voiceHint=doc.createElement('small');voiceHint.className='brtts-voice-hint';settings.append(voiceHint);
  const sleepSelect=doc.createElement('select'); sleepSelect.setAttribute('aria-label',t("Sleep timer"));
  for (const minutes of [0,5,15,30,60]) { const o=doc.createElement('option');o.value=String(minutes);o.textContent=minutes ? t("{0} min",minutes) : t("No timer");sleepSelect.append(o); }
  field(t("Sleep timer"),sleepSelect);
  sleepSelect.addEventListener('change',()=>{cancelSleep();const mins=Number(sleepSelect.value);if(mins){deadline=Date.now()+mins*60000;sleepTimer=win.setTimeout(()=>{deadline=0;sleepTimer=null;queue?.pause();sleepSelect.value='0';status.textContent=t("Sleep timer reached; press Continue to resume");},mins*60000);}if(queue)update(queue);});
  const followBox=doc.createElement('input');followBox.type='checkbox';followBox.checked=true;field(t("Follow speech"),followBox);
  followBox.addEventListener('change',()=>{follow=followBox.checked;save({...readSaved(),follow});savePrefs({follow});if(follow)reveal();});
  const highlightSelect=doc.createElement('select');highlightSelect.setAttribute('aria-label',t("Speech highlight"));
  for(const [value,label] of [['soft',t("Soft background")],['line',t("Underline")],['none',t("No highlight")]]){const o=doc.createElement('option');o.value=value;o.textContent=label;highlightSelect.append(o);}
  field(t("Speech highlight"),highlightSelect);
  const applyHighlight=()=>{root.dataset.ttsHighlight=highlightSelect.value;if(highlightSelect.value==='none')clearMark();};
  highlightSelect.value=readPrefs().highlight || 'soft';applyHighlight();
  highlightSelect.addEventListener('change',()=>{savePrefs({highlight:highlightSelect.value});applyHighlight();});
  const returnButton=button(t("Return to speech"),reveal);settings.append(returnButton);
  const contentsButton=button(t("Contents"),()=> (view.togglePanel || view._togglePanel)?.call(view,'toc'));settings.append(contentsButton);
  const displayButton=button(t("Font and layout"),()=> (view.togglePanel || view._togglePanel)?.call(view,'settings'));settings.append(displayButton);
  const hint=doc.createElement('small');hint.textContent=t("Disable follow to browse freely. Voice and speed changes apply to the next phrase.");settings.append(hint);
  const languageNames = {'zh-CN':t("Chinese (Mandarin)"),'zh-TW':t("Chinese (Taiwan)"),'zh-HK':t("Chinese (Hong Kong)"),'en-US':t("English (US)"),'en-GB':t("English (UK)"),'ja-JP':t("Japanese"),'auto':t("Auto-detect Chinese / English / Japanese")};
  const normalizeLang = lang => String(lang||'').replaceAll('_','-').toLowerCase();
  const refreshVoices = (restore = false) => {
    const saved=readSaved();
    const selected = restore ? saved.voice || '' : voiceSelect.value || saved.voice || '';
    const voices = (synth?.getVoices() || []).filter(v=>['zh','en','ja'].includes(voiceFamily(v.lang)));
    const language = restore ? saved.language ?? 'auto' : languageSelect.value ?? saved.language ?? ''; 
    languageSelect.replaceChildren();
    for(const lang of ['',...new Set([...Object.keys(languageNames),...voices.map(v=>v.lang)])]){const o=doc.createElement('option');o.value=lang;o.textContent=lang ? (languageNames[lang] || lang) : t("System language");languageSelect.append(o);}
    languageSelect.value=language;
    const matches=voices.filter(v=>!language || language==='auto' || normalizeLang(v.lang)===normalizeLang(language));
    voiceSelect.replaceChildren();
    const defaultOption = doc.createElement('option'); defaultOption.value = ''; defaultOption.textContent = language==='auto' ? t("Match voice to text") : language ? t("Choose an available voice") : t("System voice"); voiceSelect.append(defaultOption);
    for (const voice of matches) { const option = doc.createElement('option'); option.value = voice.voiceURI; option.textContent = `${voice.name} · ${voice.lang}${voice.localService ? t(" · Local") : t(" · Online")}`; voiceSelect.append(option); }
    if (matches.some(v=>v.voiceURI===selected)) voiceSelect.value=selected;
    if(queue){
      queue.language=language;
      queue.voice=matches.find(v=>v.voiceURI===voiceSelect.value) || (language && language!=='auto' ? chooseSpeechVoice(voices,language) : null);
      queue.resolveVoice=language==='auto' ? text=>{
        const context=Array.from(view.pager._blocks()).slice(0,60).map(el=>el.textContent).join(' ');
        const detected=detectSpeechLanguage(text,detectSpeechLanguage(context));
        const remembered=readPrefs().voicesByLanguage || {};
        const voice=chooseSpeechVoice(synth.getVoices(),detected,remembered[voiceFamily(detected)] || voiceSelect.value);
        return {language:detected,voice};
      } : null;
    }
    voiceHint.textContent = language && language!=='auto' && !matches.length ? t("No voice for this language was found. System playback may be unavailable; install a matching voice and try again.") : !voices.length ? t("No voices found yet. Wait for the system to load them and refresh.") : selected && !voices.some(v=>v.voiceURI===selected) ? t("The previous voice is unavailable on this device; using the system default.") : t("Chinese {0} · English {1} · Japanese {2} voices. Detection uses text rules; Japanese without kana may need manual selection. Install system voices for missing languages.",voices.filter(v=>voiceFamily(v.lang)==='zh').length,voices.filter(v=>voiceFamily(v.lang)==='en').length,voices.filter(v=>voiceFamily(v.lang)==='ja').length);
    summary.textContent=t("Voice · {0}×",rateSelect.value || 1);summary.title=languageNames[language] || language || t("System default");
  };
  languageSelect.addEventListener('change',()=>{
    // Explicitly persist an empty selection too, so returning to system defaults works.
    save({...readSaved(),language:languageSelect.value,voice:''});savePrefs({language:languageSelect.value,voice:''});voiceSelect.value='';refreshVoices(true);
  });
  const audition = button(t("Preview voice"),()=>{
    if(!queue)return;if(activeReader && activeReader!==queue)activeReader.stop();activeReader=queue;
    queue.pause();
    refreshVoices();
    const voice=queue.voice || queue.resolveVoice?.('你好，这是声音试听。').voice;
    queue.voice=voice||null;queue.rate=Number(rateSelect.value);
    // A separate controller avoids replacing the book's saved queue and location.
    preview.stop();preview.voice=voice||null;preview.language=languageSelect.value;preview.rate=queue.rate;
    const lang=(voice?.lang || languageSelect.value || 'zh').split('-')[0];
    const samples={zh:'你好，这是你选择的朗读声音。愿阅读成为轻松的日常。',en:'Hello. This is a preview of your selected reading voice.',ja:'こんにちは。選択した音声の読み上げテストです。',ko:'안녕하세요. 선택한 음성을 미리 들어보세요.',fr:'Bonjour. Voici un aperçu de la voix sélectionnée.',de:'Hallo. Dies ist eine Vorschau der ausgewählten Stimme.',es:'Hola. Esta es una muestra de la voz seleccionada.'};
    preview.start([{text:samples[lang] || samples.en}]);
  });settings.append(audition);
  const preview = queue ? new SpeechQueue(synth,win.SpeechSynthesisUtterance,()=>{}) : null;
  for (const control of [rateSelect, voiceSelect]) control.addEventListener('change', () => {
    if(control===rateSelect&&view.plugin.settings?.readerSyncPreferences){view.plugin.settings.sharedSpeechRate=Number(rateSelect.value);view.plugin._saveLocalData?.();}
    if (queue) queue.rate = Number(rateSelect.value);
    save({...readSaved(), rate:Number(rateSelect.value), voice:voiceSelect.value});
    const selectedVoice=synth?.getVoices().find(v=>v.voiceURI===voiceSelect.value);
    savePrefs({rate:Number(rateSelect.value),voice:voiceSelect.value,...(selectedVoice ? {voicesByLanguage:{...readPrefs().voicesByLanguage,[voiceFamily(selectedVoice.lang)]:selectedVoice.voiceURI}} : {})});
    refreshVoices();
  });
  const quick=doc.createElement('div');quick.className='brtts-rate-quick';settings.append(quick);
  const changeRate=value=>{rateSelect.value=String(Math.max(0.5,Math.min(3,Math.round(value*10)/10)));rateSelect.dispatchEvent(new win.Event('change'));};
  for(const [label,fn] of [['−0.1',()=>changeRate(Number(rateSelect.value)-0.1)],['1×',()=>changeRate(1)],['1.5×',()=>changeRate(1.5)],['2×',()=>changeRate(2)],['＋0.1',()=>changeRate(Number(rateSelect.value)+0.1)]]){const b=button(label,fn);b.setAttribute('aria-label',t("Speed ")+label);quick.append(b);}
  const applyNow=button(t("Apply to current phrase"),()=>{preview?.stop();if(queue?.state==='playing')queue.seek(queue.index);else status.textContent=t("Saved; the next playback will use these settings");});settings.append(applyNow);
  const disposeVoiceManager=mountVoiceManager(doc,settings,synth,voice=>{
    languageSelect.value=voice.lang;
    // Persist first, then rebuild available voices in the selected language.
    save({...readSaved(),language:voice.lang,voice:voice.voiceURI});
    savePrefs({language:voice.lang,voice:voice.voiceURI,voicesByLanguage:{...readPrefs().voicesByLanguage,[voiceFamily(voice.lang)]:voice.voiceURI}});
    refreshVoices(true);
  },()=>refreshVoices());
  row.append(status); refreshVoices(true);
  rateSelect.value = String(readSaved().rate || 1);refreshVoices(true);
  follow=readSaved().follow !== false;followBox.checked=follow;
  const disposePopover=mountReaderPopover(options,settings,t("Voice settings"));
  const voicesChanged=()=>refreshVoices();
  synth?.addEventListener('voiceschanged', voicesChanged);
  status.textContent = queue ? t("EPUB system speech · changes apply to the next phrase") : t("System speech is unavailable on this device");
  if (!queue) row.dataset.state='error';
  if (!queue) row.querySelectorAll('button,select').forEach(el => el.disabled = true);
  // File is not yet set on desktop when the toolbar is constructed.
  const api = {
    stop() { preview?.stop();queue?.stop(); },
    reset() { preview?.stop();cancelSleep();sleepSelect.value='0';queue?.stop(); const saved = readSaved(); rateSelect.value = String(saved.rate || 1);follow=saved.follow !== false;followBox.checked=follow; refreshVoices(true);if(queue)queue.rate=Number(rateSelect.value); },
    dispose() { disposePopover();disposeVoiceManager();preview?.stop();cancelSleep();queue?.stop(); disposed = true; clearMark(); synth?.removeEventListener('voiceschanged', voicesChanged);delete root.dataset.ttsHighlight; row.remove(); if (activeReader === queue) activeReader = null; }
  };
  view._tts = api;
  view.plugin.register(() => api.dispose());
  return api;
}

