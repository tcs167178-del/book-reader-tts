import {Modal,Notice,Setting} from 'obsidian';
import {t} from './i18n.js';
import {mountSyncSettings} from './reader-sync-ui.js';
import {parseTags,libraryTags,tagsFor,editTags,renameTag,removeTag} from './library-core.js';

export function openShelfSettings(view) { new ShelfSettings(view).open(); }
export function openBookTags(view,paths,append=false) { new BookTags(view,paths,append).open(); }
class ShelfSettings extends Modal {
 constructor(view){super(view.app);this.view=view;}
 onOpen(){
  const c=this.contentEl,s=this.view.plugin.settings;c.addClass('br-shelf-dialog');c.createEl('h2',{text:t('Customize bookshelf')});
  const draft={...s,libraryLabels:{...s.libraryLabels}};
  new Setting(c).setName(t('Shelf name')).addText(x=>x.setValue(s.libraryTitle||'').setPlaceholder(t('Library')).onChange(v=>draft.libraryTitle=v.trim()));
  new Setting(c).setName(t('Shelf subtitle')).addText(x=>x.setValue(s.librarySubtitle??'').setPlaceholder(t('My reading collection')).onChange(v=>draft.librarySubtitle=v.trim()));
  new Setting(c).setName(t('Show folder filters')).setDesc(t('Folder names are separate from your custom tags.')).addToggle(x=>x.setValue(s.libraryShowFolders===true).onChange(v=>draft.libraryShowFolders=v));
  new Setting(c).setName(t('Shelf layout')).addDropdown(x=>x.addOption('grid',t('Covers')).addOption('compact',t('Compact covers')).setValue(s.libraryLayout||'grid').onChange(v=>draft.libraryLayout=v));
  c.createEl('h3',{text:t('Filter names')});
  for(const [key,label]of [['all','All'],['status:reading','Reading'],['status:new','Not started'],['status:done','Finished'],['archive','Archive']])new Setting(c).setName(t(label)).addText(x=>x.setValue(s.libraryLabels?.[key]||'').setPlaceholder(t(label)).onChange(v=>draft.libraryLabels[key]=v.trim()));
  new Setting(c).addButton(b=>b.setButtonText(t('Save')).setCta().onClick(async()=>{try{for(const key of ['libraryTitle','librarySubtitle','libraryShowFolders','libraryLayout','libraryLabels'])s[key]=draft[key];await this.view.plugin._saveLocalData();this.close();this.view._refresh();}catch(e){new Notice(t('Error: {0}',e.message));}}));
  c.createEl('h3',{text:t('Manage tags')});c.createEl('p',{text:t('Tags group books without moving files. Renaming updates every book; removing a tag keeps all books.')});
  const row=c.createDiv('br-tag-create'),input=row.createEl('input',{attr:{placeholder:t('New tag'), 'aria-label':t('New tag')}});
  row.createEl('button',{text:t('Add tag')}).onclick=async()=>{const names=parseTags(input.value);if(!names.length)return;s.libraryTagNames=[...new Set([...libraryTags(s),...names])];await this.view.plugin._saveLocalData();input.value='';draw();this.view._refresh();};
  const list=c.createDiv();
  mountSyncSettings(c,this.view.plugin);
  const draw=()=>{list.empty();for(const tag of libraryTags(s)){
   const r=list.createDiv('br-tag-edit');const name=r.createEl('input',{attr:{'aria-label':t('Tag name')}});name.value=tag;
   r.createEl('button',{text:t('Rename')}).onclick=async()=>{try{renameTag(s,tag,name.value);await this.view.plugin._saveLocalData();draw();this.view._refresh();}catch(e){new Notice(t(e.message));}};
   r.createEl('button',{text:t('Remove tag')}).onclick=async()=>{removeTag(s,tag);await this.view.plugin._saveLocalData();draw();this.view._refresh();};
  }};draw();
 }
 onClose(){this.contentEl.empty();}
}
class BookTags extends Modal {
 constructor(view,paths,append){super(view.app);this.view=view;this.paths=paths;this.append=append;}
 onOpen(){
  const c=this.contentEl,s=this.view.plugin.settings;c.addClass('br-shelf-dialog');c.createEl('h2',{text:t('Edit book tags')});
  c.createEl('p',{text:this.append?t('Adds tags to selected books without removing existing tags.'):t('Separate tags with commas. Clear the field to remove tags from this book.')});
  const input=c.createEl('input',{cls:'br-tag-input',attr:{'aria-label':t('Tags')}});input.value=this.append?'':tagsFor(s,this.paths[0]).join(', ');
  const choices=c.createDiv('br-card-tags');for(const tag of libraryTags(s)){const b=choices.createEl('button',{text:tag});b.onclick=()=>input.value=parseTags(input.value+','+tag).join(', ');}
  new Setting(c).addButton(b=>b.setButtonText(t('Cancel')).onClick(()=>this.close())).addButton(b=>b.setButtonText(t('Save')).setCta().onClick(async()=>{try{editTags(s,this.paths,parseTags(input.value),this.append);await this.view.plugin._saveLocalData();this.close();this.view._refresh();}catch(e){new Notice(t('Error: {0}',e.message));}}));
 }
 onClose(){this.contentEl.empty();}
}
