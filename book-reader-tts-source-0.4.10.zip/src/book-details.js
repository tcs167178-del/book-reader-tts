import JSZip from 'jszip';
export function cleanBookName(name) {
 return String(name||'').replace(/^[a-f0-9]{10,64}[-_]/i,'').replace(/\s*\(?z-library[^)]*\)?/ig,'').replace(/_/g,' ').replace(/\s+/g,' ').trim();
}
export function bookDetails(settings,file) {
 const cached=settings.bookDisplayMetadata?.[file.path]||{},custom=settings.bookDisplayOverrides?.[file.path]||{};
 return {title:custom.title||cached.title||cleanBookName(file.basename)||file.basename,author:custom.author??cached.author??''};
}
export async function epubDetails(binary,Parser) {
 const zip=await JSZip.loadAsync(binary);
 const parse=xml=>{const doc=new Parser().parseFromString(xml,'application/xml');if(doc.getElementsByTagName('parsererror').length)throw Error('Invalid EPUB metadata');return doc;};
 const container=zip.file('META-INF/container.xml');if(!container)throw Error('Missing EPUB container');
 const doc=parse(await container.async('string'));
 const path=doc.getElementsByTagNameNS('*','rootfile')[0]?.getAttribute('full-path');
 const opf=path&&zip.file(path);if(!opf)throw Error('Missing EPUB package');
 const metadata=parse(await opf.async('string'));
 const values=name=>Array.from(metadata.getElementsByTagNameNS('http://purl.org/dc/elements/1.1/',name)).map(e=>e.textContent.trim()).filter(Boolean);
 return {title:values('title')[0]||'',author:values('creator').join(' · ')};
}
export function loadBookDetails(plugin,file,Parser) {
 if(file.extension!=='epub'||file.stat?.size>100*1024*1024)return Promise.resolve(bookDetails(plugin.settings,file));
 const stamp=`${file.stat?.mtime||0}:${file.stat?.size||0}`;
 if(plugin.settings.bookDisplayMetadata?.[file.path]?.stamp===stamp)return Promise.resolve(bookDetails(plugin.settings,file));
 plugin._detailJobs??=new Map();if(plugin._detailJobs.has(file.path))return plugin._detailJobs.get(file.path);
 const task=(plugin._detailChain||Promise.resolve()).then(async()=>{
  let data={};try{data=await epubDetails(await plugin.app.vault.readBinary(file),Parser);}catch{/* Keep filename fallback for malformed or unavailable books. */}
  plugin.settings.bookDisplayMetadata??={};plugin.settings.bookDisplayMetadata[file.path]={...data,stamp};
  await plugin._saveLocalData();return bookDetails(plugin.settings,file);
 }).finally(()=>plugin._detailJobs.delete(file.path));
 plugin._detailChain=task.catch(()=>{});plugin._detailJobs.set(file.path,task);return task;
}
export function latestReading(files,settings,getProgress) {
 return files.filter(f=>!settings.bookArchives?.[f.path]&&getProgress(f.path)?.lastRead>0).sort((a,b)=>getProgress(b.path).lastRead-getProgress(a.path).lastRead)[0]||null;
}
