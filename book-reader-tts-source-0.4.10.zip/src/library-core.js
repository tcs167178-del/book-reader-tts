export function parseTags(value) {
  return [...new Set(String(value || '').split(/[,，;；、\n]+/u).map(s=>s.trim().replace(/^#+/u,'')).filter(Boolean))];
}
export function tagsFor(settings,path) { return parseTags((settings.bookTags?.[path] || []).join(',')); }
export function libraryTags(settings) {
  return [...new Set([...(settings.libraryTagNames || []),...Object.values(settings.bookTags || {}).flat()].filter(s=>typeof s==='string'&&s.trim()))];
}
export function setArchived(settings,paths,archived) {
  settings.bookArchives ??= {};
  for (const path of paths) { if(archived) settings.bookArchives[path]=true; else delete settings.bookArchives[path]; }
}
export function visibleBooks(files,settings,archive=false) {
  return files.filter(f=>Boolean(settings.bookArchives?.[f.path])===archive);
}
export function editTags(settings,paths,tags,append=false) {
  settings.bookTags ??= {};
  for(const path of paths) settings.bookTags[path]=parseTags([...(append?tagsFor(settings,path):[]),...tags].join(','));
  settings.libraryTagNames=[...new Set([...libraryTags(settings),...tags])];
}
export function renameTag(settings,oldName,newName) {
  const parsed=parseTags(newName),name=parsed[0];
  if(!name || parsed.length!==1 || /[,，;；、\n]/u.test(newName)) throw Error('Tag names cannot be empty or contain separators.');
  settings.libraryTagNames=[...new Set(libraryTags(settings).map(t=>t===oldName?name:t))];
  for(const [path,tags]of Object.entries(settings.bookTags||{})) settings.bookTags[path]=[...new Set(tags.map(t=>t===oldName?name:t))];
  if(settings.libCategory==='tag:'+oldName) settings.libCategory='tag:'+name;
}
export function removeTag(settings,name) {
  settings.libraryTagNames=libraryTags(settings).filter(t=>t!==name);
  for(const [path,tags]of Object.entries(settings.bookTags||{})) settings.bookTags[path]=tags.filter(t=>t!==name);
  if(settings.libCategory==='tag:'+name) settings.libCategory='all';
  for(const key of ['libraryCollectionOrder','libraryHiddenCollections'])settings[key]=(settings[key]||[]).filter(id=>id!=='tag:'+name);
  if(settings.libraryLabels)delete settings.libraryLabels['tag:'+name];
}
export function moveLibraryMetadata(settings,oldPath,newPath) {
  for(const key of ['bookArchives','bookTags','bookNoteLinks','bookNotePrompted','bookTemplates','coverFits','bookReadingSeconds','bookDisplayMetadata','bookDisplayOverrides']) {
    const map=settings[key];if(map&&Object.hasOwn(map,oldPath)){map[newPath]=map[oldPath];delete map[oldPath];}
  }
}
export function sortLibrary(files,mode,getProgress,locale,getDetails) {
  return [...files].sort((a,b)=>{
    const title=()=>(getDetails?.(a)?.title||a.basename).localeCompare(getDetails?.(b)?.title||b.basename,locale,{numeric:true,sensitivity:'base'});
    if(mode==='title')return title();
    if(mode==='added')return (b.stat?.ctime||0)-(a.stat?.ctime||0)||title();
    if(mode==='progress')return (getProgress(b.path)?.percent||0)-(getProgress(a.path)?.percent||0)||title();
    return (getProgress(b.path)?.lastRead||0)-(getProgress(a.path)?.lastRead||0)||title();
  });
}

// Apply only explicitly changed shelves: mixed membership in a bulk selection is preserved.
export function setCollectionMembership(settings, paths, changes) {
  settings.bookTags ??= {};
  for (const path of paths) {
    const tags = new Set(tagsFor(settings,path));
    for (const [name,enabled] of changes) enabled ? tags.add(name) : tags.delete(name);
    settings.bookTags[path] = [...tags];
  }
  settings.libraryTagNames = [...new Set([...libraryTags(settings),...Array.from(changes.keys())])];
}
