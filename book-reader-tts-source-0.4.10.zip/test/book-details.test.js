import test from 'node:test';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import {JSDOM} from 'jsdom';
import {epubDetails,cleanBookName,bookDetails,latestReading,loadBookDetails} from '../src/book-details.js';
import {removeTag,moveLibraryMetadata} from '../src/library-core.js';
test('EPUB namespace metadata takes precedence; overrides and filename fallback preserve physical names',async()=>{
 const dom=new JSDOM(),zip=new JSZip();
 zip.file('META-INF/container.xml','<container><rootfiles><rootfile full-path="OPS/book.opf"/></rootfiles></container>');
 zip.file('OPS/book.opf','<package xmlns:dc="http://purl.org/dc/elements/1.1/"><metadata><dc:title>Book &amp; History</dc:title><dc:creator>Writer</dc:creator></metadata></package>');
 const bytes=await zip.generateAsync({type:'uint8array'}),data=await epubDetails(bytes,dom.window.DOMParser);assert.deepEqual(data,{title:'Book & History',author:'Writer'});
 const file={path:'a.epub',basename:'0a0c63804617-Elon_Musk',extension:'epub',stat:{mtime:1,size:10}};
 assert.equal(cleanBookName(file.basename),'Elon Musk');
 const settings={bookDisplayMetadata:{'a.epub':data},bookDisplayOverrides:{'a.epub':{title:'My title',author:''}}};
 assert.deepEqual(bookDetails(settings,file),{title:'My title',author:''});assert.equal(file.basename,'0a0c63804617-Elon_Musk');
 let reads=0;const plugin={settings:{},app:{vault:{readBinary:async()=>{reads++;return bytes}}},_saveLocalData:async()=>{}};
 await Promise.all([loadBookDetails(plugin,file,dom.window.DOMParser),loadBookDetails(plugin,file,dom.window.DOMParser)]);await loadBookDetails(plugin,file,dom.window.DOMParser);assert.equal(reads,1);
 file.stat.mtime=2;await loadBookDetails(plugin,file,dom.window.DOMParser);assert.equal(reads,2);dom.window.close();
});
test('deleting a shelf preserves books and unrelated metadata; continue reading excludes archives and missing files',()=>{
 const s={bookTags:{a:['History','English'],b:['History']},libraryTagNames:['History','English'],libraryHiddenCollections:['tag:History'],libraryCollectionOrder:['all','tag:History'],libCategory:'tag:History',bookDisplayOverrides:{a:{title:'Title'}},bookArchives:{b:true}};
 removeTag(s,'History');assert.deepEqual(s.bookTags,{a:['English'],b:[]});assert.equal(s.libCategory,'all');assert.deepEqual(s.libraryCollectionOrder,['all']);assert.deepEqual(s.libraryHiddenCollections,[]);
 const progress={a:{lastRead:2},b:{lastRead:5},missing:{lastRead:10}};
 assert.equal(latestReading([{path:'a'},{path:'b'}],s,p=>progress[p]).path,'a');
 moveLibraryMetadata(s,'a','new');assert.equal(s.bookDisplayOverrides.new.title,'Title');
});
