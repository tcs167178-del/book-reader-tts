import {Notice,Setting} from 'obsidian';
import {ReaderSync,SYNC_FOLDER} from './reader-sync.js';
import {t} from './i18n.js';
export async function installReaderSync(plugin) {
 const storageKey=`reader-sync-device:${plugin.manifest.id}:${plugin.app.vault.getName()}`;
 let device=localStorage.getItem(storageKey);
 if(!device||!/^[a-z0-9-]+$/i.test(device)){device=crypto.randomUUID();localStorage.setItem(storageKey,device);}
 let lastError=0;
 const fail=e=>{console.error('Book Reader sync:',e);if(Date.now()-lastError>60000){new Notice(t('Reader sync failed. Existing data was kept; check the console and retry.'));lastError=Date.now();}};
 plugin.readerSync=new ReaderSync(plugin,device,fail,localStorage);
 try {await plugin.readerSync.initialize();}catch(e){fail(e);}
 plugin.addCommand({id:'merge-reader-sync',name:t('Merge reading sync data'),callback:async()=>{
  try {if(!plugin.readerSync.ready)await plugin.readerSync.initialize();const r=await plugin.readerSync.refresh();new Notice(t('Reading data merged from {0} device(s). Run Remotely Save to transfer files.',r?.devices||1));}catch(e){fail(e);}
 }});
 plugin.registerInterval(window.setInterval(()=>plugin.readerSync.refresh().catch(fail),30000));
 plugin.register(()=>plugin.readerSync.dispose());
}
export function mountSyncSettings(container,plugin) {
 container.createEl('h3',{text:t('Reading data sync')});
 container.createEl('p',{text:t('Sync the Book Reader Sync folder and your books with Remotely Save on both devices. This button merges local files; it does not upload to the NAS.')});
 new Setting(container).setName(t('Sync reading preferences')).setDesc(t('Share font, theme and speech speed. Device voices and window layout stay local. Reopen the book to apply changes.')).addToggle(x=>x.setValue(!!plugin.settings.readerSyncPreferences).onChange(async v=>{plugin.settings.readerSyncPreferences=v;await plugin._saveLocalData();}));
 new Setting(container).setName(SYNC_FOLDER).setDesc(plugin.readerSync?.status? t('Last local merge: {0}',new Date(plugin.readerSync.status).toLocaleString()):t('No successful merge in this session.')).addButton(b=>b.setButtonText(t('Merge now')).onClick(async()=>{
  try{if(!plugin.readerSync?.ready)await plugin.readerSync?.initialize();const r=await plugin.readerSync?.refresh();new Notice(t('Reading data merged from {0} device(s). Run Remotely Save to transfer files.',r?.devices||1));}catch(e){new Notice(t('Reader sync failed. Existing data was kept; check the console and retry.'));}
 }));
}
