import {t} from './i18n.js';
// Settings float above the book, so opening them never changes pagination.
export function mountReaderPopover(details, content, title) {
 const doc=details.ownerDocument, win=doc.defaultView, summary=details.querySelector('summary');
 content.classList.add('br-reader-popover');content.setAttribute('role','region');content.setAttribute('aria-label',title);
 const close=doc.createElement('button');close.type='button';close.className='br-popover-close';close.textContent=t("Close");close.setAttribute('aria-label',t("Close {0}",title));content.prepend(close);
 const hide=()=>{details.open=false;summary.focus();};close.addEventListener('click',hide);
 const place=()=>{};
 const toggle=()=>{summary.setAttribute('aria-expanded',String(details.open));if(details.open){for(const other of doc.querySelectorAll('.br-reader-settings[open]'))if(other!==details)other.open=false;place();}};
 const outside=e=>{if(details.open&&!details.contains(e.target))details.open=false;};
 const key=e=>{if(details.open&&e.key==='Escape'){e.preventDefault();e.stopPropagation();hide();}};
 details.classList.add('br-reader-settings');summary.setAttribute('aria-expanded','false');
 details.addEventListener('toggle',toggle);doc.addEventListener('pointerdown',outside);doc.addEventListener('keydown',key,true);win.addEventListener('resize',place);
 return ()=>{details.removeEventListener('toggle',toggle);doc.removeEventListener('pointerdown',outside);doc.removeEventListener('keydown',key,true);win.removeEventListener('resize',place);};
}
