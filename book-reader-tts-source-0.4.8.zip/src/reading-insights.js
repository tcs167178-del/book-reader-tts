export function localDay(date){return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;}
export function readingInsights(settings,now=new Date()){
 const log=settings.readingLog||{};const seconds=x=>Number.isFinite(x)&&x>0?x:0;
 const day=offset=>{const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()+offset);return localDay(d);};
 const days=Array.from({length:7},(_,i)=>({date:day(i-6),seconds:seconds(log[day(i-6)])}));
 const week=days.reduce((sum,x)=>sum+x.seconds,0),previous=Array.from({length:7},(_,i)=>seconds(log[day(i-13)])).reduce((a,b)=>a+b,0);
 let streak=0,offset=seconds(log[day(0)])?0:-1;
 while(streak<4000&&seconds(log[day(offset-streak)]))streak++;
 const ranked=Object.entries(settings.bookReadingSeconds||{}).filter(([,s])=>seconds(s)>0).map(([path,s])=>({path,seconds:s})).sort((a,b)=>b.seconds-a.seconds||a.path.localeCompare(b.path));
 return {days,week,previous,today:seconds(log[day(0)]),streak,activeDays:days.filter(x=>x.seconds>0).length,total:Math.max(seconds(settings.lifetimeSeconds),Object.values(log).reduce((a,b)=>a+seconds(b),0)),ranked};
}
