import {t} from './i18n.js';
export function estimateReadingSeconds(text) {
 const cjk=(String(text).match(/[\u3040-\u30ff\u3400-\u9fff]/g)||[]).length;
 const words=(String(text).match(/[A-Za-z]+(?:['’-][A-Za-z]+)*/g)||[]).length;
 return cjk/300*60+words/220*60;
}
export function formatReadingTime(seconds){const minutes=Math.ceil(Math.max(0,seconds)/60);return minutes>=60?t("{0} h {1} min",Math.floor(minutes/60),minutes%60):t("{0} min",minutes);}
export function mountReadingProgress(view,host,toggleTimer=()=>{}){
 const doc=host.ownerDocument;const wrap=doc.createElement('div');wrap.className='br-progress';
 const meta=doc.createElement('div');meta.className='br-progress-meta';
 const chapter=doc.createElement('span');chapter.className='br-progress-chapter';
 const position=doc.createElement('output');position.className='br-progress-position';meta.append(chapter,position);
 const slider=doc.createElement('input');slider.type='range';slider.min='0';slider.max='1000';slider.step='1';slider.value='0';slider.disabled=true;slider.setAttribute('aria-label',t("Reading progress"));
 const back=doc.createElement('button');back.textContent=t("Return to previous position");back.type='button';back.className='br-progress-back';back.hidden=true;
 const stats=doc.createElement('div');stats.className='br-progress-stats';
 const timer=doc.createElement('button');timer.type='button';timer.className='br-session-time';timer.addEventListener('click',toggleTimer);
 const cumulativeLabel=doc.createElement('span');cumulativeLabel.className='br-cumulative-time';stats.append(cumulativeLabel);
 const remaining=doc.createElement('span');remaining.title=t("Estimated from the current text block at 300 Chinese/Japanese characters or 220 English words per minute; actual reading time may vary.");stats.append(timer,remaining);
 wrap.append(meta,slider,stats,back);host.classList.add('br-progress-host');host.append(wrap);
 let dragging=false,returnPosition=null,cachedFirst=null,cachedCount=-1,suffix=[];
 const updateTime=()=>{const seconds=Math.floor(view._sessionSec||0);timer.textContent=t("{0} Session {1}:{2}",view._running ? "Ⅱ" : "▶",Math.floor(seconds/60),String(seconds%60).padStart(2,"0"));timer.setAttribute("aria-label",view._running?t("Pause reading timer"):t("Start reading timer"));const cumulative=view.plugin?.settings?.bookReadingSeconds?.[view.file?.path]||0;cumulativeLabel.textContent=t('Read {0}',formatReadingTime(cumulative));};
 const update=(cur,total)=>{
  const max=Math.max(0,total-1);const percent=max?Math.round(cur/max*100):total?100:0;
  slider.disabled=!total;if(!dragging)slider.value=String(max?Math.round(cur/max*1000):0);
  slider.style.setProperty('--br-fill',`${Number(slider.value)/10}%`);
  const currentBlock=view.pager?.currentBlockIndex?.()||0;
  const blocks=Array.from(view.pager?._blocks?.()||[]);
  if(cachedFirst!==blocks[0]||cachedCount!==blocks.length){cachedFirst=blocks[0];cachedCount=blocks.length;suffix=new Array(blocks.length+1).fill(0);for(let i=blocks.length-1;i>=0;i--)suffix[i]=suffix[i+1]+estimateReadingSeconds(blocks[i].textContent||'');}
  const estimate=suffix[currentBlock]||0;
  remaining.textContent=total?t("{0} pages left · {1}",Math.max(0,total-cur-1),estimate ? t("About ")+formatReadingTime(estimate) : t("Time unavailable")):t("Pages depend on layout");updateTime();
  const toc=(view.tocItems||[]).filter(item=>Number.isFinite(item.block)&&item.block<=currentBlock).sort((a,b)=>a.block-b.block);
  chapter.textContent=toc.at(-1)?.label||view.file?.basename||t("Open a book to begin");chapter.title=chapter.textContent;
  if(!dragging)position.textContent=total?`${cur+1} / ${total} · ${percent}%`:'—';
  slider.setAttribute('aria-valuetext',total?t("Page {0} of {1}, {2}%",cur+1,total,percent):t("Not loaded"));
 };
 const jump=target=>{view._tts?.stop();const [cur,total]=view.pager.jumpTo(target);(view.updateUI||view._updateUI).call(view,cur,total);if(view.file)view.plugin.saveProgress(view.file.path,cur,total,view.pager.currentBlockIndex());};
 slider.addEventListener('input',()=>{dragging=true;const total=view.pager?.total||0;const target=Math.round(Number(slider.value)/1000*Math.max(0,total-1));position.textContent=t("Jump to {0} / {1} · {2}%",target+1,total,Math.round(Number(slider.value)/10));slider.style.setProperty('--br-fill',`${Number(slider.value)/10}%`);});
 slider.addEventListener('change',()=>{dragging=false;if(!view.pager?.total)return;returnPosition={page:view.pager.spread,total:view.pager.total,block:view.pager.currentBlockIndex()};back.hidden=false;jump(Math.round(Number(slider.value)/1000*Math.max(0,view.pager.total-1)));});
 slider.addEventListener('blur',()=>{dragging=false;update(view.pager?.spread||0,view.pager?.total||0);});
 back.addEventListener('click',()=>{if(returnPosition===null)return;jump(view.pager.total===returnPosition.total?returnPosition.page:view.pager.spreadForBlock(returnPosition.block));returnPosition=null;back.hidden=true;});
 view._readingProgress={update,updateTime,reset(){returnPosition=null;back.hidden=true;dragging=false;update(0,0);}};update(0,0);
 return view._readingProgress;
}
