import zh from './locales/zh.json' with {type:'json'};

let localeSource = () => globalThis.navigator?.language || 'en';
export function configureLocale(source) { localeSource = source; }
export function systemLocale() {
  let locale;
  try { locale = localeSource(); } catch { /* use device language */ }
  locale = String(locale || globalThis.navigator?.language || 'en').replaceAll('_','-');
  if (locale === 'zh') locale = 'zh-CN';
  if (locale === 'zh-TW') return locale;
  try { return Intl.getCanonicalLocales(locale)[0] || 'en'; } catch { return 'en'; }
}
export function uiLanguage() { return /^zh(?:-|$)/i.test(systemLocale()) ? 'zh' : 'en'; }
export function outputLanguage() { return uiLanguage() === 'zh' ? 'Chinese' : 'English'; }
export function t(key,...args) {
  const text = uiLanguage()==='zh' && Object.hasOwn(zh,key) ? zh[key] : key;
  return String(text).replace(/\{(\d+)\}/g,(match,index)=>args[Number(index)] == null ? match : String(args[Number(index)]));
}
