// One writer per device: transport may copy files in any order without replacing
// another device's changes. Tombstones prevent deleted metadata reappearing.
export const SYNC_FOLDER = 'Book Reader Sync';
const maps = ['bookArchives','bookNoteLinks','bookTemplates'];
const shelf = ['libraryTitle','librarySubtitle','libraryLabels','libraryTagNames'];
const preferences = ['fontSize','fontFamily','lineHeight','theme','textAlign','sharedSpeechRate'];
const clone = value => JSON.parse(JSON.stringify(value));
const equal = (a,b) => JSON.stringify(a) === JSON.stringify(b);
const key = (...parts) => JSON.stringify(parts);
export function snapshot(plugin) {
 const out={};const s=plugin.settings;
 for(const name of maps) for(const [path,value] of Object.entries(s[name]||{})) out[key('map',name,path)]=value;
 for(const [path,tags] of Object.entries(s.bookTags||{})) for(const tag of tags) out[key('tag',path,tag)]=true;
 for(const name of shelf) if(s[name]!==undefined) out[key('shelf',name)]=s[name];
 if(s.readerSyncPreferences) for(const name of preferences) if(s[name]!==undefined) out[key('pref',name)]=s[name];
 for(const [path,value] of Object.entries(plugin.progress||{})) out[key('progress',path)]=value;
 for(const [path,list] of Object.entries(plugin.highlights||{})) for(const value of list) if(value.id!=null) out[key('highlight',path,String(value.id))]=value;
 return clone(out);
}
export function mergeRecords(documents) {
 const records={};
 for(const doc of documents) {
  if(doc?.version!==1 || !doc.records || typeof doc.records!=='object' || Array.isArray(doc.records)) throw Error('Unsupported or damaged reader sync file');
  for(const [k,r] of Object.entries(doc.records)) {
   const parts=JSON.parse(k);
   if(!Array.isArray(parts)||parts.some(p=>typeof p!=='string'||['__proto__','constructor','prototype'].includes(p))||!r||!Number.isFinite(r.time)||typeof r.device!=='string'||(!r.deleted&&!Object.hasOwn(r,'value'))) throw Error('Unsupported or damaged reader sync file');
   const [type,a]=parts,v=r.value;
   const allowed=(type==='map'&&maps.includes(a)&&parts.length===3)||(type==='tag'&&parts.length===3)||(type==='shelf'&&shelf.includes(a)&&parts.length===2)||(type==='pref'&&preferences.includes(a)&&parts.length===2)||(type==='progress'&&parts.length===2)||(type==='highlight'&&parts.length===3);
   if(!allowed)throw Error('Unsupported or damaged reader sync file');
   if(!r.deleted) {
    const object=v&&typeof v==='object'&&!Array.isArray(v);
    if((type==='progress'&&(!object||!Number.isFinite(v.pct)||v.pct<0||v.pct>1))||(type==='highlight'&&(!object||v.id==null||String(v.id)!==parts[2]))||(type==='tag'&&v!==true)||(type==='map'&&(a==='bookArchives'?typeof v!=='boolean':typeof v!=='string'))||(type==='shelf'&&(a==='libraryTagNames'?!Array.isArray(v)||v.some(t=>typeof t!=='string'):a==='libraryLabels'?!object:typeof v!=='string'))||(type==='pref'&&!['number','string'].includes(typeof v)))throw Error('Unsupported or damaged reader sync file');
   }
   const prev=records[k];
   if(!prev || r.time>prev.time || (r.time===prev.time&&r.device>prev.device)) records[k]=clone(r);
  }
 }
 return records;
}
export function captureChanges(records,before,after,device,time) {
 for(const k of new Set([...Object.keys(before),...Object.keys(after)])) {
  if(equal(before[k],after[k]))continue;
  records[k]=Object.hasOwn(after,k)?{time,device,value:clone(after[k])}:{time,device,deleted:true};
 }
}
export function applyRecords(plugin,records) {
 const s=plugin.settings;
 for(const [k,r] of Object.entries(records)) {
  const [type,a,b]=JSON.parse(k),value=r.deleted?undefined:clone(r.value);
  // Explicit allowlists keep local layout, voices and credentials out of sync.
  if(type==='map'&&maps.includes(a)) {s[a]??={};if(r.deleted)delete s[a][b];else s[a][b]=value;}
  if(type==='tag') {s.bookTags??={};const tags=new Set(s.bookTags[a]||[]);r.deleted?tags.delete(b):tags.add(b);s.bookTags[a]=[...tags].sort();}
  if(type==='shelf'&&shelf.includes(a)) {if(r.deleted)delete s[a];else s[a]=value;}
  if(type==='pref'&&s.readerSyncPreferences&&preferences.includes(a)) {if(!r.deleted)s[a]=value;}
  if(type==='progress') {if(!equal(plugin.progress[a],value))plugin._recordBackup?.(a,plugin.progress[a],Date.now());if(r.deleted)delete plugin.progress[a];else plugin.progress[a]=value;}
  if(type==='highlight') {const list=plugin.highlights[a]||[];plugin.highlights[a]=list.filter(h=>String(h.id)!==b);if(!r.deleted)plugin.highlights[a].push(value);}
 }
}
export class ReaderSync {
 constructor(plugin,device,onError=()=>{},storage=null) {this.plugin=plugin;this.device=device;this.onError=onError;this.storage=storage;this.cacheKey=`reader-sync-pending:${device}`;this.records={};this.baseline={};this.pending={};this.chain=Promise.resolve();this.ready=false;this.clock=0;this.status='';}
 async initialize() {
  const ad=this.plugin.app.vault.adapter;
  if(!await ad.exists(SYNC_FOLDER))await this.plugin.app.vault.createFolder(SYNC_FOLDER);
  const docs=await this.readDocuments();
  const merged=mergeRecords(docs);this.clock=Math.max(0,...Object.values(merged).map(r=>r.time));
  // Bootstrap at an older logical time: an empty/new installation must never
  // replace existing remote progress with its defaults.
  const current=snapshot(this.plugin);for(const k of Object.keys(merged))delete current[k];captureChanges(this.records,{},current,this.device,1);
  const cached=this.storage?.getItem(this.cacheKey);
  this.records=mergeRecords([{version:1,records:this.records},...docs.filter(d=>d.device===this.device),...(cached?[JSON.parse(cached)]:[])]);
  const all=mergeRecords([{version:1,records:this.records},...docs]);this.clock=Math.max(this.clock,...Object.values(all).map(r=>r.time));this.remotePositions=new Set(Object.entries(all).filter(([k,r])=>JSON.parse(k)[0]==='progress'&&r.device!==this.device&&!r.deleted).map(([k])=>JSON.parse(k)[1]));applyRecords(this.plugin,all);
  this.baseline=snapshot(this.plugin);this.ready=true;
  await this.write();await this.plugin._saveLocalData();
 }
 async readDocuments() {
  const ad=this.plugin.app.vault.adapter,listing=await ad.list(SYNC_FOLDER),docs=[];
  for(const path of listing.files.filter(p=>p.endsWith('.json'))) {
   const doc=JSON.parse(await ad.read(path));mergeRecords([doc]);docs.push(doc);
  }
  return docs;
 }
 observe() {
  if(!this.ready)return;
  const current=snapshot(this.plugin);
  if(!this.plugin.settings.readerSyncPreferences) for(const k of Object.keys(this.baseline)) if(JSON.parse(k)[0]==='pref')delete this.baseline[k];
  // A logical clock also keeps updates ordered when wall clocks move backward.
  this.clock=Math.max(Date.now(),this.clock+1);
  captureChanges(this.pending,this.baseline,current,this.device,this.clock);
  try{this.storage?.setItem(this.cacheKey,JSON.stringify({version:1,records:{...this.records,...this.pending}}));}catch(e){this.onError(e);}
  this.baseline=current;
 }
 schedule() {
  if(!this.ready)return;this.observe();clearTimeout(this.timer);
  this.timer=setTimeout(()=>this.refresh().catch(this.onError),1200);
 }
 async write() {
  const ad=this.plugin.app.vault.adapter,path=`${SYNC_FOLDER}/${this.device}.json`,text=JSON.stringify({version:1,device:this.device,records:this.records},null,2);
  if(!await ad.exists(path)||await ad.read(path)!==text) await ad.write(path,text);
 }
 refresh() {
  const run=async()=>{
   if(!this.ready)return;
   this.observe();
   const docs=await this.readDocuments();
   // User actions may happen while files are being read. Capture them before
   // applying remote values, then retain dirty records if writing fails.
   this.observe();Object.assign(this.records,this.pending);this.pending={};
   const all=mergeRecords([...docs,{version:1,records:this.records}]);
   this.clock=Math.max(this.clock,...Object.values(all).map(r=>r.time));
   const old=snapshot(this.plugin);
   for(const [k,r] of Object.entries(all))if(JSON.parse(k)[0]==='progress'&&r.device!==this.device&&!r.deleted&&!equal(old[k],r.value))this.remotePositions.add(JSON.parse(k)[1]);
   applyRecords(this.plugin,all);this.baseline=snapshot(this.plugin);
   await this.write();this.status=new Date().toISOString();
   if(!equal(old,this.baseline)) {
    await this.plugin._saveLocalData();
    for(const leaf of this.plugin.app.workspace.getLeavesOfType('book-reader-tts-library'))leaf.view._refresh?.();
   }
   return {devices:new Set(docs.map(d=>d.device).filter(Boolean)).size,time:this.status};
  };
  const result=this.chain.then(run);this.chain=result.catch(()=>{});return result;
 }
 dispose(){clearTimeout(this.timer);this.ready=false;}
}
