import {t} from './i18n.js';
import {voiceFamily} from './speech-voices.js';
export function voiceDiagnostics(synth){
 return {schemaVersion:1,capturedAt:new Date().toISOString(),apiAvailable:!!synth,voices:Array.from(synth?.getVoices()||[],(v,index)=>({index,name:v.name,lang:v.lang,voiceURI:v.voiceURI,default:!!v.default,localService:!!v.localService}))};
}
export function mountVoiceManager(doc,host,synth,onSelect,onRefresh,onExport){
 const box=doc.createElement('details');box.className='brtts-voice-manager';
 const title=doc.createElement('summary');title.textContent=t("Manage and install voices");box.append(title);
 const info=doc.createElement('p');info.textContent=t("These are the system voices available to this reader. Install voices in system settings; some system-only voices are not exposed to Obsidian.");box.append(info);
 const links=doc.createElement('div');links.className='brtts-rate-quick';
 for(const [label,url] of [[t("Windows installation guide"),'https://support.microsoft.com/en-us/accessibility/windows/narrator/appendix-a-supported-languages-and-voices'],[t("iPad installation guide"),'https://support.apple.com/en-gb/111798']]){const a=doc.createElement('a');a.textContent=label;a.href=url;a.target='_blank';a.rel='noopener noreferrer';links.append(a);}box.append(links);
 const guide=doc.createElement('p');guide.textContent=t("Windows: Settings → Time & language → Speech → Add voices. iPad: Settings → Accessibility → Spoken Content → Voices (names vary by OS version). Refresh after downloading; restart Obsidian if voices still do not appear.");box.append(guide);
 const status=doc.createElement('p');status.setAttribute('role','status');box.append(status);
 const refresh=doc.createElement('button');refresh.type='button';refresh.textContent=t("Refresh installed voices");box.append(refresh);
 const diagnostics=doc.createElement('details');const diagnosticTitle=doc.createElement('summary');diagnosticTitle.textContent=t("All voices diagnostics (unfiltered)");diagnostics.append(diagnosticTitle);
 const report=doc.createElement('textarea');report.readOnly=true;report.rows=10;report.style.width='100%';report.setAttribute('aria-label',t("Full voice report"));diagnostics.append(report);
 const exportButton=doc.createElement('button');exportButton.type='button';exportButton.textContent=t("Export all voices to vault");exportButton.disabled=!onExport;diagnostics.append(exportButton);box.append(diagnostics);
 exportButton.addEventListener('click',async()=>{exportButton.disabled=true;try{const data=JSON.stringify(voiceDiagnostics(synth),null,2);report.value=data;const path=await onExport(data);status.textContent=t("Voice report saved: {0}",path);}catch(error){status.textContent=t("Voice report failed: {0}",error.message);}finally{exportButton.disabled=!onExport;}});
 const list=doc.createElement('div');list.className='brtts-voice-list';box.append(list);
 const render=()=>{list.replaceChildren();const voices=synth?.getVoices()||[];report.value=JSON.stringify(voiceDiagnostics(synth),null,2);let count=0;
 for(const [family,label]of [['zh',t("Chinese")],['en',t("English")],['ja',t("Japanese")]]){
  const matches=voices.filter(v=>voiceFamily(v.lang)===family);count+=matches.length;
  const heading=doc.createElement('h4');heading.textContent=t("{0} · {1} available voices",label,matches.length);list.append(heading);
  if(!matches.length){const p=doc.createElement('p');p.textContent=t("No voice detected. Follow the installation guide, then refresh.");list.append(p);}
  for(const voice of matches){const item=doc.createElement('div');item.className='brtts-voice-item';const name=doc.createElement('span');name.textContent=`${voice.name} · ${voice.lang} · ${voice.localService?t("Local"):t("Online")}`;name.title=voice.voiceURI;item.append(name);const identity=doc.createElement('small');identity.textContent=voice.voiceURI;identity.style.overflowWrap='anywhere';item.append(identity);const use=doc.createElement('button');use.type='button';use.textContent=t("Use this voice");use.addEventListener('click',()=>{onSelect(voice);status.textContent=t("Selected {0}. Press Preview voice to listen.",voice.name);});item.append(use);list.append(item);}
 }
 status.textContent=t("This reader found {0} Chinese / English / Japanese voices.",count);
 };
 refresh.addEventListener('click',()=>{onRefresh();render();});
 const changed=()=>{onRefresh();render();};synth?.addEventListener('voiceschanged',changed);
 const visible=()=>{if(doc.visibilityState==='visible')changed();};doc.addEventListener('visibilitychange',visible);doc.defaultView?.addEventListener('focus',changed);
 box.addEventListener('toggle',()=>{if(box.open)render();});host.append(box);render();
 return ()=>{synth?.removeEventListener('voiceschanged',changed);doc.removeEventListener('visibilitychange',visible);doc.defaultView?.removeEventListener('focus',changed);box.remove();};
}
