import {t} from './i18n.js';
import { mountReaderPopover } from './reader-popover.js';
// Reading controls share the upstream paginator and its paragraph-based position.
export function mountReadingControls(view, root, top) {
  const doc = root.ownerDocument, settings = view.plugin.settings;
  const panel = doc.createElement('details'); panel.className = 'tts-reading-controls';
  const summary = doc.createElement('summary'); summary.textContent = t("Aa Appearance"); panel.append(summary);
  const grid = doc.createElement('div'); grid.className = 'tts-reading-grid'; panel.append(grid); (root.querySelector('.brtts-controls') || top).append(panel);
  const message = doc.createElement('small');
  const run = fn => async () => { try { await fn(); message.textContent = ''; } catch (error) { message.textContent = t("Could not adjust: {0}",error.message); } };
  const repaint = async () => { const anchor=view.pager?.currentBlockIndex?.(); await view.plugin.saveAll(); (view.applyVars || view._applyTheme)?.call(view); await (view.repaginate || view._repaginate)?.call(view,anchor); paint(); };
  function select(label, values, initial, change) {
    const field = doc.createElement('label'); field.textContent = label;
    const input = doc.createElement('select'); input.setAttribute('aria-label',label);
    for (const [value,text] of values) { const option=doc.createElement('option'); option.value=value; option.textContent=text; input.append(option); }
    input.value=initial; input.addEventListener('change',run(()=>change(input.value))); field.append(input); grid.append(field); return input;
  }
  function button(text, fn, parent=grid) { const b=doc.createElement('button'); b.textContent=text; b.type='button'; b.addEventListener('click',run(fn)); parent.append(b); return b; }
  select(t("Paper theme"),[['auto',t("Match Obsidian")],['light',t("White")],['sepia',t("Sepia")],['dark',t("Night")],['eink',t("High contrast")]],settings.theme||'auto',async value=>{settings.theme=value;await repaint();});
  const size = doc.createElement('div'); size.className='tts-font-size'; grid.append(size);
  const label=doc.createElement('output'); label.textContent=t("Font size {0}",settings.fontSize || 18);
  const resize=async delta=>{settings.fontSize=Math.max(12,Math.min(40,(settings.fontSize||18)+delta));label.textContent=t("Font size {0}",settings.fontSize);await repaint();};
  button('A−',()=>resize(-2),size);size.append(label);button('A＋',()=>resize(2),size);
  select(t("Line spacing"),[['1.4',t("Compact")],['1.8',t("Comfortable")],['2.2',t("Spacious")]],String(settings.lineHeight||1.8),async value=>{settings.lineHeight=Number(value);await repaint();});
  select(t("Reading mode"),[['single',t("Single page")],['double',t("Two pages (wide screen)")],['scroll',t("Continuous scrolling")]],settings.readMode==='scroll'?'scroll':settings.columns==='2'?'double':'single',async value=>{
    view._tts?.stop();
    if(view.file&&view.pager)view.plugin.saveNow(view.file.path,view.pager.spread,view.pager.total,view.pager.currentBlockIndex());
    const old=settings.readMode; settings.readMode=value==='scroll'?'scroll':'pages';settings.columns=value==='double'?'2':'1';
    await view.plugin.saveAll();
    if(old!==settings.readMode && view.file){if(view.openFile)await view.openFile(view.file);else await view._loadBook();}else await repaint();
    paint();
  });
  select(t("Mouse wheel"),[['pages',t("Turn pages with wheel")],['off',t("Disable wheel page turning")]],settings.ttsWheel||'pages',async value=>{settings.ttsWheel=value;await view.plugin.saveAll();});
  const pictures=view.app.vault.getFiles().filter(f=>/^(png|jpe?g|webp)$/i.test(f.extension));
  select(t("Wallpaper (vault images)"),[['',t("No wallpaper")],...pictures.map(f=>[f.path,f.path])],settings.ttsWallpaper||'',async value=>{settings.ttsWallpaper=value;await view.plugin.saveAll();paint();});
  select(t("Wallpaper intensity"),[['0.04',t("Faint")],['0.08',t("Soft")],['0.15',t("Strong")]],String(settings.ttsWallpaperOpacity||0.08),async value=>{settings.ttsWallpaperOpacity=Number(value);await view.plugin.saveAll();paint();});
  button(t("Open side by side"),async()=>{if(!view.file)return; const leaf=view.app.workspace.getLeaf('split');await leaf.setViewState({type:'book-reader-tts-view',state:{path:view.file.path},active:true});});
  grid.append(message);
  function paint(){
    const file=view.app.vault.getAbstractFileByPath(settings.ttsWallpaper||'');
    root.style.setProperty('--tts-wallpaper',file?`url(${JSON.stringify(view.app.vault.getResourcePath(file))})`:'none');
    root.style.setProperty('--tts-wallpaper-opacity',String(settings.ttsWallpaperOpacity||0.08));
  }
  let total=0,last=0;
  const wheel=event=>{
    if(!view.areaEl?.contains(event.target)||event.ctrlKey||event.metaKey||view.pager?.scrollMode||settings.ttsWheel==='off')return;
    if(event.target.closest('input,textarea,select,button,a'))return;
    event.preventDefault(); const now=Date.now(); if(now-last<350)return;
    total+=(event.deltaY||event.deltaX)*(event.deltaMode===1?16:event.deltaMode===2?500:1);
    if(Math.abs(total)<60)return;
    (view.nav||view._nav)?.call(view,total>0?'next':'prev');total=0;last=now;
  };
  root.addEventListener('wheel',wheel,{passive:false});
  view.plugin.register(mountReaderPopover(panel,grid,t("Reading appearance"))); 
  paint(); view.plugin.register(()=>root.removeEventListener('wheel',wheel));
}
