// Count only foreground intervals; never count a suspended timer's long gap.
export function readingTick(previous,now,active){
 const elapsed=(now-previous)/1000;
 return active&&elapsed>0&&elapsed<=2.5?elapsed:0;
}
export function readingViewActive(view){
 const root=view.contentEl||view.containerEl,doc=root?.ownerDocument;
 if(!view.file||!root?.isConnected||doc?.visibilityState!=='visible')return false;
 if(view.leaf&&view.app?.workspace?.activeLeaf!==view.leaf)return false;
 return root.getClientRects().length>0;
}
