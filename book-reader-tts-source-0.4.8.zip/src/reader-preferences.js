// One-time migration: do not erase later deliberate changes or existing notes.
export function migrateReaderPreferences(settings) {
  settings.language = 'auto';
  settings.languagePicked = false;
  if ((settings.readerPreferencesVersion || 0) >= 1) return;
  settings.askNoteTitle = false;
  settings.noteOpenMode = 'none';
  settings.autoBookNote = false;
  settings.translateTo = 'auto';
  settings.aiInto = 'auto';
  settings.readerPreferencesVersion = 1;
}
export function bookNoteAction(settings = {}, path) {
  if (!path) return 'quiet';
  if (settings.bookNoteLinks?.[path]) return 'linked';
  if (settings.autoBookNote) return settings.bookNotePrompted?.[path] ? 'prompted' : 'auto';
  return 'quiet';
}
