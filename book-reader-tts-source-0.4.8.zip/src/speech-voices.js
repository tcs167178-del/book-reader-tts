// Conservative script-based detection: kana identifies Japanese; Han-only text
// needs book context or a manual choice because Chinese and Japanese share it.
export const voiceFamily = lang => String(lang||'').replaceAll('_','-').split('-')[0].toLowerCase();
export function detectSpeechLanguage(text, fallback='zh-CN') {
 if(/[\u3040-\u30ff]/u.test(text))return 'ja-JP';
 if(/[\u3400-\u9fff]/u.test(text))return voiceFamily(fallback)==='ja'?'ja-JP':'zh-CN';
 if(/[a-zA-Z]/.test(text))return 'en-US';
 return fallback;
}
export function chooseSpeechVoice(voices, language, preferred='') {
 const family=voiceFamily(language),matches=voices.filter(v=>voiceFamily(v.lang)===family);
 return matches.find(v=>v.voiceURI===preferred) || matches.find(v=>v.lang.replaceAll('_','-').toLowerCase()===language.toLowerCase()&&v.default) || matches.find(v=>v.lang.replaceAll('_','-').toLowerCase()===language.toLowerCase()&&v.localService) || matches.find(v=>v.lang.replaceAll('_','-').toLowerCase()===language.toLowerCase()) || matches.find(v=>v.localService) || matches[0] || null;
}
