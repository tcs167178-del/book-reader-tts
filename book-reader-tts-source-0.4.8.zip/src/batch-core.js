export const supportedBook = path => /\.(epub|pdf|fb2)$/i.test(path);
export function safeName(name) { return String(name).replace(/[<>:"/\\|?*\x00-\x1f#\[\]]/g,'_').replace(/[. ]+$/g,'').slice(0,100)||'Book'; }
export function inside(path,folder) { return !!folder && path.startsWith(folder.replace(/\/+$/,'')+'/'); }
export function chunks(text, limit=12000) { const out=[];for(let i=0;i<text.length;i+=limit)out.push(text.slice(i,i+limit));return out; }
export function extractDigest(blocks) {
 const candidates=blocks.map((text,index)=>({text:text.replace(/\s+/g,' ').trim(),index})).filter(x=>x.text.length>=35);
 const frequencies=new Map();const words=s=>s.toLowerCase().match(/[a-z]{4,}|[\u3400-\u9fff]{2}/g)||[];
 for(const p of candidates)for(const w of new Set(words(p.text)))frequencies.set(w,(frequencies.get(w)||0)+1);
 const ranked=candidates.map(p=>({...p,score:words(p.text).reduce((s,w)=>s+Math.log(1+(frequencies.get(w)||0)),0)/Math.sqrt(p.text.length)})).sort((a,b)=>b.score-a.score);
 const used=new Set();return ranked.filter(p=>{if(used.has(p.text))return false;used.add(p.text);return true;}).slice(0,8).sort((a,b)=>a.index-b.index);
}
export async function uniquePath(vault,path){let candidate=path,n=2;const dot=path.lastIndexOf('.');while(vault.getAbstractFileByPath(candidate))candidate=path.slice(0,dot)+` (${n++})`+path.slice(dot);return candidate;}
export async function ensureFolder(vault,path){let cur='';for(const part of path.split('/').filter(Boolean)){if(part==='.'||part==='..')throw Error('Invalid folder');cur=cur?cur+'/'+part:part;if(!vault.getAbstractFileByPath(cur))await vault.createFolder(cur);}}
export async function mapReduceSummary(text,ask,cancelled=()=>false){
 let items=chunks(text),round=0;
 while(items.length){const next=[];for(let i=0;i<items.length;i++){if(cancelled())throw Error('Cancelled');next.push(await ask(items[i],round,i+1,items.length));}if(next.length===1)return next[0];const joined=next.join('\n\n');if(joined.length>=items.join('').length)throw Error('Summary did not shrink; stopped to limit requests');items=chunks(joined);round++;if(round>8)throw Error('Summary reduction limit reached');}
 return items[0];
}
