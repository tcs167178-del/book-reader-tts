/* Patch pdf.js whitespace detection to retain periods in multi-character glyphs such as space-plus-period. Require the entire glyph to be whitespace; run after dependency installation. This patch is idempotent. */
const fs = require("fs");
const path = require("path");

// pdf.js writes this check as a string in v3 and as a regex literal since v4 —
// both forms are handled so the patch survives an engine upgrade.
const PAIRS = [
  ['"^(\\s)|(\\p{Mn})|(\\p{Cf})$"', '"^(\\s+)$|(\\p{Mn})|(\\p{Cf})$"'],
  ["/^(\\s)|(\\p{Mn})|(\\p{Cf})$/u", "/^(\\s+)$|(\\p{Mn})|(\\p{Cf})$/u"],
];

const targets = [
  "pdf.worker.mjs",                                        // the shipped worker
  "node_modules/pdfjs-dist/build/pdf.worker.mjs",          // source the build copies
  "node_modules/pdfjs-dist/legacy/build/pdf.worker.mjs",   // legacy build (what we embed)
  "pdf.worker.js",                                         // older engines, if vendored
  "node_modules/pdfjs-dist/build/pdf.worker.js",
  "node_modules/pdfjs-dist/legacy/build/pdf.worker.js",
];

let patched = 0, already = 0, missing = 0;
for (const rel of targets) {
  const p = path.resolve(__dirname, rel);
  if (!fs.existsSync(p)) { console.warn("  skip (not found):", rel); missing++; continue; }
  let s = fs.readFileSync(p, "utf8");
  const pair = PAIRS.find(([o, n]) => s.includes(n) || s.includes(o));
  if (!pair) { console.warn("  PATTERN NOT FOUND (pdf.js version changed?):", rel); missing++; continue; }
  const [OLD, NEW] = pair;
  if (s.includes(NEW)) { console.log("  already patched:", rel); already++; continue; }
  const n = s.split(OLD).length - 1;
  fs.writeFileSync(p, s.split(OLD).join(NEW));
  console.log(`  patched ${n}x:`, rel);
  patched++;
}
console.log(`\npatch-pdfjs: ${patched} patched, ${already} already ok, ${missing} skipped.`);
if (missing && !patched && !already) process.exit(1);
