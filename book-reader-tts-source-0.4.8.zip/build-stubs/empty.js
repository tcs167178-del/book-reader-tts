/* Empty stubs exclude server-only Node modules and optional EPUB storage branches that are unused inside Obsidian. */
const empty = {};
export default empty;
export const createInstance = () => empty;
