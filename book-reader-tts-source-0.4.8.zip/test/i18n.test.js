import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {JSDOM} from 'jsdom';
import {t,configureLocale,systemLocale} from '../src/i18n.js';
import {mountReadingProgress} from '../src/reading-progress.js';
import {mountReadingControls} from '../src/reading-controls.js';
import {migrateReaderPreferences,bookNoteAction} from '../src/reader-preferences.js';
const catalog=JSON.parse(fs.readFileSync(new URL('../src/locales/zh.json',import.meta.url)));
test('all translation calls have Chinese text with the same interpolation parameters',()=>{
 for(const file of fs.readdirSync(new URL('../src/',import.meta.url)).filter(f=>f.endsWith('.js'))){
  const text=fs.readFileSync(new URL('../src/'+file,import.meta.url),'utf8');
  for(const match of text.matchAll(/(?:__ertr|\bt)\('([^'\\]*)'/g)){
   const key=match[1];assert.ok(Object.hasOwn(catalog,key),`${file}: ${key}`);
   const fields=s=>[...s.matchAll(/\{(\d+)\}/g)].map(m=>m[1]).sort();assert.deepEqual(fields(catalog[key]),fields(key),key);
  }
  for(const match of text.matchAll(/(?:__ertr|\bt)\(("(?:[^"\\]|\\.)*")/g)){
   const key=JSON.parse(match[1]);assert.ok(Object.hasOwn(catalog,key),`${file}: ${key}`);
   const fields=s=>[...s.matchAll(/\{(\d+)\}/g)].map(m=>m[1]).sort();assert.deepEqual(fields(catalog[key]),fields(key),key);
  }
 }
});
test('locale follows host language, normalizes tags and consistently falls back to English',()=>{
 configureLocale(()=> 'zh_CN');assert.equal(systemLocale(),'zh-CN');assert.equal(t('Library'),'书库');assert.equal(t('Books: {0}',0),'书籍：0');assert.equal(t('constructor'),'constructor');
 configureLocale(()=> 'en-GB');assert.equal(t('Library'),'Library');assert.equal(t('Voice'),'Voice');
 configureLocale(()=> 'ja-JP');assert.equal(t('Library'),'Library');assert.equal(t('Voice'),'Voice');
 configureLocale(()=> 'not_a_valid_locale_!');assert.equal(systemLocale(),'en');assert.equal(t('Unknown {2}',0),'Unknown {2}');
});
test('English reader surfaces do not contain hardcoded Chinese and preserve book titles',()=>{
 configureLocale(()=> 'en-GB');const dom=new JSDOM('<main><header></header><footer></footer></main>'),d=dom.window.document;
 const view={plugin:{settings:{},register(){},saveAll:async()=>{}},app:{vault:{getFiles:()=>[],getAbstractFileByPath:()=>null}},pager:{},file:{basename:'中文书名'}};
 mountReadingControls(view,d.querySelector('main'),d.querySelector('header'));mountReadingProgress(view,d.querySelector('footer'));
 assert.ok(d.body.textContent.includes('中文书名'));assert.equal(/[\u3400-\u9fff]/u.test(d.body.textContent.replace('中文书名','')),false);assert.ok(d.querySelector('[aria-label="Reading mode"]'));dom.window.close();
});
test('quiet-note migration preserves links, is persisted once and respects later opt-ins',()=>{
 const settings={askNoteTitle:true,noteOpenMode:'split',autoBookNote:true,bookNoteLinks:{'a.epub':'My note'},bookTags:{'a.epub':['Keep']}};
 migrateReaderPreferences(settings);assert.equal(settings.askNoteTitle,false);assert.equal(settings.noteOpenMode,'none');assert.equal(bookNoteAction(settings,'a.epub'),'linked');assert.equal(bookNoteAction(settings,'new.epub'),'quiet');assert.deepEqual(settings.bookTags,{'a.epub':['Keep']});
 settings.askNoteTitle=true;settings.autoBookNote=true;migrateReaderPreferences(settings);assert.equal(settings.askNoteTitle,true);assert.equal(bookNoteAction(settings,'new.epub'),'auto');
 const main=fs.readFileSync(new URL('../src/main.js',import.meta.url),'utf8');assert.equal(main.includes('title: __ertr("Quotes added")'),false);assert.equal(main.includes('this._maybePromptBookNote'),true);
});
