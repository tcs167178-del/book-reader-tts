import test from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {mountReaderPopover} from '../src/reader-popover.js';
import {mountReadingControls} from '../src/reading-controls.js';
test('settings layers dismiss with Escape and never request pagination',async()=>{
 const dom=new JSDOM('<details><summary>Settings</summary><div></div></details>');const d=dom.window.document,details=d.querySelector('details');const dispose=mountReaderPopover(details,d.querySelector('details > div'),'Settings');
 details.open=true;details.dispatchEvent(new dom.window.Event('toggle'));assert.equal(d.querySelector('summary').getAttribute('aria-expanded'),'true');assert.equal(d.querySelector('.br-reader-popover').getAttribute('role'),'region');
 d.dispatchEvent(new dom.window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));assert.equal(details.open,false);assert.equal(d.activeElement,d.querySelector('summary'));dispose();dom.window.close();
});
test('font changes capture the old paragraph before applying layout metrics',async()=>{
 const dom=new JSDOM('<main><header></header><div class="brtts-controls"></div></main>');const d=dom.window.document;let block=42,received;
 const view={plugin:{settings:{fontSize:18},register(){},saveAll:async()=>{}},pager:{currentBlockIndex:()=>block},app:{vault:{getFiles:()=>[],getAbstractFileByPath:()=>null}},applyVars(){block=99;},repaginate:async a=>{received=a;}};
 mountReadingControls(view,d.querySelector('main'),d.querySelector('header'));[...d.querySelectorAll('button')].find(b=>b.textContent==='A＋').click();await new Promise(r=>setImmediate(r));assert.equal(received,42);assert.equal(view.plugin.settings.fontSize,20);dom.window.close();
});
