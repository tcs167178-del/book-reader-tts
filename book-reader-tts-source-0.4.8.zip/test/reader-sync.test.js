import test from 'node:test';
import assert from 'node:assert/strict';
import {ReaderSync,snapshot,mergeRecords,captureChanges,applyRecords,SYNC_FOLDER} from '../src/reader-sync.js';
const make=(files=new Map(),settings={})=>({settings,progress:{},highlights:{},_saveLocalData:async()=>{},app:{workspace:{getLeavesOfType:()=>[]},vault:{createFolder:async()=>{},adapter:{exists:async p=>p===SYNC_FOLDER||files.has(p),list:async()=>({files:[...files.keys()]}),read:async p=>files.get(p),write:async(p,s)=>files.set(p,s)}}}});
test('two writers converge on concurrent book tags, archives, progress and highlight removal',async()=>{
 const files=new Map(),a=make(files,{bookTags:{book:['Initial']},fontSize:18}),b=make(files,{fontSize:25});
 a.progress.book={pct:.2,percent:20};a.highlights.book=[{id:'h1',text:'Keep initially'}];
 const x=new ReaderSync(a,'a'),y=new ReaderSync(b,'b');await x.initialize();await y.initialize();
 assert.equal(b.progress.book.pct,.2);assert.equal(b.settings.fontSize,25);
 a.settings.bookTags.book.push('A');b.settings.bookTags.book.push('B');a.settings.bookArchives={book:true};
 a.highlights.book=[];b.highlights.book.push({id:'h2',text:'New'});b.progress.book={pct:.6,percent:60};
 await x.refresh();await y.refresh();await x.refresh();
 assert.deepEqual(a.settings.bookTags.book,['A','B','Initial']);assert.deepEqual(b.settings.bookTags.book,a.settings.bookTags.book);
 assert.equal(b.settings.bookArchives.book,true);assert.equal(a.progress.book.pct,.6);assert.deepEqual(a.highlights.book.map(h=>h.id),['h2']);assert.deepEqual(b.highlights.book.map(h=>h.id),['h2']);
 delete b.settings.bookArchives.book;await y.refresh();await x.refresh();assert.equal(a.settings.bookArchives.book,undefined);
 const restarted=make(files,{bookArchives:{book:true}});const z=new ReaderSync(restarted,'a');await z.initialize();assert.equal(restarted.settings.bookArchives.book,undefined);assert.equal(restarted.progress.book.pct,.6);
});
test('corrupt remote data does not overwrite state and failed writes can be retried',async()=>{
 const files=new Map(),a=make(files),x=new ReaderSync(a,'a');await x.initialize();a.settings.bookTags={book:['safe']};
 files.set(`${SYNC_FOLDER}/bad.json`,'{incomplete');await assert.rejects(x.refresh());assert.deepEqual(a.settings.bookTags.book,['safe']);files.delete(`${SYNC_FOLDER}/bad.json`);
 const write=a.app.vault.adapter.write;a.app.vault.adapter.write=async()=>{throw Error('offline disk');};await assert.rejects(x.refresh());a.app.vault.adapter.write=write;await x.refresh();
 const b=make(files);await new ReaderSync(b,'b').initialize();assert.deepEqual(b.settings.bookTags.book,['safe']);
});
test('pending device cache survives a close before transport file is written',async()=>{
 const files=new Map(),cache=new Map(),storage={getItem:k=>cache.get(k),setItem:(k,v)=>cache.set(k,v)};
 const a=make(files),x=new ReaderSync(a,'a',()=>{},storage);await x.initialize();a.progress.book={pct:.7,percent:70};x.observe();x.dispose();
 const b=make(files);await new ReaderSync(b,'a',()=>{},storage).initialize();assert.equal(b.progress.book.pct,.7);
});
test('preferences are opt-in; credentials, device voice and layout never enter shared snapshot',()=>{
 const a=make(new Map(),{fontSize:18,theme:'dark',sharedSpeechRate:1.5,columns:2,voice:'local',apiKey:'SECRET'});assert.equal(Object.keys(snapshot(a)).length,0);
 a.settings.readerSyncPreferences=true;const snap=snapshot(a),records={};captureChanges(records,{},snap,'a',10);
 const b=make(new Map(),{fontSize:24,columns:1});applyRecords(b,records);assert.equal(b.settings.fontSize,24);
 b.settings.readerSyncPreferences=true;applyRecords(b,records);assert.equal(b.settings.fontSize,18);assert.equal(b.settings.sharedSpeechRate,1.5);assert.equal(b.settings.columns,1);assert.ok(!JSON.stringify(snap).includes('SECRET'));assert.ok(!JSON.stringify(snap).includes('voice'));
});
test('merge order is deterministic; unsafe schema is rejected',()=>{
 const k=JSON.stringify(['tag','book','Tag']),a={version:1,records:{[k]:{time:5,device:'a',value:true}}},b={version:1,records:{[k]:{time:5,device:'b',deleted:true}}};
 assert.deepEqual(mergeRecords([a,b]),mergeRecords([b,a]));assert.equal(mergeRecords([a,b])[k].deleted,true);
 assert.throws(()=>mergeRecords([{version:2,records:{}}]));assert.throws(()=>mergeRecords([{version:1,records:{'["map","bookTags","__proto__"]':{time:2,device:'a',value:{}}}}]));
});
test('unchanged merges do not rewrite transport files',async()=>{
 const a=make(),x=new ReaderSync(a,'a');let writes=0;const write=a.app.vault.adapter.write;a.app.vault.adapter.write=async(...args)=>{writes++;return write(...args);};await x.initialize();await x.refresh();await x.refresh();assert.equal(writes,1);
});
test('offline replicas converge after file exchange and preserve overwritten progress as a restore point',async()=>{
 const fa=new Map(),fb=new Map(),a=make(fa),b=make(fb),backups=[];
 a._recordBackup=(path,value)=>{if(value)backups.push(value);};
 const x=new ReaderSync(a,'a'),y=new ReaderSync(b,'b');await x.initialize();await y.initialize();
 a.progress.book={pct:.3,percent:30};a.settings.bookNoteLinks={book:'My Note'};await x.refresh();
 b.progress.book={pct:.8,percent:80};b.settings.bookTags={book:['Offline']};y.clock=x.clock+100;await y.refresh();
 for(const [k,v]of fa)fb.set(k,v);for(const [k,v]of fb)fa.set(k,v);
 await x.refresh();await y.refresh();assert.equal(a.progress.book.pct,.8);assert.equal(b.settings.bookNoteLinks.book,'My Note');assert.deepEqual(a.settings.bookTags.book,['Offline']);assert.ok(backups.some(p=>p.pct===.3));
});
test('disabling shared preferences does not erase another device preference',async()=>{
 const files=new Map(),a=make(files,{readerSyncPreferences:true,fontSize:20}),x=new ReaderSync(a,'a');await x.initialize();
 a.settings.readerSyncPreferences=false;await x.refresh();const b=make(files,{readerSyncPreferences:true,fontSize:12});await new ReaderSync(b,'b').initialize();assert.equal(b.settings.fontSize,20);
});
