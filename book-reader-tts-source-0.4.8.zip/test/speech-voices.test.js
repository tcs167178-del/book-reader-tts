import test from 'node:test';import assert from 'node:assert/strict';
import {detectSpeechLanguage,chooseSpeechVoice} from '../src/speech-voices.js';
test('three-language detection uses kana and preserves Japanese context for Han-only text',()=>{
 assert.equal(detectSpeechLanguage('これは日本語です。'),'ja-JP');assert.equal(detectSpeechLanguage('中文段落。'),'zh-CN');assert.equal(detectSpeechLanguage('An English sentence.'),'en-US');assert.equal(detectSpeechLanguage('東京大学','ja-JP'),'ja-JP');assert.equal(detectSpeechLanguage('123…','en-US'),'en-US');
});
test('automatic voice selection never chooses an unrelated language',()=>{
 const voices=[{voiceURI:'zh',lang:'zh-CN',localService:true},{voiceURI:'en',lang:'en-GB',localService:true},{voiceURI:'ja1',lang:'ja-JP'},{voiceURI:'ja2',lang:'ja-JP',localService:true}];
 assert.equal(chooseSpeechVoice(voices,'en-US','zh').voiceURI,'en');assert.equal(chooseSpeechVoice(voices,'ja-JP').voiceURI,'ja2');assert.equal(chooseSpeechVoice(voices,'ja-JP','ja1').voiceURI,'ja1');assert.equal(chooseSpeechVoice(voices.slice(0,2),'ja-JP'),null);
});
