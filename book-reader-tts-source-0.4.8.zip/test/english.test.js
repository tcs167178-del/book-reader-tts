import {t,configureLocale} from '../src/i18n.js';
import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
const source=fs.readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
test('project interface source and docs contain no untranslated Cyrillic text',()=>{
 for(const name of ['src/main.js','styles.css','README.md','esbuild.config.mjs','patch-pdfjs.cjs','build-stubs/empty.js'])assert.equal(/[\u0400-\u04ff]/.test(fs.readFileSync(new URL('../'+name,import.meta.url),'utf8')),false,name);
});
test('English formatting retains positional arguments and unknown placeholders',()=>{
 configureLocale(()=> 'en-GB');assert.equal(t('Book {0}: {1}%', 'Example',0),'Book Example: 0%');assert.equal(t('Missing {1}','Example'),'Missing {1}');
});
test('legacy Cyrillic PDF recognition remains operational after source cleanup',()=>{
 const code=source.slice(source.indexOf('const PDF_CYR_SHIFT'),source.indexOf('function pdfItemsLookShifted'));
 const decode=vm.runInNewContext(code+';unshiftCyrillic');const text='Маркетинг';const shifted=Array.from(text,c=>String.fromCharCode(c.charCodeAt(0)-470)).join('');assert.equal(decode(shifted),text);
 assert.ok(source.includes('fm.\\u043e\\u0431\\u043b\\u043e\\u0436\\u043a\\u0430'));
});
