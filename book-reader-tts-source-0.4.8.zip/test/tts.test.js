import {configureLocale} from '../src/i18n.js';
configureLocale(()=> 'zh-CN');
import test from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {SpeechQueue, splitSpeech, mountSpeech} from '../src/tts.js';

function fakeSpeech() {
  const spoken=[];
  return {spoken, cancels:0, speak(u){spoken.push(u);}, cancel(){this.cancels++;}, getVoices(){return [{voiceURI:'zh-test',name:'Test',lang:'zh-CN',localService:true}];}, addEventListener(){},removeEventListener(){}};
}
class Utterance {constructor(text){this.text=text;}}
test('system default test omits explicit voice and preserves preferences and book position',()=>{
 const f=fixture();f.root.querySelector('button').click();
 const before=JSON.stringify({...f.win.localStorage});
 [...f.root.querySelectorAll('button')].find(b=>b.textContent==='试听系统默认声音（中文）').click();
 const u=f.synth.spoken.at(-1);assert.equal(u.voice,undefined);assert.equal(u.lang,'zh-CN');assert.equal(u.rate,1);
 assert.equal(JSON.stringify({...f.win.localStorage}),before);
 u.onerror({error:'not-allowed'});assert.match(f.root.querySelector('.brtts-status').textContent,/not-allowed/);
 f.api.dispose();f.win.close();
});
test('chunks preserve mixed-language text and emoji without splitting surrogate pairs',()=>{
  const text='中文。Hello world!'+ '😀'.repeat(500);
  const chunks=splitSpeech(text);
  assert.equal(chunks.join(''),text); assert.ok(chunks.every(c=>Array.from(c).length<=220));
  assert.deepEqual(splitSpeech('  \n '),[]);
});
test('sequential playback, pause/restart and stale completion are isolated',()=>{
  const synth=fakeSpeech(), q=new SpeechQueue(synth,Utterance);
  q.start([{text:'one'},{text:'two'}]);const old=synth.spoken[0];
  q.pause(); old.onend(); assert.equal(q.index,0);
  q.resume(); assert.equal(synth.spoken[1].text,'one');
  old.onerror({error:'canceled'});assert.equal(q.state,'playing');
  synth.spoken[1].onend();assert.equal(synth.spoken[2].text,'two');
  synth.spoken[2].onend();assert.equal(q.state,'finished');
});
test('stop suppresses late events, error terminates, rate and voice are applied',()=>{
  const synth=fakeSpeech(),q=new SpeechQueue(synth,Utterance);q.rate=1.5;q.voice=synth.getVoices()[0];
  q.start([{text:'test'},{text:'next'}]);const u=synth.spoken[0];assert.equal(u.rate,1.5);assert.equal(u.lang,'zh-CN');
  q.stop();u.onend();assert.equal(synth.spoken.length,1);
  q.start([{text:'again'}]);synth.spoken[1].onerror({error:'not-allowed'});assert.equal(q.state,'error');
});
function fixture(supported=true){
  const dom=new JSDOM('<main><header></header><article><p>第一段。</p><p>Second paragraph.</p></article></main>',{url:'https://test.local'});
  const win=dom.window,synth=fakeSpeech();if(supported){win.speechSynthesis=synth;win.SpeechSynthesisUtterance=Utterance;}
  const root=win.document.querySelector('main'), blocks=[...root.querySelectorAll('p')];
  let current=0;const cleanups=[];
  const view={app:{vault:{getName:()=> 'Test vault'}},file:{path:'test.epub'},ext:'epub',plugin:{register:f=>cleanups.push(f)},pager:{_blocks:()=>blocks,currentBlockIndex:()=>current,blockEl:i=>blocks[i],spreadForBlock:i=>i,jumpTo:i=>{current=i;return[i,2];}},updateUI(){}};
  const api=mountSpeech(view,root,root.querySelector('header'));
  return {dom,win,root,blocks,view,api,synth,cleanups};
}
test('toolbar integrates pagination, saves resume, restores and removes highlight on close',()=>{
  const f=fixture();f.root.querySelector('button').click();assert.equal(f.synth.spoken[0].text,'第一段。');
  assert.ok(f.blocks[0].classList.contains('brtts-speaking'));
  f.synth.spoken[0].onend();assert.ok(f.blocks[1].classList.contains('brtts-speaking'));
  f.api.dispose();assert.ok(!f.blocks[1].classList.contains('brtts-speaking'));
  mountSpeech(f.view,f.root,f.root.querySelector('header'));f.root.querySelectorAll('button')[1].click();assert.equal(f.synth.spoken.at(-1).text,'Second paragraph.');
  f.view._tts.dispose();f.dom.window.close();
});
test('no speech API yields disabled controls; PDF never starts speech',()=>{
  const no=fixture(false);assert.ok(no.root.querySelector('button').disabled);no.api.dispose();no.win.close();
  const f=fixture();f.view.ext='pdf';f.root.querySelector('button').click();assert.equal(f.synth.spoken.length,0);f.api.dispose();f.win.close();
});
test('switching books cancels playback and an inactive reader cannot cancel another reader',()=>{
  const f=fixture();f.root.querySelector('button').click();const old=f.synth.spoken[0];f.view.file={path:'other.epub'};f.api.reset();old.onend();assert.equal(f.synth.spoken.length,1);
  const synth=fakeSpeech();const a=new SpeechQueue(synth,Utterance),b=new SpeechQueue(synth,Utterance);a.start([{text:'active'}]);b.stop();assert.equal(synth.cancels,0);a.stop();f.api.dispose();f.win.close();
});
test('previous and next paragraph cancel old speech without skipping ahead on late callbacks',()=>{
  const f=fixture();f.root.querySelector('button').click();const old=f.synth.spoken[0];
  [...f.root.querySelectorAll('button')].find(b=>b.textContent==='下一段').click();
  assert.equal(f.synth.spoken.at(-1).text,'Second paragraph.');old.onend();assert.equal(f.synth.spoken.length,2);
  [...f.root.querySelectorAll('button')].find(b=>b.textContent==='上一段').click();
  assert.equal(f.synth.spoken.at(-1).text,'第一段。');f.api.dispose();f.win.close();
});
test('free reading does not jump pages; return-to-speech restores the listening location',()=>{
  const f=fixture(),follow=f.root.querySelector('[aria-label="跟随朗读翻页"]');follow.checked=false;follow.dispatchEvent(new f.win.Event('change'));
  f.root.querySelector('button').click();f.synth.spoken[0].onend();assert.equal(f.view.pager.currentBlockIndex(),0);
  [...f.root.querySelectorAll('button')].find(b=>b.textContent==='回到朗读处').click();assert.equal(f.view.pager.currentBlockIndex(),1);
  f.api.dispose();f.win.close();
});
test('sleep timer pauses and is cleared on dispose; playback toggle resumes',()=>{
  const f=fixture();let callback=null,cleared=false;
  f.win.setTimeout=fn=>{callback=fn;return 123;};f.win.clearTimeout=()=>{cleared=true;};
  f.root.querySelector('button').click();
  const sleep=f.root.querySelector('[aria-label="定时停止"]');sleep.value='5';sleep.dispatchEvent(new f.win.Event('change'));
  callback();assert.match(f.root.querySelector('.brtts-status').textContent,/定时已到/);
  const count=f.synth.spoken.length;f.root.querySelector('.brtts-primary').click();assert.equal(f.synth.spoken.length,count+1);
  sleep.value='15';sleep.dispatchEvent(new f.win.Event('change'));f.api.dispose();assert.equal(cleared,true);f.win.close();
});
test('audition does not overwrite book position and resume cancels preview',()=>{
  const f=fixture();f.root.querySelector('button').click();f.synth.spoken[0].onend();
  const key='book-reader-tts:Test vault:test.epub',saved=f.win.localStorage.getItem(key);
  [...f.root.querySelectorAll('button')].find(b=>b.textContent==='试听声音').click();
  assert.equal(f.win.localStorage.getItem(key),saved);const preview=f.synth.spoken.at(-1);
  f.root.querySelector('.brtts-primary').click();assert.equal(f.synth.spoken.at(-1).text,'Second paragraph.');
  const count=f.synth.spoken.length;preview.onend();assert.equal(f.synth.spoken.length,count);f.api.dispose();f.win.close();
});
test('voice preferences survive a new book and unavailable voice falls back visibly',()=>{
  const f=fixture();const select=f.root.querySelector('[aria-label="朗读声音"]');select.value='zh-test';select.dispatchEvent(new f.win.Event('change'));
  f.view.file={path:'new.epub'};f.api.reset();assert.equal(select.value,'zh-test');
  f.api.dispose();f.synth.getVoices=()=>[{voiceURI:'en-test',name:'English',lang:'en-US',localService:true}];
  mountSpeech(f.view,f.root,f.root.querySelector('header'));
  assert.equal(f.root.querySelector('[aria-label="朗读声音"]').value,'');assert.match(f.root.querySelector('.brtts-voice-hint').textContent,/回退/);
  f.view._tts.dispose();f.win.close();
});

test('language choice reaches speech engine and returning to system default clears it',()=>{
 const f=fixture();const language=f.root.querySelector('[aria-label="声音语言"]');
 language.value='en-US';language.dispatchEvent(new f.win.Event('change'));
 f.root.querySelector('button').click();assert.equal(f.synth.spoken.at(-1).lang,'en-US');assert.match(f.root.querySelector('.brtts-voice-hint').textContent,/未提供/);
 language.value='';language.dispatchEvent(new f.win.Event('change'));f.root.querySelector('button').click();assert.equal(f.synth.spoken.at(-1).lang,undefined);
 f.api.dispose();f.win.close();
});
test('matching language voice and new rate apply on next utterance without losing position',()=>{
 const f=fixture();const language=f.root.querySelector('[aria-label="声音语言"]');language.value='zh-CN';language.dispatchEvent(new f.win.Event('change'));f.root.querySelector('button').click();
 assert.equal(f.synth.spoken[0].voice.voiceURI,'zh-test');
 const rate=f.root.querySelector('[aria-label="朗读语速"]');rate.value='2.3';rate.dispatchEvent(new f.win.Event('change'));assert.equal(f.synth.spoken.length,1);
 f.synth.spoken[0].onend();assert.equal(f.synth.spoken.at(-1).rate,2.3);assert.equal(f.synth.spoken.at(-1).text,'Second paragraph.');
 f.view.file={path:'other.epub'};f.api.reset();assert.equal(rate.value,'2.3');assert.equal(language.value,'zh-CN');
 f.api.dispose();f.win.close();
});
test('rate controls clamp values and apply-now restarts only the current chunk',()=>{
 const f=fixture();const rate=f.root.querySelector('[aria-label="朗读语速"]');rate.value='3';rate.dispatchEvent(new f.win.Event('change'));f.root.querySelector('[aria-label="语速 ＋0.1"]').click();assert.equal(rate.value,'3');
 f.root.querySelector('button').click();const old=f.synth.spoken.at(-1);rate.value='0.5';rate.dispatchEvent(new f.win.Event('change'));f.root.querySelector('[aria-label="语速 −0.1"]').click();assert.equal(rate.value,'0.5');
 [...f.root.querySelectorAll('button')].find(b=>b.textContent==='应用到当前句').click();assert.equal(f.synth.spoken.at(-1).text,old.text);assert.equal(f.synth.spoken.at(-1).rate,0.5);const count=f.synth.spoken.length;old.onend();assert.equal(f.synth.spoken.length,count);
 f.api.dispose();f.win.close();
});

test('auto mode changes actual utterance voice between Chinese and English',()=>{
 const f=fixture();f.synth.getVoices=()=>[{voiceURI:'zh',lang:'zh-CN',name:'Chinese',localService:true},{voiceURI:'en',lang:'en-US',name:'English',localService:true}];
 const language=f.root.querySelector('[aria-label="声音语言"]');language.value='auto';language.dispatchEvent(new f.win.Event('change'));f.root.querySelector('button').click();assert.equal(f.synth.spoken.at(-1).voice.voiceURI,'zh');f.synth.spoken.at(-1).onend();assert.equal(f.synth.spoken.at(-1).voice.voiceURI,'en');
 assert.ok(![...language.options].some(o=>o.value==='fr-FR'));f.api.dispose();f.win.close();
});

test('prefetch submits bounded phrases and resumes without skipping queued text',()=>{
 const synth=fakeSpeech(),q=new SpeechQueue(synth,Utterance);q.prefetch=32;
 q.start(Array.from({length:40},(_,i)=>({text:String(i)})));
 assert.equal(synth.spoken.length,32);assert.equal(q.index,0);
 const stale=synth.spoken[5];synth.spoken[0].onend();
 assert.equal(synth.spoken.length,33);assert.equal(q.index,1);
 synth.spoken[1].onstart();q.pause();stale.onstart();stale.onend();
 assert.equal(q.index,1);assert.equal(q.pending.size,0);
 q.resume();assert.equal(synth.spoken[33].text,'1');
 q.seek(39);const last=synth.spoken.at(-1);assert.equal(last.text,'39');
 stale.onerror({error:'interrupted'});assert.equal(q.state,'playing');
 last.onend();assert.equal(q.state,'finished');assert.equal(q.pending.size,0);
});
test('a prefetch engine error cancels remaining utterances and rejects late events',()=>{
 const synth=fakeSpeech(),q=new SpeechQueue(synth,Utterance);q.prefetch=32;
 q.start([{text:'a'},{text:'b'},{text:'c'}]);synth.spoken[0].onerror({error:'interrupted'});
 assert.equal(q.state,'error');assert.equal(q.pending.size,0);assert.equal(synth.cancels,1);
 synth.spoken[1].onstart();synth.spoken[1].onend();assert.equal(q.index,0);assert.equal(synth.spoken.length,3);
});
test('background mode persists and returning from a stopped engine offers continuation',()=>{
 const f=fixture(),box=f.root.querySelector('[aria-label="后台连续朗读实验"]');
 box.checked=true;box.dispatchEvent(new f.win.Event('change'));
 f.root.querySelector('button').click();assert.equal(f.synth.spoken.length,2);
 assert.equal(JSON.parse(f.win.localStorage.getItem('book-reader-tts-preferences:Test vault')).backgroundSpeech,true);
 Object.defineProperty(f.win.document,'visibilityState',{configurable:true,value:'hidden'});
 f.win.document.dispatchEvent(new f.win.Event('visibilitychange'));assert.equal(f.synth.cancels,0);
 f.synth.speaking=false;f.synth.pending=false;
 Object.defineProperty(f.win.document,'visibilityState',{configurable:true,value:'visible'});
 f.win.document.dispatchEvent(new f.win.Event('visibilitychange'));
 assert.equal(f.root.querySelector('.brtts-controls').dataset.state,'paused');
 assert.match(f.root.querySelector('.brtts-status').textContent,/后台朗读已中断/);
 f.root.querySelector('.brtts-primary').click();assert.equal(f.synth.spoken.at(-2).text,'第一段。');
 f.api.dispose();f.win.close();
});
