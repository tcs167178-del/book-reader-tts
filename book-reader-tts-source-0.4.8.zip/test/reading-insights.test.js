import test from 'node:test';import assert from 'node:assert/strict';
import {readingInsights} from '../src/reading-insights.js';
test('insights compares calendar weeks and uses recorded totals without fabricating per-book history',()=>{
 const s={readingLog:{'2026-09-19':60,'2026-09-18':120,'2026-09-12':90},lifetimeSeconds:500,bookReadingSeconds:{'b.epub':30,'a.epub':90}};
 const r=readingInsights(s,new Date(2026,8,19));assert.equal(r.week,180);assert.equal(r.previous,90);assert.equal(r.streak,2);assert.equal(r.activeDays,2);assert.equal(r.total,500);assert.equal(r.ranked[0].path,'a.epub');
 assert.equal(readingInsights({readingLog:s.readingLog},new Date(2026,8,19)).ranked.length,0);
});
