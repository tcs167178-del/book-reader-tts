import test from 'node:test';import assert from 'node:assert/strict';
import {safeName,inside,extractDigest,uniquePath,mapReduceSummary} from '../src/batch-core.js';
test('import names stay within destination and collisions never overwrite',async()=>{
 assert.equal(safeName('../bad:name'),'.._bad_name');assert.equal(inside('BooksExtra/a.epub','Books'),false);assert.equal(inside('Books/Inbox/a.epub','Books/Inbox'),true);
 const existing=new Set(['Books/a.epub','Books/a (2).epub']);assert.equal(await uniquePath({getAbstractFileByPath:p=>existing.has(p)},'Books/a.epub'),'Books/a (3).epub');
});
test('local digest preserves source indices and removes duplicate paragraphs',()=>{
 const a='A sufficiently long paragraph about reading and learning from books.';const b='A different long paragraph about memory, habits and learning.';
 const digest=extractDigest([a,a,b]);assert.equal(digest.length,2);assert.deepEqual(digest.map(p=>p.index),[0,2]);assert.equal(digest[0].text,a);
});
test('AI summary covers all chunks, reduces summaries, and supports cancellation',async()=>{
 const received=[];const result=await mapReduceSummary('a'.repeat(25000),async(s,round)=>{received.push({s,round});return 'summary';});assert.equal(received.filter(x=>x.round===0).map(x=>x.s).join('').length,25000);assert.equal(result,'summary');assert.equal(received.length,4);
 await assert.rejects(mapReduceSummary('some text',async()=>'',()=>true),/Cancelled/);
 await assert.rejects(mapReduceSummary('a'.repeat(24000),async s=>s),/did not shrink/);
});
