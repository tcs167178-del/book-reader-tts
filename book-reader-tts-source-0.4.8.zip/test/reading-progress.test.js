import {configureLocale} from '../src/i18n.js';
configureLocale(()=> 'zh-CN');
import test from 'node:test';import assert from 'node:assert/strict';import {JSDOM} from 'jsdom';import {mountReadingProgress,estimateReadingSeconds,formatReadingTime} from '../src/reading-progress.js';
test('progress seek commits once, pauses speech, saves position and returns to original block',()=>{
 const dom=new JSDOM('<footer></footer>');const host=dom.window.document.querySelector('footer');let cur=2,stops=0,saves=0;
 const view={file:{path:'x.epub',basename:'Book'},tocItems:[{label:'Chapter one',block:0}],_tts:{stop:()=>stops++},plugin:{saveProgress:()=>saves++},pager:{total:11,spread:2,currentBlockIndex:()=>cur,spreadForBlock:b=>b+1,jumpTo:n=>{cur=n;view.pager.spread=n;return[n,11];},_blocks:()=>[]},updateUI:(a,b)=>view._readingProgress.update(a,b)};
 const api=mountReadingProgress(view,host);api.update(2,11);const input=host.querySelector('input');assert.equal(input.value,'200');input.value='800';input.dispatchEvent(new dom.window.Event('input'));assert.equal(cur,2);input.dispatchEvent(new dom.window.Event('change'));assert.equal(cur,8);assert.equal(stops,1);assert.equal(saves,1);[...host.querySelectorAll('button')].find(b=>b.textContent==='返回跳转前').click();assert.equal(cur,2);assert.match(host.textContent,/剩余 8 页/);api.reset();assert.equal(input.disabled,true);dom.window.close();
});
test('reading time estimation counts CJK characters and English words separately',()=>{assert.equal(estimateReadingSeconds('中'.repeat(300)),60);assert.equal(estimateReadingSeconds('word '.repeat(220)),60);assert.equal(formatReadingTime(3660),'1 小时 1 分钟');});
