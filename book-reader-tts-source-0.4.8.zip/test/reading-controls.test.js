import {configureLocale} from '../src/i18n.js';
configureLocale(()=> 'zh-CN');
import test from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {mountReadingControls} from '../src/reading-controls.js';
test('wheel navigation respects scrolling mode, modifiers and disabled preference',()=>{
 const dom=new JSDOM('<div id="root"><header></header><article>book</article></div>');const d=dom.window.document;const root=d.querySelector('#root');const calls=[];
 const view={plugin:{settings:{},register(){},saveAll:async()=>{}},app:{vault:{getFiles:()=>[],getAbstractFileByPath:()=>null}},areaEl:d.querySelector('article'),pager:{},nav:dir=>calls.push(dir)};
 mountReadingControls(view,root,d.querySelector('header'));
 const fire=options=>view.areaEl.dispatchEvent(new dom.window.WheelEvent('wheel',{bubbles:true,cancelable:true,deltaY:100,...options}));
 fire({ctrlKey:true});assert.equal(calls.length,0);view.pager.scrollMode=true;fire();assert.equal(calls.length,0);view.pager.scrollMode=false;view.plugin.settings.ttsWheel='off';fire();assert.equal(calls.length,0);view.plugin.settings.ttsWheel='pages';fire();assert.deepEqual(calls,['next']);fire();assert.equal(calls.length,1);
});
test('reading mode saves current paragraph before reopening and font size is bounded',async()=>{
 const dom=new JSDOM('<div id="root"><header></header></div>');const d=dom.window.document,calls=[];
 const view={plugin:{settings:{fontSize:40,readMode:'pages'},register(){},saveAll:async()=>{},saveNow:(...v)=>calls.push(['saved',...v])},app:{vault:{getFiles:()=>[],getAbstractFileByPath:()=>null}},file:{path:'test.epub'},pager:{spread:2,total:5,currentBlockIndex:()=>12},openFile:async()=>calls.push(['opened']),repaginate:async()=>{}};
 mountReadingControls(view,d.querySelector('#root'),d.querySelector('header'));const select=d.querySelector('[aria-label="阅读方式"]');select.value='scroll';select.dispatchEvent(new dom.window.Event('change'));await new Promise(r=>setImmediate(r));assert.deepEqual(calls,[['saved','test.epub',2,5,12],['opened']]);
 [...d.querySelectorAll('button')].find(b=>b.textContent==='A＋').click();await new Promise(r=>setImmediate(r));assert.equal(view.plugin.settings.fontSize,40);
});
