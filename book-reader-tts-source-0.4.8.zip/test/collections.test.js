import test from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {configureLocale} from '../src/i18n.js';
import {mountCollections,orderedCollections} from '../src/collections.js';
import {readingTick,readingViewActive} from '../src/reading-time.js';
configureLocale(()=> 'en');
test('collections rename preserves book membership, hide preserves files, reorder persists, failed save rolls back',async()=>{
 const dom=new JSDOM('<main></main>'),doc=dom.window.document;
 const settings={libraryTagNames:['History'],bookTags:{'book.epub':['History']},libCategory:'all'};let fail=false;
 const items=()=>[{id:'all',label:'All',count:1},...settings.libraryTagNames.map(x=>({id:'tag:'+x,label:x,count:1}))];
 const dispose=mountCollections(doc,doc.querySelector('main'),{settings,getItems:items,save:async()=>{if(fail)throw Error('disk');},pick:()=>{},customize:()=>{}});
 const button=text=>[...doc.querySelectorAll('button')].find(x=>x.textContent===text);
 const settle=()=>new Promise(resolve=>setTimeout(resolve,0));
 button('Edit').click();
 const rows=()=>[...doc.querySelectorAll('.br-collection-row')];
 rows()[1].querySelector('input').value='Science';[...rows()[1].querySelectorAll('button')].find(x=>x.textContent==='Rename').click();await settle();
 assert.deepEqual(settings.bookTags['book.epub'],['Science']);
 rows()[1].querySelector('button').click();await settle();assert.deepEqual(orderedCollections(items(),settings).map(x=>x.id),['all']);assert.ok(settings.bookTags['book.epub']);
 [...rows()[1].querySelectorAll('button')].find(x=>x.textContent==='Move up').click();await settle();assert.equal(settings.libraryCollectionOrder[0],'tag:Science');
 fail=true;doc.querySelector('.br-collection-new input').value='Travel';doc.querySelector('form').dispatchEvent(new dom.window.Event('submit',{cancelable:true}));await settle();assert.deepEqual(settings.libraryTagNames,['Science']);
 dispose();assert.equal(doc.querySelector('details'),null);dom.window.close();
});
test('reading time excludes background and suspended intervals',()=>{
 assert.equal(readingTick(1000,2000,true),1);assert.equal(readingTick(1000,2000,false),0);assert.equal(readingTick(1000,61000,true),0);
 const dom=new JSDOM('<main></main>',{pretendToBeVisual:true});const root=dom.window.document.querySelector('main');root.getClientRects=()=>[{}];const leaf={};
 const view={file:{path:'book.epub'},contentEl:root,leaf,app:{workspace:{activeLeaf:leaf}}};
 assert.equal(readingViewActive(view),true);view.app.workspace.activeLeaf={};assert.equal(readingViewActive(view),false);dom.window.close();
});
