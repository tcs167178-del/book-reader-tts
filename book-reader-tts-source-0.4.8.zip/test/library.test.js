import test from 'node:test';
import assert from 'node:assert/strict';
import {parseTags,editTags,renameTag,removeTag,libraryTags,setArchived,visibleBooks,sortLibrary,moveLibraryMetadata} from '../src/library-core.js';
test('archive separates the default shelf without deleting tags, notes or progress',()=>{
 const s={bookTags:{'a.epub':['History']},bookNoteLinks:{'a.epub':'Note'}};const files=[{path:'a.epub'},{path:'b.epub'}];
 setArchived(s,['a.epub'],true);assert.deepEqual(visibleBooks(files,s),[files[1]]);assert.deepEqual(visibleBooks(files,s,true),[files[0]]);assert.equal(s.bookNoteLinks['a.epub'],'Note');assert.deepEqual(s.bookTags['a.epub'],['History']);
 setArchived(s,['a.epub'],false);assert.deepEqual(visibleBooks(files,s),files);assert.deepEqual(s.bookArchives,{});
});
test('tags accept Chinese separators, batch append, rename-merge and removal',()=>{
 assert.deepEqual(parseTags('心理学，#商业、心理学；英语\n阅读'),['心理学','商业','英语','阅读']);
 const s={bookTags:{a:['Old','New'],b:['Keep']},libCategory:'tag:Old'};editTags(s,['a','b'],['Added'],true);assert.deepEqual(s.bookTags.b,['Keep','Added']);
 renameTag(s,'Old','New');assert.deepEqual(s.bookTags.a,['New','Added']);assert.equal(s.libCategory,'tag:New');removeTag(s,'New');assert.deepEqual(s.bookTags.a,['Added']);assert.equal(s.libCategory,'all');assert.ok(!libraryTags(s).includes('New'));assert.throws(()=>renameTag(s,'Added','One,Two'));
 editTags(s,['b'],[],false);assert.deepEqual(s.bookTags.b,[]);
});
test('archive and tags follow file moves without losing book-note links',()=>{
 const s={bookArchives:{old:true},bookTags:{old:['Tag']},bookNoteLinks:{old:'Note'}};moveLibraryMetadata(s,'old','new');assert.equal(s.bookArchives.new,true);assert.deepEqual(s.bookTags.new,['Tag']);assert.equal(s.bookNoteLinks.new,'Note');assert.equal(s.bookArchives.old,undefined);
});
test('sorting is deterministic and does not mutate original file order',()=>{
 const files=[{path:'b',basename:'Book 10',stat:{ctime:2}},{path:'a',basename:'Book 2',stat:{ctime:1}}],get=p=>({percent:p==='a'?70:20,lastRead:p==='a'?3:4});
 assert.deepEqual(sortLibrary(files,'title',get,'en').map(f=>f.path),['a','b']);assert.deepEqual(sortLibrary(files,'progress',get,'en').map(f=>f.path),['a','b']);assert.deepEqual(sortLibrary(files,'recent',get,'en').map(f=>f.path),['b','a']);assert.deepEqual(sortLibrary(files,'added',get,'en').map(f=>f.path),['b','a']);assert.equal(files[0].path,'b');
});
