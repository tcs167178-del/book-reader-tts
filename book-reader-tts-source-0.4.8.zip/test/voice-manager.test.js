import {configureLocale} from '../src/i18n.js';
configureLocale(()=> 'zh-CN');
import test from 'node:test';import assert from 'node:assert/strict';import {JSDOM} from 'jsdom';import {mountVoiceManager} from '../src/voice-manager.js';
test('voice manager detects newly available system voices, selects and cleans up',()=>{
 const dom=new JSDOM('<main></main>');const doc=dom.window.document;let voices=[],selected=null,listener=null,refreshes=0;
 const synth={getVoices:()=>voices,addEventListener:(name,fn)=>listener=fn,removeEventListener:(name,fn)=>{assert.equal(fn,listener);listener=null;}};
 const cleanup=mountVoiceManager(doc,doc.querySelector('main'),synth,v=>selected=v,()=>refreshes++);
 assert.match(doc.body.textContent,/日语 · 0/);voices=[{name:'Japanese voice',lang:'ja-JP',voiceURI:'ja1',localService:true}];listener();assert.match(doc.body.textContent,/日语 · 1/);assert.equal(refreshes,1);
 [...doc.querySelectorAll('button')].find(b=>b.textContent==='使用此音色').click();assert.equal(selected.voiceURI,'ja1');cleanup();assert.equal(listener,null);assert.equal(doc.querySelector('details'),null);dom.window.close();
});
test('diagnostics exports unfiltered voices and focus refresh is removed on dispose',async()=>{
 const dom=new JSDOM('<main></main>');const doc=dom.window.document;let saved=null,refreshes=0;
 const voices=[{name:'French',lang:'fr-FR',voiceURI:'fr-unique',default:true,localService:true},{name:'Cantonese',lang:'yue-HK',voiceURI:'yue-unique',localService:true}];
 const synth={getVoices:()=>voices,addEventListener(){},removeEventListener(){}};
 const cleanup=mountVoiceManager(doc,doc.querySelector('main'),synth,()=>{},()=>refreshes++,async data=>{saved=JSON.parse(data);return 'report.json';});
 assert.equal(JSON.parse(doc.querySelector('textarea').value).voices.length,2);
 dom.window.dispatchEvent(new dom.window.Event('focus'));assert.equal(refreshes,1);
 [...doc.querySelectorAll('button')].find(b=>b.textContent==='导出全部音色到仓库').click();await Promise.resolve();
 assert.equal(saved.voices[1].voiceURI,'yue-unique');assert.match(doc.body.textContent,/report.json/);
 cleanup();dom.window.dispatchEvent(new dom.window.Event('focus'));assert.equal(refreshes,1);dom.window.close();
});
