import {t} from './i18n.js';
import {libraryTags,parseTags,renameTag} from './library-core.js';
import {mountReaderPopover} from './reader-popover.js';

export function orderedCollections(items,settings,includeHidden=false){
 const order=settings.libraryCollectionOrder||[],hidden=new Set(settings.libraryHiddenCollections||[]);
 return items.filter(x=>includeHidden||x.id==='all'||!hidden.has(x.id)).map((item,index)=>({item,index})).sort((a,b)=>{
  const rank=x=>order.includes(x.item.id)?order.indexOf(x.item.id):order.length+x.index;
  return rank(a)-rank(b);
 }).map(x=>x.item);
}

// Native buttons support touch and keyboard; ordering does not require dragging.
export function mountCollections(doc,host,{settings,getItems,save,pick,customize,onError=()=>{},onClose=()=>{}}){
 const details=doc.createElement('details');details.className='br-collections';
 const summary=doc.createElement('summary');summary.textContent=t('Collections');details.append(summary);
 const panel=doc.createElement('div');panel.className='br-collections-panel';details.append(panel);host.append(details);
 const dispose=mountReaderPopover(details,panel,t('Collections'));
 const head=doc.createElement('div');head.className='br-collections-heading';panel.append(head);
 const title=doc.createElement('strong');title.textContent=t('Collections');head.append(title);
 const edit=doc.createElement('button');edit.type='button';head.append(edit);
 const list=doc.createElement('div');list.className='br-collections-list';panel.append(list);
 const message=doc.createElement('p');message.className='br-collection-message';message.setAttribute('role','status');panel.append(message);
 const form=doc.createElement('form');form.className='br-collection-new';panel.append(form);
 const input=doc.createElement('input');input.placeholder=t('New collection');input.setAttribute('aria-label',t('New collection'));form.append(input);
 const add=doc.createElement('button');add.type='submit';add.textContent=t('Add');form.append(add);
 let editing=false,busy=false,dirty=false;
 const closed=()=>{if(!details.open&&dirty){dirty=false;onClose();}};details.addEventListener('toggle',closed);
 const run=async mutate=>{
  if(busy)return;busy=true;panel.setAttribute('aria-busy','true');
  const before=JSON.parse(JSON.stringify(settings));
  try{mutate();await save();dirty=true;message.textContent=t('Saved');}
  catch(e){for(const k of Object.keys(settings))delete settings[k];Object.assign(settings,before);message.textContent=t('Error: {0}',e.message);onError(e);}
  finally{busy=false;panel.removeAttribute('aria-busy');draw();}
 };
 const button=(row,label,action)=>{const b=doc.createElement('button');b.type='button';b.textContent=label;b.onclick=action;row.append(b);return b;};
 const draw=()=>{
  edit.textContent=t(editing?'Done':'Edit');edit.setAttribute('aria-pressed',String(editing));list.replaceChildren();
  const items=orderedCollections(getItems(),settings,editing);
  items.forEach((item,index)=>{
   const row=doc.createElement('div');row.className='br-collection-row';list.append(row);
   const hidden=(settings.libraryHiddenCollections||[]).includes(item.id);row.classList.toggle('is-hidden-collection',hidden);
   if(editing){
    const hide=button(row,t(hidden?'Show collection':'Hide collection'),()=>run(()=>{
     const set=new Set(settings.libraryHiddenCollections||[]);hidden?set.delete(item.id):set.add(item.id);settings.libraryHiddenCollections=[...set];
     if(settings.libCategory===item.id&&!hidden)settings.libCategory='all';
    }));hide.className='br-collection-visibility';hide.disabled=item.id==='all';
    const name=doc.createElement('input');name.value=item.label;name.setAttribute('aria-label',t('Collection name'));row.append(name);
    button(row,t('Rename'),()=>run(()=>{
     const value=name.value.trim();if(!value)throw Error(t('Collection name is required'));
     if(item.id.startsWith('tag:')){
      const old=item.id.slice(4);if(value!==old&&libraryTags(settings).includes(value))throw Error(t('A collection with this name already exists'));
      renameTag(settings,old,value);
      for(const key of ['libraryCollectionOrder','libraryHiddenCollections'])settings[key]=(settings[key]||[]).map(id=>id===item.id?'tag:'+value:id);
     }else{settings.libraryLabels??={};settings.libraryLabels[item.id]=value;}
    }));
    for(const [offset,label]of [[-1,'Move up'],[1,'Move down']]){
     const move=button(row,t(label),()=>run(()=>{const ids=items.map(x=>x.id);[ids[index],ids[index+offset]]=[ids[index+offset],ids[index]];settings.libraryCollectionOrder=ids;}));move.disabled=index+offset<0||index+offset>=items.length;
    }
   }else{
    const choose=button(row,item.label,()=>{details.open=false;pick(item.id);});choose.className='br-collection-pick';choose.setAttribute('aria-current',String(settings.libCategory===item.id));
    const count=doc.createElement('span');count.textContent=String(item.count??0);row.append(count);
    const chevron=doc.createElement('span');chevron.textContent='›';chevron.setAttribute('aria-hidden','true');row.append(chevron);
   }
  });
 };
 edit.onclick=()=>{editing=!editing;draw();};
 form.onsubmit=e=>{e.preventDefault();run(()=>{
  const names=parseTags(input.value);if(names.length!==1)throw Error(t('Enter one collection name'));
  if(libraryTags(settings).includes(names[0]))throw Error(t('A collection with this name already exists'));
  settings.libraryTagNames=[...libraryTags(settings),names[0]];input.value='';
 });};
 draw();return ()=>{details.removeEventListener('toggle',closed);dispose();details.remove();};
}
