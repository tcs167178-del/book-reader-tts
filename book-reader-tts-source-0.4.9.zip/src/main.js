import {mountCollections,orderedCollections} from './collections.js';
import {readingTick,readingViewActive} from './reading-time.js';
import {installReaderSync, mountSyncSettings} from './reader-sync-ui.js';
import {visibleBooks, setArchived, sortLibrary, libraryTags, moveLibraryMetadata} from './library-core.js';
import {openShelfSettings, openBookTags, openReadingInsights} from './library-settings.js';
import {t as __ertr, configureLocale, systemLocale, outputLanguage} from './i18n.js';
import {migrateReaderPreferences, bookNoteAction} from './reader-preferences.js';
import { mountReadingProgress, formatReadingTime } from "./reading-progress.js";
import { installBatchBooks } from "./batch-books.js";
import { mountReadingControls } from "./reading-controls.js";
import { mountSpeech } from "./tts.js";
/*
 * Book Reader TTS for Obsidian — plugin source.
 *
 * Read EPUB, FB2 and PDF books inside Obsidian, highlight passages and turn them
 * into notes. Everything below is the plugin's own code; the libraries it uses
 * (pdf.js, epub.js, JSZip, localForage) come from npm and are bundled at build
 * time by esbuild — see esbuild.config.mjs.
 */
import { AbstractInputSuggest, FuzzySuggestModal, ItemView, MarkdownRenderer, Menu, Modal, Notice, Platform, Plugin, PluginSettingTab, Scope, Setting, TFile, TFolder, getLanguage, normalizePath, requestUrl } from "obsidian";
import * as pdfjsLib from "pdfjs-dist";
import ePub from "epubjs";

// English interface strings with positional placeholders.
configureLocale(() => getLanguage());

const VIEW_TYPE = "book-reader-tts-view";
const DEFAULT = {
  // Interface language: "auto" (default) or "en".
  language: "en",
  booksFolder: "",
  // ── Notes created from selections / highlights ────────────────────────────
  // Templater template applied to every new note ("" = create without a
  // template, just the quoted selection). Point this at your own template.
  noteTemplate: "",
  // Folder new notes are created in ("" = vault root).
  notesFolder: "",
  // Folder whose notes appear in the per-book "link to note" picker ("" = all).
  bookNotesFolder: "",
  // Opt-in: on a book's first open, automatically create a dedicated note named
  // after the book (in the book-notes folder, else the notes folder) and link it,
  // so every book gets its own note without manual picking. Requested by readers.
  autoBookNote: false,
  /* Append highlights to the book note independently of automatic note creation; this also supports notes created with QuickAdd templates. */
  quotesToBookNote: false,
  // Where reading data (progress, highlights, rescue backups) is stored.
  // "" = next to the books (the booksFolder). Set it to keep data in one place
  // regardless of where the books live.
  dataFolder: "Book Reader TTS TTS Data",
  // Per-book template override, keyed by book path → template path. Lets a
  // given book (or genre) use a different note template than the global one.
  bookTemplates: {},
  // Keep highlight colours when exporting: wraps each quote in a coloured
  // <mark> (renders in vanilla Obsidian). Off = plain quotes without colour.
  exportColors: true,
  /* Match Obsidian appearance, including dark themes, by default. */
  theme: "auto",
  /* Keep library appearance separate from the page theme; reader mode uses the book theme. */
  libTheme: "auto",
  fontSize: 18,
  fontFamily: "georgia",
  lineHeight: 1.8,
  columns: "2",
  // Text alignment inside the reading column: "left" (default), "justify",
  // "center" or "right". Requested by readers who prefer a specific alignment.
  textAlign: "left",
  // Where a SHORT page sits vertically: "top" (default), "center" or "bottom".
  // The end of a chapter often fills only part of the page, leaving the text
  // stranded at the top with a large empty band underneath.
  vAlign: "top",
  // Opt-in: adds a "translate" button to the selection popup. Off by default
  // because translating sends the SELECTED FRAGMENT to Google's public endpoint —
  // that has to be a deliberate choice, never a surprise.
  translateEnabled: false,
  // Target language for that button (ISO code Google Translate understands).
  translateTo: "auto",
  // Per-book override for the backlink inserted into notes created from a
  // selection. Keyed by the book file's path → the note name to link to.
  // Empty/unset → fall back to the book file's own name.
  bookNoteLinks: {},
  // Books we've already shown the "pick a book note" prompt for (keyed by path),
  // so first-open asks once and never nags again.
  bookNotePrompted: {},
  // Per-book cover display mode in the library, keyed by path → "contain".
  // Default (no entry) = "cover" (fills the card, may crop). "contain" shows the
  // WHOLE cover in proportion over a soft blurred backdrop.
  coverFits: {},
  // How the user syncs their vault between devices. Progress & highlights are
  // stored AS FILES inside the vault, so they ride whatever sync is in use —
  // this is mostly informational + tunes how aggressively we re-read on open.
  syncMode: "auto",
  // Opt-in: on PDF pages that have BOTH a picture and extractable text, also show
  // the page artwork above the text. Off by default — by default an image is only
  // shown when the page's text can't be extracted (scans, full-page figures), so
  // there is never a screenshot duplicating text you can already read.
  // Pictures on pages that also have text. Was off by default on the theory that
  // people want clean text — but a subscriber had to open illustrated books in a
  // different reader to see whether they contained pictures at all, which is a
  // much worse failure than an occasional redundant image.
  pdfShowFiguresOnTextPages: true,
  // Library cover size = the grid column width in px (cards scale with it). The
  // user can change it live with the −/+ control in the library header.
  libCoverSize: 176,
  // Last category chip picked in the library ("all", "status:reading",
  // "folder:<name>", "tag:<name>"), so it survives reopening.
  libCategory: "all",
  /* Remember whether Advanced settings is expanded; keep frequently used controls visible by default. */
  readerAdvOpen: false,
  readerHistOpen: false,
  askNoteTitle: false,
  shortNoteTitles: true,
  // Colour used when a comment has to create the highlight it hangs on.
  defaultHlColor: "yellow",
  /* User categories are stored by book path, for example Psychology, without moving files on disk. */
  bookTags: {},
  // How pages are turned. "buttons" = the ← → arrows / keys / swipe (default).
  // "click" = tap/click the left or right side of the page to turn it (the
  // middle stays neutral so you can still select text / dismiss popups).
  navMode: "buttons",
  // Daily reading-goal timer. Counts active reading time (pauses when you're
  // idle or the book isn't focused) and shows a progress bar toward the goal.
  timerEnabled: true,
  dailyGoalMin: 15,
  // Accumulated reading seconds per day: { "YYYY-MM-DD": seconds }. Kept to the
  // last ~90 days. Local (in data.json) — a personal habit log, not synced.
  readingLog: {},
  // Untrimmed lifetime reading total (seconds). readingLog is capped to ~90 days,
  // so this separate counter is what powers the honest "all-time" total shown to
  // readers who asked to see cumulative reading time.
  lifetimeSeconds: 0,
  // Content-first "immersive" chrome: the top/bottom bars gently dim after a few
  // seconds of no pointer movement, and brighten the instant you move again.
  immersive: true,
  /* Manual mobile top inset in pixels; zero uses the system status-bar inset. */
  mobileTopInset: 0,
  // Set to true once the first-run welcome slideshow has been shown, so it never
  // pops up again on its own (can still be re-opened from Settings).
  onboarded: false,
  // Set once the stale "already asked" flags from older builds have been cleaned
  // up (see loadAll). Without this the repair would run on every start.
  promptedRepaired: false,
  figuresShownByDefault: false,
  einkMode: false,
  // Keep the LOOK of the reader separate on each kind of device (see
  // DEVICE_KEYS). Off = one shared appearance everywhere, as before.
  // Where a note made from a highlight opens: "split" beside the book (default,
  // so the book stays on screen), "tab" in a new tab, "none" don't open it.
  // ── AI passage breakdown ──────────────────────────────────────────────────
  // Off by default and stays off until the reader sets it up: it sends the
  // selected passage to whichever service they choose, and that has to be a
  // decision, never a surprise.
  aiEnabled: false,
  aiProvider: "eltonlabs",
  aiKey: "",
  aiModel: "",
  aiBase: "",
  aiInto: "auto",
  // Empty means the built-in instruction. A reader who wants a different kind
  // of answer writes their own here instead of getting the four fixed sections.
  aiSystem: "",
  // Put a link back to the exact paragraph under every exported quote.
  // "pages" (default) or "scroll": one long column the reader scrolls.
  // Set once the reader has chosen a language by hand; until then the plugin
  // follows whatever language Obsidian itself is in.
  languagePicked: false,
  readMode: "pages",
  // Does a page slide when turned? On, and NOT derived from the system's
  // "reduce animations" preference.
  //
  // That preference is respected everywhere it belongs — the card cascade, the
  // pill sliding in, buttons shrinking under a press all stop. But the page
  // turn is not decoration: the slide is what tells you the book moved and in
  // which direction, the same category as a scrollbar moving when you scroll.
  // Deriving it from the OS meant anyone who had switched animations off in
  // Windows — a common thing to do, for reasons that have nothing to do with
  // reading — opened a book that turned pages by teleporting.
  pageTurnAnimation: true,
  // Copy the reading percentage into the book note's frontmatter, so it can be
  // charted and sorted in Bases. Off by default: it writes to a note the reader
  // owns, and that should be asked for.
  progressToFrontmatter: false,
  // How a copied quote is shaped. Placeholders: {text} {book} {page} {link} {comment}
  quoteTemplate: "",
  quoteBacklinks: true,
  /* Custom backlink label; empty uses the interface default. */
  quoteBacklinkLabel: "",
  noteOpenMode: "none",
  // Widest a single reading column may get, in characters. A full-width column
  // on a wide monitor runs to 150+ characters, and the eye loses the start of
  // the next line — typography puts the comfortable range at 60-90. 0 = off,
  // fill the whole column as before. Extra width becomes side margin, so the
  // page geometry (and therefore the paging stride) is untouched.
  maxLineCh: 0,
  // Put notes made from a book's highlights in the SAME folder as the book,
  // instead of the shared notes folder. Off = the folder setting decides.
  notesNextToBook: false,
  perDevice: false,
  // { desktop: {...}, tablet: {...}, phone: {...} } — only the appearance keys.
  deviceProfiles: {},
  // Plugin version the reader last saw the "what's new" screen for. Drives the
  // post-update summary; empty on an existing install means "never tracked", and
  // the full history is shown once so the jump isn't silent.
  lastSeenVersion: "",
  /* Save release notes in the vault after an update. */
  whatsNewNote: true
};
const THEMES = {
  /* Use Obsidian CSS variables so book and library colors follow theme changes immediately. */
  auto: {
    bg: "var(--background-primary)",
    text: "var(--text-normal)",
    ui: "var(--background-secondary)",
    border: "var(--background-modifier-border)",
    accent: "var(--interactive-accent)",
    muted: "var(--text-muted)",
  },
  // Maximum contrast, no tinting: anything softer turns to mush on an e-ink panel.
  eink: { bg: "#ffffff", text: "#000000", ui: "#ffffff", border: "#000000", accent: "#000000", muted: "#444444" },
  dark: { bg: "#12121a", text: "#ddd8f0", ui: "#1c1c2a", border: "#2e2e45", accent: "#7c6af7", muted: "#6a6880" },
  light: { bg: "#faf8f3", text: "#1a1a2e", ui: "#f0ede5", border: "#ddd9ce", accent: "#5548d9", muted: "#8a8678" },
  sepia: { bg: "#f5efe3", text: "#2c2416", ui: "#ece4d2", border: "#cfc4a8", accent: "#8B6914", muted: "#9a8a68" }
};
/* Resolve colors centrally: e-ink overrides the selected theme; unknown themes fall back to Obsidian. Library colors remain independent. */
function erLibTheme(settings) {
  const s = settings || {};
  const mode = s.libTheme || "auto";
  if (mode === "reader") return erTheme(s);
  if (s.einkMode === true) return THEMES.eink;
  return THEMES[mode] || THEMES.auto;
}
function erTheme(settings) {
  const s = settings || {};
  if (s.einkMode === true) return THEMES.eink;
  return THEMES[s.theme] || THEMES.auto;
}
const FONTS = {
  georgia: "Georgia,'Times New Roman',serif",
  lora: "'Lora',Georgia,serif",
  inter: "'Inter',system-ui,sans-serif"
};
/* Translucent highlight colors remain readable across themes. */
const HL_COLORS = [
  { id: "yellow", name: __ertr("Yellow"), css: "rgba(255,206,64,.45)" },
  { id: "green", name: __ertr("Green"), css: "rgba(118,214,108,.42)" },
  { id: "blue", name: __ertr("Blue"), css: "rgba(96,165,250,.42)" },
  { id: "pink", name: __ertr("Pink"), css: "rgba(248,123,168,.42)" }
];
function hlColorCss(id) {
  const c = HL_COLORS.find((x) => x.id === id);
  return c ? c.css : HL_COLORS[0].css;
}
// Every user-supplied or constructed vault path goes through here.
//
// normalizePath() is the Obsidian API's canonicaliser (and what plugin review
// expects on user paths): it turns a hand-typed "0. Files\Books//" into
// "0. Files/Books", so Windows-style backslashes finally just work instead of
// silently pointing nowhere.
//
// The wrapper exists for one reason: normalizePath("") returns "/", while this
// plugin uses "" to mean "not set" (→ vault root / next to the books). Passing
// its "/" onward would make every "if (folder)" check think a folder WAS set.
// So empty stays empty, in both directions.
function erPath(p) {
  const s = String(p == null ? "" : p).trim();
  if (!s) return "";
  try {
    const n = normalizePath(s);
    return n === "/" ? "" : n;
  } catch {
    // Older API surface / unexpected input: fall back to the old hand-rolled trim.
    return s.replace(/\\/g, "/").replace(/\/+/g, "/").replace(/^\/+|\/+$/g, "");
  }
}
// ── Which window are we actually in? ────────────────────────────────────────
// Obsidian can move a leaf into a separate OS window, and that window has its
// own document with its OWN selection. `window.getSelection()` therefore comes
// back empty whenever the reader is living in a popout — which is why selecting
// text there produced no colour palette, and why the reader looked broken in a
// detached window while working fine in a tab.
//
// These take the element whose window we mean, rather than reading the global
// `activeDocument`: that one follows keyboard focus, so it can legitimately
// answer with one document when a listener is added and a different one when
// it is removed, leaking the listener.
// A missing element falls back to the main window, i.e. to the old behaviour.
// ── Per-device appearance ───────────────────────────────────────────────────
// data.json travels with the vault, so one font size was shared by the phone,
// the tablet and the desktop. What reads comfortably on a 27" monitor is tiny
// on a tablet and enormous on a phone, and readers were re-adjusting the size
// every time they switched device.
//
// Only the LOOK is per device. Folders, templates, highlight colours and
// reading progress stay shared — those are decisions about the vault, not about
// the screen you happen to be holding.
const DEVICE_KEYS = ["theme", "fontSize", "fontFamily", "lineHeight", "columns", "textAlign", "vAlign", "einkMode"];
function erDeviceKey() {
  try {
    if (Platform) {
      if (Platform.isPhone) return "phone";
      if (Platform.isTablet) return "tablet";
    }
  } catch { /* optional step; a failure here must not interrupt reading */ }
  return "desktop";
}
// Load this device's saved look over the shared defaults. A key the device has
// never set is left alone, so turning the option on inherits what is on screen
// now rather than resetting the book to factory settings mid-sentence.
function applyDeviceProfile(settings) {
  if (!settings || !settings.perDevice) return;
  const p = (settings.deviceProfiles || {})[erDeviceKey()];
  if (!p) return;
  for (const k of DEVICE_KEYS) if (p[k] !== void 0) settings[k] = p[k];
}
// Stash the live look back into this device's slot on the way to disk. Done at
// save time rather than at each of the ~35 places that read or write a font
// size, so the reader's own code is untouched and there is one place to check.
function captureDeviceProfile(settings) {
  if (!settings || !settings.perDevice) return;
  if (!settings.deviceProfiles) settings.deviceProfiles = {};
  const key = erDeviceKey();
  const p = settings.deviceProfiles[key] || (settings.deviceProfiles[key] = {});
  for (const k of DEVICE_KEYS) p[k] = settings[k];
}
// Put one of our own icons into an element as real SVG nodes.
//
// This was `el.innerHTML = icon(name)` in about forty places. The markup is a
// constant of ours, so nothing could actually be injected through it, but
// assigning innerHTML at all is what a reviewer greps for — and it is one
// careless edit away from being handed something that isn't a constant.
// Parsing instead of assigning removes the question entirely.
function svgIcon(el, name) {
  if (!el) return el;
  el.empty();
  try {
    let markup = icon(name);
    if (!markup) return el;
    // The icons are written as plain `<svg viewBox=…>` with no xmlns, which is
    // fine in HTML but NOT as XML: parsed as image/svg+xml without a namespace
    // the element lands outside the SVG namespace and the browser draws nothing.
    // Every button in the reader came out blank.
    if (!/\sxmlns=/.test(markup)) {
      markup = markup.replace("<svg", '<svg xmlns="http://www.w3.org/2000/svg"');
    }
    const parsed = new DOMParser().parseFromString(markup, "image/svg+xml");
    // A parse failure yields a <parsererror> document instead of throwing.
    if (parsed.getElementsByTagName("parsererror").length) return el;
    const svg = parsed.documentElement;
    if (svg && String(svg.nodeName).toLowerCase() === "svg") {
      el.appendChild(docOf(el).importNode(svg, true));
    }
  } catch { /* an icon is decoration; never let it break the reader */ }
  return el;
}
// Icon followed by a text label — the other shape the old innerHTML calls took.
function iconLabel(el, name, text) {
  svgIcon(el, name);
  el.createSpan({ text });
  return el;
}
// Show the book only once the layout has stopped moving.
//
// "It jumps between two pages when it opens" has been reported four times, and
// every mechanism I found and fixed was real but not the last one. So this stops
// hunting and makes the symptom impossible instead: the curtain (er-booting)
// comes up when the book is built and comes down only after the page area has
// held the same width for a beat. Anything that re-flows in that window — the
// dialog settling, the keyboard leaving, a rotation landing — happens behind it.
// Every call re-arms, so a re-flow that starts late just holds the curtain
// longer rather than revealing a half-finished page.
//
// The cost is a fifth of a second before the text appears. That is worth it: the
// reader sees the page they left, once, instead of watching it change.
const ER_SETTLE_MS = 200;
function erRevealWhenSettled(view) {
  const area = view.areaEl;
  if (!area) return;
  const win = winOf(area);
  win.clearTimeout(view._revealT);
  const width = () => (view.areaEl ? view.areaEl.clientWidth : 0);
  let last = width();
  const check = () => {
    if (!view.areaEl) return;
    const now = width();
    // Still moving — wait for it to settle rather than reveal mid-flight.
    if (now !== last) { last = now; view._revealT = win.setTimeout(check, ER_SETTLE_MS); return; }
    view.areaEl.removeClass("er-booting");
    erHideVeil(view);
  };
  view._revealT = win.setTimeout(check, ER_SETTLE_MS);
}
/* Use the Custom Highlight API for paginated mobile text selections without changing their DOM. Native selection painting handles scrolling mode. */
const ER_SEL_HL = "er-selection";
function erPaintSelection(view, range) {
  try {
    if (!erIsMobile(view.app)) return;
    if (view.pager && view.pager.scrollMode) return;
    if (typeof CSS === "undefined" || !CSS.highlights || typeof Highlight !== "function") return;
    CSS.highlights.set(ER_SEL_HL, new Highlight(range.cloneRange()));
  } catch { /* decoration: never let it interrupt selecting */ }
}
function erClearPaintedSelection() {
  try { if (typeof CSS !== "undefined" && CSS.highlights) CSS.highlights.delete(ER_SEL_HL); }
  catch { /* nothing painted is a fine outcome */ }
}
function docOf(el) { return (el && el.ownerDocument) || document; }
function winOf(el) { return docOf(el).defaultView || window; }
function selOf(el) { return winOf(el).getSelection(); }
function icon(n) {
  let _a;
  const m = {
    "arrow-left": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>`,
    message: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 8.5 8.5 0 0 1-3.8-.9L3 21l2-4.2a8.4 8.4 0 0 1-1-4.3 8.4 8.4 0 0 1 8.4-8.4 8.4 8.4 0 0 1 8.6 7.4z"/></svg>`,
    "list": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>`,
    "sliders": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>`,
    "chevron-left": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>`,
    "chevron-right": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>`,
    "refresh": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>`,
    "highlighter": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l-6 6v3h3l6-6"/><path d="M22 12l-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4l8 8z"/></svg>`,
    "trash": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
    "note": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg>`,
    "save": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>`,
    "download": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
    "info": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
    "more": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>`,
    "search": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
    "cover-fit": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/></svg>`,
    "cover-fill": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>`,
    // Outline, like every other icon in the selection popup — it was the only
    // filled one, which is why that row looked mismatched.
    "bookmark": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>`,
    "copy": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
    "translate": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h7M9 3v2c0 4.4-2.2 7-5 8"/><path d="M5 9c0 2.5 2.5 4.5 6 6"/><path d="M12.5 20l4.2-9.5L21 20M14.3 16.2h4.8"/></svg>`,
    "text-quote": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 6H3M21 12H8M21 18H8M3 12v6"/></svg>`,
    "folder-open": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 14l1.5-3.5A2 2 0 0 1 9.3 9H21l-2.6 6.2A2 2 0 0 1 16.6 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4l2 3h6a2 2 0 0 1 2 2v1"/></svg>`,
    "close": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>`,
    // Paper plane: the one icon every chat in the world uses for "send",
    // so nobody has to work out what the round button does.
    "send": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/></svg>`,
    "sparkles": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.9 4.6L18.5 9.5 13.9 11.4 12 16l-1.9-4.6L5.5 9.5l4.6-1.9z"/><path d="M18 15l.8 2L21 17.8l-2.2.8-.8 2-.8-2-2.2-.8 2.2-.8z"/></svg>`,
    "play": `<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M7 4.5v15a1 1 0 0 0 1.53.85l12-7.5a1 1 0 0 0 0-1.7l-12-7.5A1 1 0 0 0 7 4.5z"/></svg>`,
    "pause": `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="6" y="4.5" width="4.2" height="15" rx="1.4"/><rect x="13.8" y="4.5" width="4.2" height="15" rx="1.4"/></svg>`,
    "check": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>`,
    "rotate-ccw": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>`,
    "more-horizontal": `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><circle cx="5" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="19" cy="12" r="1.7"/></svg>`,
    "x": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    "plus": `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`
  };
  return (_a = m[n]) != null ? _a : "";
}
// ── Reading-goal timer + click-to-turn helpers ────────────────────────────────
// Shared by both readers (the desktop ItemView and the mobile full-screen Modal),
// which each expose `plugin`, `areaEl`, `bookHtml`, a nav method, and the goal-bar
// element refs. Keeping this as free functions avoids duplicating the logic twice.
// A page counts as "short" — worth centring — only when this much of it is empty.
// Below the threshold the page is essentially full and must stay put.
const SHORT_PAGE_GAP = 0.35;
// How long a search match stays painted before fading out by itself.
const FOUND_PAINT_MS = 4000;
/* Limit per-book commands to avoid flooding the command palette; use Open book for larger libraries. */
const MAX_BOOK_COMMANDS = 60;
function readerTodayKey() {
  try { return window.moment ? window.moment().format("YYYY-MM-DD") : new Date().toISOString().slice(0, 10); }
  catch { return new Date().toISOString().slice(0, 10); }
}
/* Reading statistics use a roughly 90-day log. Format long durations as hours and minutes; show a dash before any reading is logged. */
function fmtReadTime(sec) {
  const total = Math.max(0, Math.floor(sec || 0));
  if (total < 60) return total > 0 ? __ertr("less than a minute") : "—";
  const mins = Math.floor(total / 60);
  if (mins < 60) return __ertr("{0} min", mins);
  const h = Math.floor(mins / 60), m = mins % 60;
  if (h < 24) return m ? __ertr("{0} h {1} min", h, m) : __ertr("{0} h", h);
  const d = Math.floor(h / 24), rh = h % 24;
  return rh ? __ertr("{0} d {1} h", d, rh) : __ertr("{0} d", d);
}
// Shift a YYYY-MM-DD key by N days without touching the local timezone: parsing
// as UTC noon keeps DST changes from rolling the date backwards.
function shiftDayKey(key, delta) {
  const d = new Date(key + "T12:00:00Z");
  if (isNaN(d.getTime())) return key;
  d.setUTCDate(d.getUTCDate() + delta);
  return d.toISOString().slice(0, 10);
}
// Consecutive days with any reading, counting back from today. Reading yesterday
// but not yet today still counts as a live streak — otherwise the number would
// collapse to 0 every morning and feel punishing.
function readingStreak(log, todayKey) {
  if (!log) return 0;
  const hit = (k) => (log[k] || 0) > 0;
  let cur = todayKey;
  if (!hit(cur)) {
    cur = shiftDayKey(cur, -1);
    if (!hit(cur)) return 0;
  }
  let n = 0;
  while (hit(cur) && n < 4000) { n++; cur = shiftDayKey(cur, -1); }
  return n;
}
// Everything the stats card needs, in one pass.
function readingStats(log, lifetimeSeconds, todayKey) {
  const l = log || {};
  const keys = Object.keys(l);
  const logSum = keys.reduce((a, k) => a + (l[k] || 0), 0);
  const daysRead = keys.filter((k) => (l[k] || 0) > 0).length;
  let best = 0, bestDay = "";
  for (const k of keys) if ((l[k] || 0) > best) { best = l[k]; bestDay = k; }
  // Lifetime is untrimmed and wins, but never report less than the log proves.
  const total = Math.max(lifetimeSeconds || 0, logSum);
  const recent = [];
  for (let i = 13; i >= 0; i--) {
    const k = shiftDayKey(todayKey, -i);
    recent.push({ key: k, sec: l[k] || 0 });
  }
  return {
    total,
    today: l[todayKey] || 0,
    streak: readingStreak(l, todayKey),
    daysRead,
    best, bestDay,
    avgPerDay: daysRead ? Math.round(logSum / daysRead) : 0,
    recent,
  };
}
// Start on book open; manual pause remains available. Count only foreground time.
function startTimerSession(view) {
  if (view._timer) return;
  view._running = true;
  view._flushAcc = 0;
  view._readingTickAt=Date.now();
  view._timer = window.setInterval(() => {
    const now=Date.now(),elapsed=readingTick(view._readingTickAt,now,readingViewActive(view));view._readingTickAt=now;
    if(!elapsed)return;
    view.plugin.bumpReadingTime(elapsed);
    const totals=view.plugin.settings.bookReadingSeconds??={};totals[view.file.path]=(totals[view.file.path]||0)+elapsed;
    view._sessionSec = (view._sessionSec || 0) + elapsed;
    view._flushAcc = (view._flushAcc || 0) + 1;
    if (view._flushAcc >= 15) { view._flushAcc = 0; view.plugin.flushReadingTime(); }
    updateTimerBtn(view);
  }, 1e3);
  updateTimerBtn(view);
}
function pauseTimerSession(view) {
  if (view._timer) { window.clearInterval(view._timer); view._timer = null; }
  view._running = false;
  if (view.plugin) view.plugin.flushReadingTime();
  updateTimerBtn(view);
}
function toggleTimerSession(view) {
  view._running ? pauseTimerSession(view) : startTimerSession(view);
}
// Alias kept for the close hooks: stopping the reader just pauses + flushes.
function stopReadingTimer(view) { pauseTimerSession(view); }
function updateTimerBtn(view) { view._readingProgress?.updateTime(); }
// "Click to turn": a click on the left/right third of the page turns it. Returns
// true if it handled the click. Guards against images, highlights and active
// selections so those interactions keep working, and leaves the center neutral.
function handleAreaNavClick(view, e) {
  if ((view.plugin.settings.navMode || "buttons") !== "click") return false;
  // Not while scrolling. Tapping the side of the page to turn it fights a
  // scroller: a finger that stops moving reads as a tap, and the reader jumps a
  // screenful away from where they were reading. The stylesheet already said the
  // side zones are off in this mode; the code did not know.
  if (view.pager && view.pager.scrollMode) return false;
  if (e.target instanceof HTMLElement && e.target.closest("img,.er-hl,.er-hl-popup")) return false;
  const sel = selOf(view.areaEl);
  if (sel && !sel.isCollapsed && sel.toString().trim()) return false;
  const r = view.areaEl.getBoundingClientRect();
  if (!r.width) return false;
  const x = e.clientX - r.left;
  const goNext = () => view.nav ? view.nav("next") : view._nav("next");
  const goPrev = () => view.nav ? view.nav("prev") : view._nav("prev");
  if (x < r.width * 0.32) { goPrev(); return true; }
  if (x > r.width * 0.68) { goNext(); return true; }
  return false;
}
/* Shared navigation and daily-goal settings; put per-book editable fields in Advanced settings rather than the help dialog. */
function buildBookSettings(view, p) {
  if (!view.plugin || !view.file) return;
  // Forget just THIS book, so the setup screen can be tried again without
  // wiping every link in the vault (the settings tab has the "forget all"
  // version). Handy while setting a book up — and the only alternative used to
  // be renaming the file on disk.
  const resetRow = p.createDiv("er-pan-hint");
  const resetLink = resetRow.createSpan({ text: __ertr("Forget this book's settings") });
  resetLink.addClass("er-inline-link");
  resetLink.addEventListener("click", async () => {
    const s = view.plugin.settings;
    const path5 = view.file.path;
    if (s.bookNoteLinks) delete s.bookNoteLinks[path5];
    if (s.bookNotePrompted) delete s.bookNotePrompted[path5];
    if (s.bookTags) delete s.bookTags[path5];
    if (s.bookTemplates) delete s.bookTemplates[path5];
    await view.plugin.saveAll();
    new Notice(__ertr("Book settings cleared; your notes are preserved"));
  });
      p.createDiv("er-info-group").setText(__ertr("Book note for links"));
      const bnWrap = p.createDiv("er-info-booknote");
      const bnHint = bnWrap.createDiv("er-info-rowdesc");
      bnHint.setText(__ertr("Where the \"— from [[…]]\" link in highlight notes points. Empty — the book's file name."));
      bnHint.addClass("er-panel-hint");
      const bnInput = bnWrap.createEl("input", { type: "text" });
      bnInput.addClass("er-panel-input");
      bnInput.placeholder = view.file ? view.file.basename : __ertr("Open a book first…");
      bnInput.disabled = !view.file;
      if (view.file) {
        const map = view.plugin.settings.bookNoteLinks || {};
        bnInput.value = map[view.file.path] || "";
      }
      const saveBookNote = async () => {
        if (!view.file) return;
        if (!view.plugin.settings.bookNoteLinks) view.plugin.settings.bookNoteLinks = {};
        const v = bnInput.value.trim().replace(/^\[\[|\]\]$/g, "").trim();
        if (v) view.plugin.settings.bookNoteLinks[view.file.path] = v;
        else delete view.plugin.settings.bookNoteLinks[view.file.path];
        await view.plugin.saveAll();
        // Mirror it into the note, so the binding is visible in the vault.
        if (v) await writeBookProperty(view.app, v, view.file);
      };
      bnInput.addEventListener("change", saveBookNote);
      bnInput.addEventListener("blur", saveBookNote);
      // Two ways out, side by side — picking an existing note was the only one
      // before, which left readers stuck when the note didn't exist yet.
      const bnActions = bnWrap.createDiv("er-booknote-actions");
      bnActions.addClass("er-panel-actions");
      const bnNew = bnActions.createDiv("er-booknote-pick");
      bnNew.setText(__ertr("+ Create new"));
      bnNew.addClass("er-panel-link-strong");
      bnNew.addEventListener("click", async () => {
        if (!view.file) return;
        const folder = bookNotesFolderPath(view.app) || notesFolderPath(view.app) || "";
        const note = await view.plugin.createBookNote(view.file, view.file.basename, folder);
        if (note) {
          bnInput.value = note.basename;
          new Notice(__ertr("Book note created: {0}", note.basename));
        }
      });
      const bnPick = bnActions.createDiv("er-booknote-pick");
      bnPick.setText(__ertr("Choose from the list…"));
      bnPick.addClass("er-panel-link");
      bnPick.addEventListener("click", () => {
        if (!view.file) return;
        const files = bookNoteFiles(view.app);
        if (!files.length) { const bf = bookNotesFolderPath(view.app); new Notice(bf ? __ertr("No notes in \"{0}\"", (bf)) : __ertr("No notes in the vault")); return; }
        new BookNotePicker(view.app, files, async (chosen) => {
          if (!view.plugin.settings.bookNoteLinks) view.plugin.settings.bookNoteLinks = {};
          view.plugin.settings.bookNoteLinks[view.file.path] = chosen.basename;
          await view.plugin.saveAll();
          await writeBookProperty(view.app, chosen.basename, view.file);
          bnInput.value = chosen.basename;
          new Notice(__ertr("Book note: {0}", (chosen.basename)));
        }).open();
      });

      // ── Category (groups books in the library) ──────────────────────────────
      p.createDiv("er-info-group").setText(__ertr("Category"));
      const tgWrap = p.createDiv("er-info-booknote");
      const tgHint = tgWrap.createDiv("er-info-rowdesc");
      tgHint.setText(__ertr("Genre or topic — books are grouped by it in the library. Separate several with commas. Empty means no category."));
      tgHint.addClass("er-panel-hint");
      const tgInput = tgWrap.createEl("input", { type: "text" });
      tgInput.addClass("er-panel-input");
      tgInput.placeholder = __ertr("e.g. Psychology, Business");
      tgInput.disabled = !view.file;
      if (view.file) tgInput.value = bookTagsOf(view.plugin.settings, view.file.path).join(", ");
      const knownTags = allBookTags(view.plugin.settings);
      if (knownTags.length) {
        const dl = tgWrap.createEl("datalist");
        dl.id = "er-info-tags-" + Math.random().toString(36).slice(2, 8);
        knownTags.forEach((t) => dl.createEl("option", { value: t }));
        tgInput.setAttr("list", dl.id);
      }
      const saveTags = async () => {
        if (!view.file) return;
        await view.plugin.setBookTags(view.file.path, parseBookTags(tgInput.value));
      };
      tgInput.addEventListener("change", saveTags);
      tgInput.addEventListener("blur", saveTags);

      // ── Per-book template override ──────────────────────────────────────────
      p.createDiv("er-info-group").setText(__ertr("Template for this book"));
      const tpWrap = p.createDiv("er-info-booknote");
      const tpHint = tpWrap.createDiv("er-info-rowdesc");
      tpHint.setText(__ertr("A template just for this book (for example, per genre). Empty — the shared template from the plugin settings is used."));
      tpHint.addClass("er-panel-hint");
      const tpInput = tpWrap.createEl("input", { type: "text" });
      tpInput.addClass("er-panel-input");
      tpInput.placeholder = (view.plugin.settings.noteTemplate || "").trim() || __ertr("Templates/Template.md");
      tpInput.disabled = !view.file;
      if (view.file) {
        const tmap = view.plugin.settings.bookTemplates || {};
        tpInput.value = tmap[view.file.path] || "";
      }
      const saveBookTemplate = async () => {
        if (!view.file) return;
        if (!view.plugin.settings.bookTemplates) view.plugin.settings.bookTemplates = {};
        const v = tpInput.value.trim();
        if (v) view.plugin.settings.bookTemplates[view.file.path] = v;
        else delete view.plugin.settings.bookTemplates[view.file.path];
        await view.plugin.saveAll();
      };
      tpInput.addEventListener("change", saveBookTemplate);
      tpInput.addEventListener("blur", saveBookTemplate);
      const tpPick = tpWrap.createDiv("er-booknote-pick");
      tpPick.setText(__ertr("Choose from the list…"));
      tpPick.addClass("er-panel-link-spaced");
      tpPick.addEventListener("click", () => {
        if (!view.file) return;
        const files = view.app.vault.getMarkdownFiles();
        if (!files.length) { new Notice(__ertr("No notes in the vault")); return; }
        new TemplatePicker(view.app, files, async (chosen) => {
          if (!view.plugin.settings.bookTemplates) view.plugin.settings.bookTemplates = {};
          view.plugin.settings.bookTemplates[view.file.path] = chosen.path;
          await view.plugin.saveAll();
          tpInput.value = chosen.path;
          new Notice(__ertr("Book template: {0}", (chosen.basename)));
        }).open();
      });
}
/* Create a collapsible Advanced settings section; persist its open state using settingKey for both reader layouts. */
function panelSection(view, p, { label, emoji, settingKey, defaultOpen = false }) {
  const hdr = p.createDiv("er-pan-adv-hdr");
  if (emoji) hdr.createSpan({ cls: "er-pan-adv-ic", text: emoji });
  hdr.createSpan({ cls: "er-pan-adv-lbl", text: label });
  // Collapsed sections hide whether there is anything inside, so the header
  // carries a count that the section's own render fills in.
  const count = hdr.createSpan({ cls: "er-pan-adv-count" });
  const car = hdr.createSpan({ cls: "er-pan-adv-car", text: "›" });
  const wrap = p.createDiv("er-pan-adv");
  // The open/close animation needs exactly ONE child to size against.
  const body = wrap.createDiv("er-pan-adv-body");
  body._erCount = count;
  const stored = view.plugin.settings[settingKey];
  if (stored === void 0 ? defaultOpen : stored) {
    wrap.addClass("er-pan-adv-on");
    car.addClass("er-pan-adv-car-on");
  }
  hdr.addEventListener("click", async () => {
    const on = wrap.hasClass("er-pan-adv-on");
    wrap.toggleClass("er-pan-adv-on", !on);
    car.toggleClass("er-pan-adv-car-on", !on);
    view.plugin.settings[settingKey] = !on;
    // Local-only write: this is a UI preference, not reading data, so it must not
    // trigger the folder/progress machinery that saveAll() drives.
    await view.plugin._saveLocalData();
  });
  return body;
}
function buildReaderExtraSettings(view, p) {
  const s = view.plugin.settings;
  const sec = (l) => p.createDiv("er-pan-sec").setText(l);
  sec(__ertr("Page turning"));
  const navRow = p.createDiv("er-col-row");
  [["buttons", __ertr("Buttons")], ["click", __ertr("By click")]].forEach(([v, label]) => {
    const btn = navRow.createDiv("er-col-btn");
    btn.setText(label);
    if ((s.navMode || "buttons") === v) btn.addClass("active");
    btn.addEventListener("click", async () => {
      s.navMode = v;
      await view.plugin.saveAll();
      navRow.querySelectorAll(".er-col-btn").forEach((b) => b.removeClass("active"));
      btn.addClass("active");
      (view.contentEl || view.containerEl).classList.toggle("er-navclick", v === "click");
    });
  });
  p.createDiv("er-pan-hint").setText(__ertr("\"By click\": clicking the left part of the page goes back, the right part goes forward. The center stays free for selecting text."));
  sec(__ertr("Text alignment"));
  const alRow = p.createDiv("er-col-row");
  [["left", __ertr("Left")], ["justify", __ertr("Justify")], ["center", __ertr("Center")], ["right", __ertr("Right")]].forEach(([v, label]) => {
    const btn = alRow.createDiv("er-col-btn");
    btn.setText(label);
    if ((s.textAlign || "left") === v) btn.addClass("active");
    btn.addEventListener("click", async () => {
      s.textAlign = v;
      await view.plugin.saveAll();
      alRow.querySelectorAll(".er-col-btn").forEach((b) => b.removeClass("active"));
      btn.addClass("active");
      if (view.bookHtml && typeof view.repaginate === "function") await view.repaginate();
    });
  });
  sec(__ertr("Position on the page"));
  const vaRow = p.createDiv("er-col-row");
  [["top", __ertr("Top")], ["center", __ertr("Center")], ["bottom", __ertr("Bottom")]].forEach(([v, label]) => {
    const btn = vaRow.createDiv("er-col-btn");
    btn.setText(label);
    if ((s.vAlign || "top") === v) btn.addClass("active");
    btn.addEventListener("click", async () => {
      s.vAlign = v;
      await view.plugin.saveAll();
      vaRow.querySelectorAll(".er-col-btn").forEach((b) => b.removeClass("active"));
      btn.addClass("active");
      if (view.bookHtml && typeof view.repaginate === "function") await view.repaginate();
      else if (view.bookHtml && typeof view._repaginate === "function") await view._repaginate();
    });
  });
  p.createDiv("er-pan-hint").setText(__ertr("Where to place the text when a page isn't filled — at the end of a chapter, for instance."));
  buildBookSettings(view, p);
}
function escHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
// Copy text to the clipboard, with a fallback for older/mobile webviews where
// navigator.clipboard may be unavailable or blocked.
async function copyToClipboard(text) {
  if (!text) return false;
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch { /* optional step; a failure here must not interrupt reading */ }
  try {
    const ta = activeDocument.createElement("textarea");
    ta.value = text;
    ta.addClass("er-offscreen");
    activeDocument.body.appendChild(ta);
    ta.select();
    const ok = activeDocument.execCommand("copy");
    activeDocument.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}
// Open an image full-screen over everything (works on desktop and the mobile
// modal). Tap the image again to zoom to 100% (then pan); tap the backdrop, the
// ✕, or press Esc to close. Used for illustration pages that are too small to
// read inside a reading column.
function openImageLightbox(src, app, ownerEl) {
  if (!src) return;
  const doc = docOf(ownerEl);
  const ov = doc.createElement("div");
  ov.className = "er-lightbox";
  // Image is a direct flex child centered with margin:auto. Unlike
  // align-items/justify-content:center, margin:auto keeps the top-left edge
  // reachable when the (zoomed) image is larger than the screen, so you can
  // scroll to every part of it.
  const img = ov.createEl("img");
  img.src = src;
  const closeBtn = ov.createDiv("er-lightbox-close");
  closeBtn.setText("✕");
  const hint = ov.createDiv("er-lightbox-hint");
  hint.setText(__ertr("Tap the image to zoom · background or ✕ to close"));
  let closed = false;
  let scope = null;
  const remove = () => {
    if (closed) return;
    closed = true;
    if (scope && app && app.keymap) { try { app.keymap.popScope(scope); } catch { /* optional step; a failure here must not interrupt reading */ } }
    doc.removeEventListener("keydown", onKey, true);
    ov.remove();
  };
  const onKey = (e) => {
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); if (e.stopImmediatePropagation) e.stopImmediatePropagation(); remove(); }
  };
  // The ONLY reliable way to grab Esc before Obsidian closes the reader/leaf is
  // its own keymap: push a scope so this viewer becomes the active key handler;
  // the Escape handler returns false to stop the event going any further. The
  // capture-phase DOM listener is a belt-and-suspenders fallback.
  if (app && app.keymap && Scope) {
    try {
      scope = new Scope();
      scope.register([], "Escape", () => { remove(); return false; });
      app.keymap.pushScope(scope);
    } catch { scope = null; }
  }
  doc.addEventListener("keydown", onKey, true);
  closeBtn.addEventListener("click", (e) => { e.stopPropagation(); remove(); });
  ov.addEventListener("click", (e) => { if (e.target === ov) remove(); });
  img.addEventListener("click", (e) => { e.stopPropagation(); img.classList.toggle("er-lightbox-zoom"); });
  doc.body.appendChild(ov);
  window.requestAnimationFrame(() => ov.classList.add("er-lightbox-on"));
}
let workerReady = false;
// The pdf.js worker is embedded into this bundle at build time (esbuild replaces
// __PDF_WORKER_CODE__ with the full worker source — see esbuild.config.mjs). We
// hand it to pdf.js as an in-memory Blob URL, so PDFs work fully offline and there
// is no separate pdf.worker.js file to ship. That also makes the plugin installable
// via BRAT, which only downloads main.js / manifest.json / styles.css.
async function setupWorker(app) {
  if (workerReady)
    return;
  try {
    const code = __PDF_WORKER_CODE__;
    if (!code) throw new Error("embedded pdf.worker is empty");
    pdfjsLib.GlobalWorkerOptions.workerSrc = URL.createObjectURL(
      new Blob([code], { type: "application/javascript" })
    );
    workerReady = true;
    return;
  } catch (e) {
    /* The worker is bundled. Report initialization failures rather than downloading executable code from a CDN. */
    console.error("Book Reader TTS: failed to initialize the bundled pdf.worker", e);
    new Notice(__ertr("Could not prepare PDF reading. Please reinstall the plugin."));
  }
  workerReady = true;
}
const EltonReader = class extends Plugin {
  constructor() {
    super(...arguments);
    this.settings = { ...DEFAULT };
    this.progress = {};
    this.thumbCache = {};
    this.highlights = {};
    this.progressBackups = {};
  }
  async onload() {
    await this.loadAll();
    await installReaderSync(this);
    this.registerEvent(this.app.vault.on("rename", (file, oldPath) => {
      for(const map of ['bookArchives','bookTags','bookNoteLinks','bookNotePrompted','bookTemplates','coverFits']) {
        for(const path of Object.keys(this.settings[map]||{})) if(path===oldPath || path.startsWith(oldPath+'/')) moveLibraryMetadata(this.settings,path,file.path+path.slice(oldPath.length));
      }
      this._saveLocalData();
    }));
    installBatchBooks(this, async file => {
      let html, outline, lazy;
      const warnings=[];
      try {
        if(file.extension.toLowerCase()==='epub') { html=await extractEpub(file,this.app); warnings.push(__ertr("EPUB extraction may omit unreadable chapters; verify the table of contents against the original.")); }
        else if(file.extension.toLowerCase()==='fb2') html=await extractFb2(file,this.app);
        else { const result=await extractPdf(file,this.app,{...this.settings,pdfShowFiguresOnTextPages:false});html=result.html;outline=result.outline;lazy=result.lazy;warnings.push(__ertr("Only extractable PDF text is included. Scanned pages and figures are not summarized; OCR is not included.")); }
        const doc=new DOMParser().parseFromString(html,'text/html');
        const blocks=Array.from(doc.querySelectorAll('p,h1,h2,h3,h4,li')).filter(el=>!el.querySelector('p,li')).map(el=>(el.textContent||'').trim()).filter(Boolean);
        return {blocks,toc:buildTocItems(html,outline).map(item=>item.label),warnings};
      } finally { if(lazy?.destroy)await lazy.destroy(); }
    }, aiConfig);
    this.registerView(VIEW_TYPE, (leaf) => new ReaderView(leaf, this));
    this.registerView(LIB_VIEW_TYPE, (leaf) => new LibraryView(leaf, this));
    // Quote backlinks. A quote in a note carries an obsidian:// link back to the
    // exact paragraph it came from, so clicking it opens the book there. Using
    // the app's own URI scheme rather than something bespoke means the link
    // works from anywhere a link works — a note, the daily journal, a canvas.
    this.registerObsidianProtocolHandler("book-reader-tts", (params) => {
      // `block` for a quote, `page` for a note made from a scanned page — the
      // latter has no paragraph to anchor to.
      this.openBookAt(params.book || "", params.block, params.page);
    });
    // Test fork does not claim extensions from the original reader.
    // FB2 in its own try/catch for the same reason as PDF below: Obsidian has no
    // built-in handler for it, but another plugin might have claimed it, and that
    // must not take epub down with it.
    try { /* Open explicitly from the library. */ }
    catch (e) { console.warn("Elton Reader: could not register .fb2", e); }
    // Also open PDFs in the reader instead of Obsidian's built-in PDF viewer.
    // Separate call in try/catch: if some other plugin already claimed "pdf",
    // we still keep epub working and fall back to the right-click menu for PDFs.
    try { /* Open explicitly from the library. */ }
    catch (e) { console.warn(__ertr("Elton Reader: could not register .pdf, use right-click → Open in Elton Reader"), e); }
    this.addRibbonIcon(
      "book-open",
      __ertr("Book Reader TTS — Library"),
      () => this.openLibrary()
    );
    this.addCommand({
      id: "open-library",
      name: __ertr("Open library"),
      callback: () => this.openLibrary()
    });
    this.addCommand({
      id: "open-library-window",
      name: __ertr("Open the library in a separate window"),
      callback: () => this.openLibrary(true)
    });
    this.addCommand({
      id: "open-pdf-reader",
      // Obsidian already prefixes every command with the plugin's name in the
      // palette, so naming the plugin again read as "Book Reader TTS: Open PDF in
      // Book Reader TTS" \u2014 and the directory's rules call that out.
      name: __ertr("Open a PDF in the reader"),
      checkCallback: (checking) => {
        const f = this.app.workspace.getActiveFile();
        if ((f == null ? void 0 : f.extension) === "pdf") {
          if (!checking)
            this.openFile(f);
          return true;
        }
        return false;
      }
    });
    this.addCommand({
      id: "search-in-book",
      name: __ertr("Search the book"),
      checkCallback: (checking) => {
        const view = this.app.workspace.getActiveViewOfType(ReaderView);
        // Also reach the mobile reader, which is a Modal rather than a view.
        const target = (view && view.bookHtml) ? view : (this._openReaderModal || null);
        if (!(target && target.bookHtml)) return false;
        if (!checking) {
          // The two readers name the method differently.
          (target.togglePanel || target._togglePanel).call(target, "find");
          if (target._findInput) erAutoFocus(target._findInput, 80);
        }
        return true;
      }
    });
    this.addCommand({
      id: "save-position",
      name: __ertr("Save reading position"),
      checkCallback: (checking) => {
        const view = this.app.workspace.getActiveViewOfType(ReaderView);
        if (!(view && view.bookHtml && view.file)) return false;
        if (!checking) view.saveNow();
        return true;
      }
    });
    this.addCommand({
      id: "export-highlights",
      name: __ertr("Export highlights to notes"),
      checkCallback: (checking) => {
        const view = this.app.workspace.getActiveViewOfType(ReaderView);
        if (!(view && view.file)) return false;
        if (!checking) view.exportHighlights();
        return true;
      }
    });
    this.registerEvent(this.app.workspace.on("file-menu", (menu, file) => {
      if (file instanceof TFile && file.extension === "pdf")
        menu.addItem((item) => item.setTitle(__ertr("📖 Open in Book Reader TTS")).setIcon("book-open").onClick(() => this.openFile(file)));
    }));
    this.addSettingTab(new SettingsTab(this.app, this));
    this.addCommand({
      id: "show-onboarding",
      name: __ertr("Show welcome (onboarding)"),
      callback: () => new OnboardingModal(this.app, this).open()
    });
    // Jump straight back into whatever was open last — the single most common
    // intent, and it costs one keystroke instead of a trip through the library.
    this.addCommand({
      id: "continue-reading",
      name: __ertr("Continue reading (last book)"),
      checkCallback: (checking) => {
        const f = this.lastReadBookFile();
        if (!f) return false;
        if (!checking) this.openFile(f);
        return true;
      }
    });
    // Type-to-find over every book, for vaults where a command per book would
    // swamp the palette.
    this.addCommand({
      id: "open-book-picker",
      name: __ertr("Open a book…"),
      callback: () => new BookQuickOpen(this.app, this).open()
    });
    // One command per book, so a book can be given its own hotkey. Deferred: at
    // onload the vault index is still filling and getFiles() would miss books.
    this.app.workspace.onLayoutReady(() => {
      this.registerBookCommands();
      // Keep the list honest as books are added, renamed or deleted. Debounced —
      // a sync or a bulk import fires these events in bursts.
      const refresh = () => {
        window.clearTimeout(this._bookCmdTimer);
        this._bookCmdTimer = window.setTimeout(() => this.registerBookCommands(), 1500);
      };
      for (const ev of ["create", "delete", "rename"]) {
        this.registerEvent(this.app.vault.on(ev, (f) => {
          if (f && /^(epub|fb2|pdf)$/.test(f.extension || "")) refresh();
        }));
      }
    });
    // Startup stays quiet; help and release notes remain available in settings.
    this.settings.onboarded = true;
    this.settings.lastSeenVersion = this.manifest.version;
    await this._saveLocalData();
  }
  async openFile(file) {
    // A dialog on the phone, a tab everywhere else — and the dialog is not a
    // workaround, it is the only shape that works.
    //
    // I tried a leaf here, because the library became one and it fixed the
    // library. On a phone the book came out worse, and for reasons a leaf cannot
    // avoid: Obsidian floats its own header buttons over the top of the content
    // (straight across the reader's title bar and the clock) and puts the mobile
    // navbar over the bottom of it (straight across the page counter). Worse,
    // the workspace keeps the gestures — a swipe left opens the file sidebar
    // instead of turning the page, and a pull down fires the quick action. There
    // is no plugin API to take a gesture back; the request for one is still open
    // on the forum. A modal sits above the workspace and keeps its own touches,
    // which is exactly what a book needs.
    if (this.app.isMobile) {
      new ReaderModal(this.app, this, file).open();
      return;
    }
    const leaves = this.app.workspace.getLeavesOfType(VIEW_TYPE);
    const leaf = leaves.length > 0 ? leaves[0] : this.app.workspace.getLeaf("tab");
    await leaf.setViewState({ type: VIEW_TYPE, state: { path: file.path }, active: true });
    this.app.workspace.revealLeaf(leaf);
  }
  // Open the library. As a tab by default, so it can be docked, split, resized
  // and dragged out into its own window like anything else in Obsidian; in a
  // separate window straight away when asked.
  //
  // On a phone there are no windows and tabs are cramped, so the full-screen
  // dialog stays the right shape there.
  async openLibrary(inNewWindow = false) {
    // A tab on the phone too, not a dialog.
    //
    // As a dialog the library had to fight the platform for every edge: the
    // modal container is positioned against the screen, so the header ran under
    // the status-bar clock, Obsidian's ✕ landed in the same strip at the far
    // corner from a thumb, and the mobile build's own padding showed as bands
    // down both sides. Three rounds of arithmetic went into that and none of it
    // held. As a leaf none of it is ours: Obsidian draws the header, keeps the
    // safe area and provides the way back, exactly as it does for every other
    // plugin's mobile interface. The view already existed for the desktop.
    // Already open somewhere? Go to it instead of opening a second copy.
    const existing = this.app.workspace.getLeavesOfType(LIB_VIEW_TYPE);
    if (existing.length && !inNewWindow) {
      this.app.workspace.revealLeaf(existing[0]);
      return;
    }
    const leaf = inNewWindow && !this.app.isMobile && this.app.workspace.openPopoutLeaf
      ? this.app.workspace.openPopoutLeaf()
      : this.app.workspace.getLeaf("tab");
    await leaf.setViewState({ type: LIB_VIEW_TYPE, active: true });
    this.app.workspace.revealLeaf(leaf);
  }
  // Open a book AND land on a particular paragraph. This is what a quote's
  // backlink resolves to: readers asked to click a quote in their notes and
  // arrive at the page it came from, the way a PDF annotation plugin does.
  //
  // The paragraph index is the same anchor reading progress uses, so it travels
  // between devices and survives a different font size or column count.
  async openBookAt(path, block, page) {
    const file = this.app.vault.getAbstractFileByPath(erPath(path));
    if (!(file instanceof TFile)) {
      new Notice(__ertr("Book not found: {0}", path));
      return;
    }
    await this.openFile(file);
    let idx = Number(block);
    if (!Number.isFinite(idx) || idx < 0) {
      // No paragraph anchor — this came from a scanned page, which carries a
      // page number instead. Resolve it to the first block of that page.
      const pg = Number(page);
      if (!Number.isFinite(pg) || pg < 1) return;
      for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
        const view = leaf.view;
        if (view && typeof view.jumpToPdfPageWhenReady === "function") {
          view.jumpToPdfPageWhenReady(pg);
          return;
        }
      }
      return;
    }
    // The book is still being laid out at this point; the view exposes the jump
    // so it can be applied once the text exists.
    for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
      const view = leaf.view;
      if (view && typeof view.jumpToBlockWhenReady === "function") {
        view.jumpToBlockWhenReady(idx);
        return;
      }
    }
  }
  // Folder that holds reading data (progress / highlights / rescue backups):
  // the dedicated "dataFolder" if set, otherwise next to the books (booksFolder).
  _dataFolder() {
    const dedicated = erPath(this.settings.dataFolder);
    if (dedicated) return dedicated;
    return erPath(this.settings.booksFolder);
  }
  // Returns the vault path for the progress JSON file.
  _progressFilePath() {
    const folder = this._dataFolder();
    return erPath(folder ? `${folder}/tts-reader-progress.json` : "tts-reader-progress.json");
  }
  async loadAll() {
    let _a, _b, _c;
    const d = await this.loadData();
    this.settings = { ...DEFAULT, ...(_a = d == null ? void 0 : d.settings) != null ? _a : {} };
    // Overlay whatever THIS device last looked like (no-op unless enabled).
    applyDeviceProfile(this.settings);
    // An older install may carry a null here from a build that derived this
    // from the system preference; treat it as on, which is the default now.
    if (this.settings.pageTurnAnimation === null || this.settings.pageTurnAnimation === void 0) {
      this.settings.pageTurnAnimation = true;
    }
    // This fork uses English for the upstream interface.
    migrateReaderPreferences(this.settings);
    // Bump THUMB_VER whenever the thumbnail renderer changes so old (blurry)
    // covers are regenerated once at the new quality instead of lingering.
    // Cover thumbnails live in their OWN local file (thumb-cache.json), kept out
    // of data.json so the synced settings stay tiny and conflict-free. On the
    // first run after this change, migrate the old cache out of data.json.
    await this._loadThumbCache(d);
    this.progressBackups = (d == null ? void 0 : d.progressBackups) != null ? d.progressBackups : {};
    this.highlightsBackups = (d == null ? void 0 : d.highlightsBackups) != null ? d.highlightsBackups : {};
    // Remember the last book's folder across restarts so rescue backups land
    // next to the books even before a book is opened in this session.
    this._lastBookPath = (d == null ? void 0 : d.lastBookPath) || "";
    // Load progress from vault file (syncs via Obsidian Sync)
    this.progress = await this._loadProgressFromVault();
    // Highlights live next to progress so they also sync via Obsidian Sync
    this.highlights = await this._loadHighlightsFromVault();
    // One-time repair. Older builds set "already asked about this book" BEFORE
    // the reader answered — and back then the prompt couldn't create a note at
    // all, and gave up silently when no book-notes folder was configured. Those
    // books can therefore never show the setup screen again, even though the
    // reader was never actually offered anything. Clear the flag wherever no note
    // was linked, so the fixed flow gets exactly one chance. Books that DO have a
    // note are left alone, and from now on the flag is only set on a real answer.
    if (!this.settings.promptedRepaired) {
      const asked = this.settings.bookNotePrompted || {};
      const links = this.settings.bookNoteLinks || {};
      let freed = 0;
      for (const k of Object.keys(asked)) if (!links[k]) { delete asked[k]; freed++; }
      this.settings.promptedRepaired = true;
      // Previously logged how many books were repaired. It ran once per install
      // and told the reader nothing they could act on, so it only added noise to
      // a console other plugins have to share.
      await this._saveLocalData();
    }
    // One-time migration: turn pictures on for everyone who never chose to hide
    // them. The setting shipped defaulting to OFF, so every existing install has
    // `false` written into data.json without anyone having decided that — and the
    // symptom (illustrated books silently showing no pictures) reads as a bug,
    // not a preference. Runs once; anyone who switches it off afterwards keeps it.
    if (!this.settings.figuresShownByDefault) {
      this.settings.pdfShowFiguresOnTextPages = true;
      this.settings.figuresShownByDefault = true;
      await this._saveLocalData();
    }
    // One-time migration: if old data.json had progress, move it to vault file
    const oldProgress = (_b = d == null ? void 0 : d.progress) != null ? _b : {};
    if (Object.keys(oldProgress).length > 0 && Object.keys(this.progress).length === 0) {
      this.progress = oldProgress;
      await this._saveProgressToVault();
      // Remove from data.json to avoid future confusion
      await this._saveLocalData();
    }
  }
  async saveAll() {
    await this._saveLocalData();
    await this._saveProgressToVault();
  }
  _saveLocalData() {
    captureDeviceProfile(this.settings);
    this.readerSync?.schedule();
    return this.saveData({ settings: this.settings, progressBackups: this.progressBackups, highlightsBackups: this.highlightsBackups, lastBookPath: this._lastBookPath || "" });
  }
  // ── Cover thumbnail cache (separate, device-local, NOT synced) ─────────────
  _thumbCachePath() { return erPath(`${this.manifest.dir}/thumb-cache.json`); }
  async _loadThumbCache(d) {
    try {
      const p = this._thumbCachePath();
      if (await this.app.vault.adapter.exists(p)) {
        const j = JSON.parse(await this.app.vault.adapter.read(p));
        this.thumbCache = (j && j.ver === 2 && j.cache) ? j.cache : {};
        return;
      }
    } catch (e) { console.warn("Book Reader TTS: thumb cache load failed", e); }
    // Migrate the old in-data.json cache once, then persist to the new file.
    this.thumbCache = ((d == null ? void 0 : d.thumbCacheVer) === 2 && (d == null ? void 0 : d.thumbCache)) ? d.thumbCache : {};
    if (Object.keys(this.thumbCache).length) this._saveThumbCache();
  }
  _saveThumbCache() {
    this._thumbSaveChain = (this._thumbSaveChain || Promise.resolve()).then(
      () => this.app.vault.adapter.write(this._thumbCachePath(), JSON.stringify({ ver: 2, cache: this.thumbCache }))
    ).catch((e) => console.warn("Book Reader TTS: thumb cache save failed", e));
    return this._thumbSaveChain;
  }
  // ── Daily reading-goal timer ───────────────────────────────────────────────
  _todayKey() { return readerTodayKey(); }
  // Add active reading seconds to today's tally (kept in memory; flushed to disk
  // periodically so we don't rewrite data.json every second).
  bumpReadingTime(sec) {
    const s = this.settings;
    if (!s.readingLog) s.readingLog = {};
    const k = this._todayKey();
    s.readingLog[k] = (s.readingLog[k] || 0) + sec;
    s.lifetimeSeconds = (s.lifetimeSeconds || 0) + sec;
    const keys = Object.keys(s.readingLog);
    if (keys.length > 100) { keys.sort(); while (keys.length > 90) delete s.readingLog[keys.shift()]; }
    this._readingDirty = true;
  }
  getTodaySeconds() {
    const s = this.settings;
    return (s.readingLog && s.readingLog[this._todayKey()]) || 0;
  }
  // Sum of every day's reading seconds we still keep (~last 90 days) — shown as a
  // running total in the reading panel and settings. Requested by readers.
  getTotalSeconds() {
    const s = this.settings;
    const logSum = s.readingLog ? Object.keys(s.readingLog).reduce((a, k) => a + (s.readingLog[k] || 0), 0) : 0;
    // Lifetime counter is untrimmed; for users upgrading with existing history it
    // may start behind the 90-day log, so never report less than the log holds.
    return Math.max(s.lifetimeSeconds || 0, logSum);
  }
  // ── Opening books by command ───────────────────────────────────────────────
  // Every readable book in the configured folder (or the whole vault when none
  // is set) — the same rule the library window uses.
  bookFiles() {
    const folder = erPath(this.settings.booksFolder || "");
    const prefix = folder ? folder + "/" : "";
    return this.app.vault.getFiles().filter(
      (f) => (f.extension === "epub" || f.extension === "pdf" || f.extension === "fb2")
        && (prefix === "" || f.path.startsWith(prefix))
    );
  }
  // The book with the most recent reading timestamp, skipping any whose file has
  // since been deleted or renamed.
  lastReadBookFile() {
    const prog = this.progress || {};
    let bestPath = "", bestAt = -1;
    for (const p of Object.keys(prog)) {
      const at = (prog[p] && (prog[p].lastRead || prog[p].updated)) || 0;
      const ts = typeof at === "number" ? at : Date.parse(at) || 0;
      if (ts > bestAt) { bestAt = ts; bestPath = p; }
    }
    if (!bestPath) bestPath = this.settings.lastBookPath || "";
    if (!bestPath) return null;
    const f = this.app.vault.getAbstractFileByPath(bestPath);
    return f && f.extension ? f : null;
  }
  // Register "Book Reader TTS: <title>" for each book so it can be opened directly or
  // bound to a hotkey. Obsidian has no public API for dropping a command, so the
  // ids are tracked and removed through the (undocumented) registry when the list
  // is rebuilt — guarded, since that call is not part of the public API.
  registerBookCommands() {
    const prev = this._bookCmdIds || [];
    for (const id of prev) {
      try { this.app.commands.removeCommand(id); } catch { /* not supported — leave it */ }
    }
    const ids = [];
    const files = this.bookFiles()
      .sort((a, b) => a.basename.localeCompare(b.basename))
      .slice(0, MAX_BOOK_COMMANDS);   // a huge library would otherwise bury every other command
    for (const f of files) {
      const path = f.path;
      const cmd = this.addCommand({
        // Path-derived so the id survives restarts and keeps any assigned hotkey.
        id: "open-book:" + path,
        name: __ertr("Open book: {0}", f.basename),
        callback: () => {
          const cur = this.app.vault.getAbstractFileByPath(path);
          if (cur) this.openFile(cur);
          else new Notice(__ertr("Book not found: {0}", path));
        }
      });
      if (cmd && cmd.id) ids.push(cmd.id);
    }
    this._bookCmdIds = ids;
  }
  // Auto-create (once) a dedicated note named after the book and link it, so
  // every book gets its own note without manual picking. Opt-in via autoBookNote.
  async ensureBookNote(file) {
    if (!file) return null;
    const s = this.settings;
    if (!s.bookNoteLinks) s.bookNoteLinks = {};
    if (s.bookNoteLinks[file.path]) return null;
    const base = bookNotesFolderPath(this.app) || notesFolderPath(this.app) || "";
    return this.createBookNote(file, file.basename, base);
  }
  // Categories assigned to a book. Stored per book rather than derived from the
  // note, so a book can be filed under a category even without a note.
  async setBookTags(bookPath, tags) {
    const s = this.settings;
    if (!s.bookTags) s.bookTags = {};
    const list = (tags || []).filter(Boolean);
    if (list.length) s.bookTags[bookPath] = list;
    else delete s.bookTags[bookPath];
    await this.saveAll();
  }
  // Create the note for a book and link it. `title` and `folder` come from the
  // setup screen, so the reader can name it and place it wherever they want
  // instead of being stuck with the defaults.
  async createBookNote(file, title, folder) {
    try {
      if (!file) return null;
      const s = this.settings;
      if (!s.bookNoteLinks) s.bookNoteLinks = {};
      const base = erPath(folder);
      const name = sanitizeNoteTitle(title || file.basename);
      // Never overwrite: if that name is taken, link the EXISTING note rather
      // than clobbering someone's file or silently failing.
      const path5 = erPath(base ? `${base}/${name}.md` : `${name}.md`);
      let note = this.app.vault.getAbstractFileByPath(path5);
      if (!(note instanceof TFile)) {
        if (base && !this.app.vault.getAbstractFileByPath(base)) await this.app.vault.createFolder(base).catch(() => {});
        /* Apply the configured template to automatically created book notes as well as notes created from a selection. */
        let body = `# ${name}\n\n`;
        const tplPath = noteTemplatePath(this.app, file);
        const tplFile = tplPath ? this.app.vault.getAbstractFileByPath(tplPath) : null;
        if (tplFile instanceof TFile) {
          try { body = processTemplateManually(await this.app.vault.read(tplFile), name) + "\n\n"; }
          catch { /* a broken template must not stop the note being created */ }
        }
        note = await this.app.vault.create(path5, body).catch((e) => {
          console.error("Elton Reader: create book note failed", e);
          return null;
        });
      }
      if (note instanceof TFile) {
        s.bookNoteLinks[file.path] = note.basename;
        await this.saveAll();
        await writeBookProperty(this.app, note.basename, file);
        return note;
      }
      new Notice(__ertr("Could not create the note"));
      return null;
    } catch (e) {
      console.error("Elton Reader: create book note failed", e);
      new Notice(__ertr("Could not create the note"));
      return null;
    }
  }
  resetTodaySeconds() {
    const s = this.settings;
    if (!s.readingLog) s.readingLog = {};
    s.readingLog[this._todayKey()] = 0;
    this._readingDirty = true;
  }
  getGoalSeconds() { return Math.max(60, (this.settings.dailyGoalMin || 15) * 60); }
  flushReadingTime() {
    if (!this._readingDirty) return;
    this._readingDirty = false;
    this._saveLocalData();
  }
  // Keep a rolling local history of reading positions per book (in data.json),
  // so a glitch (e.g. a stray jump to 100%) never loses the real position.
  _recordBackup(path5, prev, now) {
    if (!prev || typeof prev.percent !== "number") return;
    const list = this.progressBackups[path5] || (this.progressBackups[path5] = []);
    const last = list[list.length - 1];
    if (last && last.percent === prev.percent) { last.ts = now; return; }
    list.push({ pct: prev.pct, percent: prev.percent, lastRead: prev.lastRead || now, ts: now });
    if (list.length > 30) list.shift();
  }
  async _loadProgressFromVault() {
    try {
      const path5 = this._progressFilePath();
      const exists = await this.app.vault.adapter.exists(path5);
      if (!exists) return {};
      const raw = await this.app.vault.adapter.read(path5);
      return JSON.parse(raw);
    } catch (e) {
      console.error("Elton Reader: could not load progress file", e);
      return {};
    }
  }
  async _saveProgressToVault() {
    this.readerSync?.schedule();
    try {
      const path5 = this._progressFilePath();
      const folder = path5.substring(0, path5.lastIndexOf("/"));
      if (folder) {
        const folderExists = await this.app.vault.adapter.exists(folder);
        if (!folderExists) await this.app.vault.createFolder(folder).catch(() => {});
      }
      await this.app.vault.adapter.write(path5, JSON.stringify(this.progress, null, 2));
      this._writeRescue(false);
    } catch (e) {
      console.error("Elton Reader: could not save progress file", e);
    }
  }
  // Safety net: keep a dated copy of progress + highlights + the plugin's own
  // data.json under "<booksFolder>/_reader-rescue-<date>" so a sync glitch can
  // never wipe out highlights for good. Progress saves are throttled
  // (≤ once / 5 min); highlight saves force a write (force=true).
  async _writeRescue(force) {
    try {
      const now = Date.now();
      if (!force && this._lastRescueTs && (now - this._lastRescueTs) < 5 * 60 * 1e3) return;
      this._lastRescueTs = now;
      let date;
      try { date = window.moment ? window.moment().format("YYYY-MM-DD") : new Date().toISOString().slice(0, 10); }
      catch { date = new Date().toISOString().slice(0, 10); }
      const bf = this._dataFolder();
      // Prefer the configured data/books folder. When neither is set, keep the
      // backup next to the last book read (persisted across restarts). If we
      // still don't know any book folder, SKIP the backup entirely rather than
      // dumping a "_reader-rescue" folder at the vault root.
      let base;
      if (bf) {
        base = erPath(`${bf}/_reader-rescue`);
      } else if (this._lastBookPath && this._lastBookPath.includes("/")) {
        const bookDir = this._lastBookPath.slice(0, this._lastBookPath.lastIndexOf("/"));
        base = erPath(`${bookDir}/_reader-rescue`);
      } else {
        return;
      }
      const dir = erPath(`${base}/_reader-rescue-${date}`);
      const ad = this.app.vault.adapter;
      if (!await ad.exists(base)) await this.app.vault.createFolder(base).catch(() => {});
      if (!await ad.exists(dir)) await this.app.vault.createFolder(dir).catch(() => {});
      await ad.write(erPath(`${dir}/tts-reader-progress.json`), JSON.stringify(this.progress, null, 2));
      await ad.write(erPath(`${dir}/tts-reader-highlights.json`), JSON.stringify(this.highlights, null, 2));
      const dataPath = erPath(`${this.manifest.dir}/data.json`);
      if (await ad.exists(dataPath)) await ad.write(erPath(`${dir}/plugin-data.json`), await ad.read(dataPath));
    } catch (e) {
      console.error("Elton Reader: rescue backup failed", e);
    }
  }
  saveProgress(path5, spread, total, block) {
    // Store as 0-1 float so it works across devices with different
    // screen sizes / column counts / font sizes.
    const pct = total > 1 ? spread / (total - 1) : 0;
    const pctDisplay = Math.round(pct * 100);
    const now = Date.now();
    const prev = this.progress[path5];
    // Snapshot the previous position into history on a big jump (≥15%) or
    // roughly every 3 minutes — so we can always roll back to a real spot.
    const bigJump = prev && typeof prev.pct === "number" && Math.abs(pct - prev.pct) >= 0.15;
    const list = this.progressBackups[path5];
    const last = list && list[list.length - 1];
    const periodic = !last || (now - (last.ts || 0)) >= 3 * 60 * 1e3;
    if (bigJump || periodic) this._recordBackup(path5, prev, now);
    this._lastBookPath = path5;
    const entry = { pct, percent: pctDisplay, lastRead: now };
    // Device-independent anchor: global index of the first visible paragraph.
    if (typeof block === "number" && block >= 0) entry.block = block;
    this.progress[path5] = entry;
    this._saveProgressToVault();
    this._saveLocalData();
    this._syncProgressFrontmatter(path5);
  }
  // Mirror the reading position into the book note's frontmatter.
  //
  // Progress itself lives in a JSON file next to the books, which is right — it
  // is the reader's own bookkeeping and has no business in a note. But a reader
  // pointed out that a number in frontmatter is a number Bases can chart, sort
  // and filter, and there is no other way to get reading progress into a table.
  // So the note gets a COPY: the JSON stays the source of truth, the note gets
  // something to look at.
  //
  // Debounced, because progress is written on every page turn and rewriting a
  // note that often would spam the vault (and any sync watching it).
  _syncProgressFrontmatter(bookPath) {
    if (!this.settings.progressToFrontmatter) return;
    const noteName = bookNoteLinkFor(this, { path: bookPath, basename: "" });
    if (!noteName) return;
    const note = resolveBookNote(this.app, noteName);
    if (!note) return;
    window.clearTimeout(this._fmTimers && this._fmTimers[bookPath]);
    if (!this._fmTimers) this._fmTimers = {};
    this._fmTimers[bookPath] = window.setTimeout(async () => {
      const p = this.progress[bookPath];
      if (!p) return;
      try {
        await this.app.fileManager.processFrontMatter(note, (fm) => {
          fm["reading-progress"] = Math.round((p.pct || 0) * 100);
          fm["reading-updated"] = new Date(p.lastRead || Date.now()).toISOString().slice(0, 10);
        });
      } catch (e) {
        console.warn("Book Reader TTS: could not write progress into the book note", e);
      }
    }, 4000);
  }
  // Manual save (the 💾 button / command). Like saveProgress, but always drops a
  // "manual" restore point for the CURRENT position so the user can jump back to
  // exactly here later, even after lots of further reading.
  saveNow(path5, spread, total, block) {
    const pct = total > 1 ? spread / (total - 1) : 0;
    const pctDisplay = Math.round(pct * 100);
    const now = Date.now();
    const hasBlock = typeof block === "number" && block >= 0;
    this._lastBookPath = path5;
    const entry = { pct, percent: pctDisplay, lastRead: now };
    if (hasBlock) entry.block = block;
    this.progress[path5] = entry;
    const list = this.progressBackups[path5] || (this.progressBackups[path5] = []);
    const last = list[list.length - 1];
    if (last && last.percent === pctDisplay) {
      last.ts = now; last.lastRead = now; last.manual = true;
      if (hasBlock) last.block = block;
    } else {
      const snap = { pct, percent: pctDisplay, lastRead: now, ts: now, manual: true };
      if (hasBlock) snap.block = block;
      list.push(snap);
      if (list.length > 30) list.shift();
    }
    this._saveProgressToVault();
    this._saveLocalData();
    this._syncProgressFrontmatter(path5);
    return pctDisplay;
  }
  getBackups(path5) {
    const list = this.progressBackups[path5];
    return Array.isArray(list) ? list : [];
  }
  getProgress(path5) {
    let _a;
    return (_a = this.progress[path5]) != null ? _a : null;
  }
  // Returns the spread index for the current device given saved progress.
  getSpreadForTotal(path5, total) {
    const prog = this.getProgress(path5);
    if (!prog) return 0;
    // New format: pct is a 0-1 float
    if (typeof prog.pct === "number") {
      return Math.round(prog.pct * Math.max(0, total - 1));
    }
    // Legacy format: raw spread number (old version) - use as-is
    return typeof prog.spread === "number" ? prog.spread : 0;
  }
  // Re-reads progress from vault file — call before opening a book
  // to get fresh data after Obsidian Sync may have updated the file.
  async refreshProgress() {
    if(this.readerSync?.ready) { await this.readerSync.refresh().catch(this.readerSync.onError); return; }
    this.progress = await this._loadProgressFromVault();
  }
  // ── Highlights ────────────────────────────────────────
  _highlightsFilePath() {
    const folder = this._dataFolder();
    return erPath(folder ? `${folder}/tts-reader-highlights.json` : "tts-reader-highlights.json");
  }
  async _loadHighlightsFromVault() {
    try {
      const path5 = this._highlightsFilePath();
      const exists = await this.app.vault.adapter.exists(path5);
      if (!exists) return {};
      const raw = await this.app.vault.adapter.read(path5);
      return JSON.parse(raw);
    } catch (e) {
      console.error("Elton Reader: could not load highlights file", e);
      return {};
    }
  }
  async _saveHighlightsToVault() {
    this.readerSync?.schedule();
    try {
      const path5 = this._highlightsFilePath();
      const folder = path5.substring(0, path5.lastIndexOf("/"));
      if (folder) {
        const folderExists = await this.app.vault.adapter.exists(folder);
        if (!folderExists) await this.app.vault.createFolder(folder).catch(() => {});
      }
      await this.app.vault.adapter.write(path5, JSON.stringify(this.highlights, null, 2));
      this._writeRescue(true);
    } catch (e) {
      console.error("Elton Reader: could not save highlights file", e);
    }
  }
  async refreshHighlights() {
    if(this.readerSync?.ready) { await this.readerSync.refresh().catch(this.readerSync.onError); return; }
    this.highlights = await this._loadHighlightsFromVault();
  }
  getHighlights(path5) {
    let _a;
    const list = (_a = this.highlights[path5]) != null ? _a : [];
    // Stable reading order: by block, then by position inside block
    return [...list].sort((a, b) => a.block - b.block || a.occ - b.occ);
  }
  addHighlight(path5, hl) {
    if (!this.highlights[path5]) this.highlights[path5] = [];
    this.highlights[path5].push(hl);
    this._persistHighlights(path5, (disk) => {
      if (!disk[path5]) disk[path5] = [];
      if (!disk[path5].some((x) => x.id === hl.id)) disk[path5].push(hl);
    });
  }
  removeHighlight(path5, id) {
    const list = this.highlights[path5];
    if (list) this.highlights[path5] = list.filter((h) => h.id !== id);
    this._persistHighlights(path5, (disk) => {
      if (disk[path5]) disk[path5] = disk[path5].filter((h) => h.id !== id);
    });
  }
  // Attach (or clear) the margin note on a highlight. `id` may be null when the
  // reader commented on a plain selection that was never saved — in that case the
  // matching highlight is found by its text, and if there is none we cannot store
  // anything, so the caller is told nothing happened.
  async setHighlightComment(path5, id, hl, text) {
    const list = this.highlights[path5] || [];
    let target = id ? list.find((x) => x.id === id) : null;
    if (!target && hl && hl.text) target = list.find((x) => x.text === hl.text);
    if (!target) { new Notice(__ertr("Highlight a passage with a colour first")); return false; }
    const value = String(text || "").trim();
    if (value) target.comment = value; else delete target.comment;
    this._persistHighlights(path5, (disk) => {
      const d = (disk[path5] || []).find((x) => x.id === target.id);
      if (d) { if (value) d.comment = value; else delete d.comment; }
    });
    new Notice(value ? __ertr("Comment saved") : __ertr("Comment removed"));
    return true;
  }
  setHighlightColor(path5, id, color) {
    const list = this.highlights[path5];
    if (list) {
      const h = list.find((x) => x.id === id);
      if (h) h.color = color;
    }
    this._persistHighlights(path5, (disk) => {
      if (disk[path5]) {
        const h = disk[path5].find((x) => x.id === id);
        if (h) h.color = color;
      }
    });
  }
  // Crash-/sync-safe persistence for incremental highlight edits.
  // Re-reads the on-disk file (which may already contain highlights written by
  // ANOTHER device that this session never loaded) and merges our single change
  // INTO it, so a stale in-memory copy can never clobber newer data via Obsidian
  // Sync. Mutations are serialized through a promise chain to avoid lost updates.
  _persistHighlights(path5, applyFn) {
    this._lastBookPath = path5;
    this._hlChain = (this._hlChain || Promise.resolve()).then(async () => {
      let disk = {};
      try {
        const fp = this._highlightsFilePath();
        if(this.readerSync?.ready) disk=JSON.parse(JSON.stringify(this.highlights||{}));
        else if (await this.app.vault.adapter.exists(fp)) {
          disk = JSON.parse(await this.app.vault.adapter.read(fp));
        }
      } catch (e) {
        console.error("Elton Reader: could not re-read highlights, falling back to memory", e);
        disk = JSON.parse(JSON.stringify(this.highlights || {}));
      }
      if (!disk || typeof disk !== "object") disk = {};
      applyFn(disk);
      // Re-add any local highlights the disk copy doesn't have yet (protects
      // rapid successive edits and concurrent local adds from being dropped).
      if (Array.isArray(this.highlights[path5])) {
        if (!disk[path5]) disk[path5] = [];
        const seen = new Set(disk[path5].map((h) => h.id));
        for (const h of this.highlights[path5]) if (!seen.has(h.id)) disk[path5].push(h);
      }
      this.highlights = disk;
      this._backupHighlights(path5, disk[path5] || []);
      await this._saveHighlightsToVault();
      await this._saveLocalData();
    }).catch((e) => console.error("Elton Reader: highlight persist failed", e));
    return this._hlChain;
  }
  // Rolling local snapshots of a book's highlights (kept in data.json), so an
  // accidental loss/overwrite can always be restored on this device.
  _backupHighlights(path5, list) {
    if (!this.highlightsBackups) this.highlightsBackups = {};
    const arr = this.highlightsBackups[path5] || (this.highlightsBackups[path5] = []);
    const now = Date.now();
    const sig = list.map((h) => h.id).sort().join(",");
    const last = arr[arr.length - 1];
    if (last && last.sig === sig) { last.ts = now; return; }
    arr.push({ ts: now, count: list.length, sig, items: JSON.parse(JSON.stringify(list)) });
    while (arr.length > 12) arr.shift();
  }
};
const Paginator = class {
  constructor() {
    this.spread = 0;
    this.total = 0;
    this.sw = 0;  // stride per spread in px (float)
  }
  /** Build the paginator. Returns [currentSpread, totalSpreads]. */
  async build(container, html, settings, savedSpread) {
    /* Reuse existing book nodes, including rendered PDF pages, when only geometry or styles change. */
    const isRelayout = !!(this.flow && this.clip
      && this.flow.parentElement === this.clip
      && this.clip.parentElement === container
      && this._html === html);
    if (!isRelayout) container.empty();
    const t = erTheme(settings);
    // Vertical placement is decided per spread from real geometry, so both the
    // setting and the measurements are reset whenever the book is re-laid out.
    this._vAlign = settings.vAlign || "top";
    this._vCache = null;
    this._blockGeom = null;

    // Continuous scrolling instead of pages. Asked for by readers who find they
    // keep going for longer when the text does not stop at a page edge.
    //
    // It is a branch rather than a separate class on purpose: everything that
    // reads a position — progress, the contents list, highlights, search —
    // speaks in spreads and block indices, so the scrolling mode presents the
    // same surface. A "spread" here is one screenful.
    this.scrollMode = (settings.readMode || "pages") === "scroll";
    // Remembered here so applyTransform can honour it on every turn without
    // reaching back into the plugin's settings.
    this.animate = settings.pageTurnAnimation !== false;

    /* 1. Clip — measure real px after one frame */
    this.clip = isRelayout ? this.clip : container.createDiv("er-clip");
    // NO `overflow` here. It used to be inline, and an inline declaration beats
    // any class without !important — so `.er-clip-scroll { overflow-y: auto }`
    // never applied and scroll mode could not be scrolled with a finger at all.
    // The page-turn buttons still worked, because they move scrollTop from code
    // and overflow does not stop that; which is exactly what it looked like from
    // the outside: "it only pages with buttons or taps". Same trap as the inline
    // `transition:none` that silently killed the page-turn animation. Overflow is
    // decided in the stylesheet: hidden on .er-clip, auto on .er-clip-scroll.
    this.clip.style.cssText = `flex:1;align-self:stretch;position:relative;min-width:0;min-height:0;`;
    if (this.scrollMode) this.clip.addClass("er-clip-scroll");
    await new Promise(r => window.requestAnimationFrame(r));
    await new Promise(r => window.requestAnimationFrame(r));
    // On mobile the view may not have final dimensions yet — wait an extra tick
    if (!container.offsetWidth) await new Promise(r => window.setTimeout(r, 80));
    const aW   = this.clip.offsetWidth  || container.offsetWidth || 390;
    const aH   = this.clip.offsetHeight || container.offsetHeight || 700;
    // The width this layout is ACTUALLY valid for. build() waits a couple of
    // frames before measuring, so by now the area may be a different size than it
    // was when the caller decided to rebuild — during a sidebar animation it
    // usually is. The view must record THIS number, not the one it saw earlier,
    // or the resize observer compares against a width that was never used and
    // concludes nothing needs rebuilding, leaving the page laid out for one width
    // and displayed at another (columns then sit off to the side).
    this.builtWidth = aW;
    const cols  = settings.columns === "2" && aW > 700 ? 2 : 1;
    const gap   = cols === 2 ? 48 : 0;
    // Side padding scales with width: a phone (≤600px) gets a comfortable 26px
    // margin instead of the desktop 60px, so the reading column isn't squeezed.
    const basePad = cols === 2 ? 48 : (aW <= 600 ? 26 : aW <= 820 ? 42 : 60);
    const padVt = Math.min(basePad, 40);
    const padVtBot = padVt;
    // Reduce aH by vertical padding so content fits within column height
    const aHinner = aH - padVt - padVtBot;

    /* 2. Column geometry is DECLARED, not inferred. A column plus the gap that
       follows it is one SLOT, and a spread is exactly `cols` slots — so a slot
       is the visible width over the column count, and the paging stride is that
       number by construction rather than something to be measured back out of
       the layout. CSS places a gap after EVERY column, including the last one
       of a spread, so a column is one gap narrower than its slot.
       Sizing the flow to a whole number of slots is what pins this down:
       `column-width` is only a MINIMUM, so whatever slack is left over in the
       flow width gets handed back to the columns — which is how a 1200px page
       ended up striding 623.94px instead of 600px.
       Splitting the gap in half on both sides of the spread (`left` below)
       keeps the margins even: giving the whole gap to the trailing edge is what
       once left the text sitting 48px from the left and 97px from the right. */
    const slot  = aW / cols;
    const colW  = this.scrollMode ? aW : slot - gap;
    const flowW = this.scrollMode ? aW : 4000 * slot - gap;   /* room for ~4000 columns */

    /* Comfortable line length. On a wide monitor a full-width column runs past
       150 characters and the eye loses its place returning to the next line;
       typography puts the readable range at 60-90. Readers asked for this after
       maximising the window and finding the text unreadable.
       Deliberately spent as PADDING rather than as a narrower column: the slot,
       the column width and therefore the paging stride stay exactly as computed
       above, so nothing about pagination changes — the spare width just becomes
       margin. 0.5em per character is the usual average for a mixed-case serif;
       it does not have to be exact, since this is a comfort limit and not a
       layout constraint. */
    let pad = basePad;
    const maxCh = Number(settings.maxLineCh) || 0;
    if (maxCh > 0) {
      const target = maxCh * (Number(settings.fontSize) || 18) * 0.5;
      if (target > 0 && target < colW - basePad * 2) pad = Math.round((colW - target) / 2);
    }

    /* 3. Flow element */
    this.flow = isRelayout ? this.flow : this.clip.createDiv("er-flow");
    this.flow.style.cssText = `
      width:${flowW}px;
      /* Scrolling: the text is as tall as it needs to be and the clip scrolls,
         so no column rules apply and the height must not be pinned. */
      ${this.scrollMode ? "height:auto;min-height:100%;" : `height:${aHinner}px;
      column-width:${colW}px;
      column-gap:${gap}px;
      column-fill:auto;`}
      position:relative;
      /* Half a gap on each side of the spread instead of a whole one after it. */
      left:${this.scrollMode ? 0 : gap / 2}px;
      /* Chrome enforces orphans/widows of 2 inside multicol: if only one line of
         the next paragraph fits at the foot of a column, it refuses to split and
         moves the WHOLE paragraph over, stranding several empty lines. Allowing a
         single line to stand lets each column fill to the bottom. */
      orphans:1;
      widows:1;
      padding:${padVt}px 0 ${padVtBot}px;
      box-sizing:content-box;
      margin-top:0;
      font-family:${FONTS[settings.fontFamily]};
      font-size:${settings.fontSize}px;
      line-height:${settings.lineHeight};
      color:var(--er-text);
      background:var(--er-bg);
      overflow:hidden;
      user-select:text;
      -webkit-user-select:text;
      will-change:transform;
      /* No transition declared here on purpose: the page-turn animation lives
         in the er-flow-anim class, and an inline transition:none would outrank
         it — which is exactly what silently killed the sliding page turn.
         Until that class is added at the end of build() there is no transition
         anyway, which is what the initial positioning wants. */`;

    /* Padding via <style> so every column (including overflow) gets consistent margins */
    /* The one innerHTML the reader keeps, and deliberately. This is the book
       itself: a whole chapter of markup, rebuilt on every re-layout, where
       building nodes one at a time would cost a visible pause on a long book.
       It is not raw file content — extractEpub / extractFb2 / extractPdf walk
       the parsed document and emit a fixed set of tags they construct
       themselves, running every text run through escHtml() on the way, so
       nothing from the file can arrive here as markup. The <style> block is
       interpolated from our own numbers (font size, padding, theme colours),
       never from anything a book or a reader typed. */
    const markup = `<style>
.er-flow p{text-align:${settings.textAlign || "left"}}
/* Fragmentation. A column must fill to its last line; if the next paragraph
   cannot be split, the whole paragraph jumps to the next column and leaves a
   hole several lines deep. A block becomes MONOLITHIC (unsplittable) as soon as
   it gets break-inside:avoid, contain, or any overflow other than visible — and
   the page wrappers below carry no rules of their own, so whatever the active
   theme applies to a plain <div> decides their fate. Stating it here removes
   that dependency. orphans/widows are repeated on the paragraphs themselves
   rather than relying on inheritance from the flow. */
.er-flow .er-section,.er-flow .er-pdf-page-break{
  display:block;overflow:visible;contain:none;
  break-inside:auto;-webkit-column-break-inside:auto}
.er-flow p,.er-flow li{
  break-inside:auto;-webkit-column-break-inside:auto;orphans:1;widows:1}
.er-flow p,.er-flow h1,.er-flow h2,.er-flow h3,.er-flow h4{
  padding-left:${pad}px;padding-right:${pad}px;margin:0 0 .75em}
.er-flow h1,.er-flow h2,.er-flow h3,.er-flow h4{margin-top:1.1em}
.er-flow>p:first-of-type,.er-flow .er-section:first-child>p:first-child,
.er-flow .er-section:first-child>h1:first-child,.er-flow .er-section:first-child>h2:first-child,
.er-flow .er-section:first-child>h3:first-child{padding-top:${padVt}px}
.er-flow img{max-width:calc(100% - ${pad*2}px);max-height:${aHinner - 12}px;height:auto;width:auto;object-fit:contain;display:block;margin:8px auto;break-inside:avoid;page-break-inside:avoid;-webkit-column-break-inside:avoid}
.er-flow figure{break-inside:avoid;-webkit-column-break-inside:avoid;margin:8px auto}
.er-flow .er-pdf-figure{margin:0 0 .9em;padding:0 ${pad}px;break-inside:avoid;-webkit-column-break-inside:avoid;text-align:center;position:relative}
/* One-click "note from this page" on image/scan pages, where there is no text to
   select and the usual highlight → note route simply doesn't exist. */
.er-flow .er-pdf-note-btn{position:absolute;top:8px;right:${pad + 8}px;width:34px;height:34px;
  display:flex;align-items:center;justify-content:center;padding:6px;cursor:pointer;
  background:var(--er-ui);color:var(--er-text);border:1px solid var(--er-border);border-radius:9px;
  opacity:.55;transition:opacity .15s,transform .15s;z-index:2}
.er-flow .er-pdf-note-btn:hover{opacity:1;transform:scale(1.06)}
.er-flow .er-pdf-note-btn svg{width:18px;height:18px}
.er-flow .er-pdf-page-img{max-width:100%;max-height:${aHinner - 24}px;width:auto;height:auto;object-fit:contain;margin:4px auto;border:1px solid var(--er-border);border-radius:10px;break-inside:avoid;-webkit-column-break-inside:avoid}
/* Program listings (PDF and EPUB): keep line breaks and indentation. Wraps rather
   than scrolls — a horizontal scrollbar has nowhere to live inside a paged column. */
.er-flow pre.er-code{margin:0 0 .85em;padding:.55em .7em;box-sizing:border-box;
  max-width:calc(100% - ${pad * 2}px);margin-left:${pad}px;margin-right:${pad}px;
  white-space:pre-wrap;overflow-wrap:anywhere;tab-size:2;
  font-family:ui-monospace,SFMono-Regular,Consolas,"Liberation Mono",Menlo,monospace;
  font-size:.8em;line-height:1.45;background:var(--er-ui);border:1px solid var(--er-border);
  border-radius:8px;break-inside:avoid;-webkit-column-break-inside:avoid}
.er-flow pre.er-code code{font:inherit;background:none;padding:0;color:inherit}
/* Contents pages: a dot leader must never be justified — stretching it turns the
   entry into a field of dots. Title left, page number right, one row each. */
.er-flow p.er-toc-line{display:flex;align-items:baseline;gap:8px;text-align:left !important;
  margin:0 0 .35em;padding-left:${pad}px;padding-right:${pad}px}
.er-flow p.er-toc-line .er-toc-t{flex:1;min-width:0}
.er-flow p.er-toc-line .er-toc-n{flex:none;opacity:.65;font-variant-numeric:tabular-nums}
/* Notes printed in a book's margin, lifted out of the listing they annotate. */
.er-flow .er-side-notes{margin:.2em ${pad}px .9em;padding:.5em .8em;border-left:2px solid var(--er-border);
  background:color-mix(in srgb,var(--er-text) 4%,transparent);border-radius:0 8px 8px 0;
  break-inside:avoid;-webkit-column-break-inside:avoid}
.er-flow .er-side-notes p{padding:0 !important;margin:0 0 .4em;font-size:.9em;opacity:.85;text-align:left}
.er-flow .er-side-notes p:last-child{margin-bottom:0}
/* Inline identifiers inside prose — malloc(), ptr, --flag. */
.er-flow code{font-family:ui-monospace,SFMono-Regular,Consolas,"Liberation Mono",Menlo,monospace;
  font-size:.86em;background:var(--er-ui);border:1px solid var(--er-border);border-radius:4px;
  padding:0 .28em;overflow-wrap:anywhere}
/* Tables from technical books: readable inside a narrow paged column. */
.er-flow table.er-table{margin:0 ${pad}px .9em;border-collapse:collapse;
  max-width:calc(100% - ${pad * 2}px);font-size:.82em;line-height:1.4;
  break-inside:avoid;-webkit-column-break-inside:avoid}
.er-flow table.er-table th,.er-flow table.er-table td{border:1px solid var(--er-border);
  padding:.3em .5em;text-align:left;vertical-align:top;overflow-wrap:anywhere}
.er-flow table.er-table th{background:var(--er-ui);font-weight:700}
/* End-of-book marker. Empty and invisible; its only job is to be the last thing
   the column layout places, so the column it lands in is the last column the
   book occupies. See the measurement in step 5. */
.er-flow .er-end{display:block;height:0;margin:0;padding:0;border:0;visibility:hidden}
</style>${html}<div class="er-end" aria-hidden="true"></div>`;
    /* Parse and transfer book nodes instead of assigning file-derived markup with innerHTML. */
    if (!isRelayout) {
    const parsed = new DOMParser().parseFromString(markup, "text/html");
    this.flow.empty();
    /* DOM parsing moves leading styles into the head. Transfer these too, or margins, alignment and pagination rules disappear silently. */
    const parsedNodes = [...Array.from(parsed.head.childNodes), ...Array.from(parsed.body.childNodes)];
    for (const node of parsedNodes) {
      this.flow.appendChild(document.importNode(node, true));
    }
    this._html = html;
    }

    /* 4. Two rAF: first inserts DOM, second completes multicol layout */
    await new Promise(r => window.requestAnimationFrame(r));
    await new Promise(r => window.requestAnimationFrame(r));

    /* Reserve lazy figure dimensions before pagination; otherwise loading images changes column offsets and causes increasing page drift. Clamp placeholders to the column width. */
    const figMaxH = Math.max(40, aHinner - 24);
    for (const img of this.flow.querySelectorAll("img.er-pdf-lazy")) {
      const aw = parseFloat(img.getAttribute("width")) || 0;
      const ah = parseFloat(img.getAttribute("height")) || 0;
      if (!aw || !ah) continue;
      const host = img.parentElement;
      const hostW = host ? host.getBoundingClientRect().width - pad * 2 : colW - pad * 2;
      const maxW = Math.max(40, hostW);
      const scale = Math.min(1, maxW / aw, figMaxH / ah);
      img.style.width = `${Math.round(aw * scale)}px`;
      img.style.height = `${Math.round(ah * scale)}px`;
    }
    await new Promise(r => window.requestAnimationFrame(r));

    /* 5. How many columns the book actually occupies.
          Read off ONE element: the empty marker appended after all the content,
          which the column layout necessarily places in the last column in use.

          What this replaces scanned every p/h1-h4/img and took the rightmost
          edge, and it was wrong twice over. It could not see a list, a code
          listing, a table or a blockquote, so a book whose tail is any of those
          measured as though it ended at its last paragraph — and step (b) then
          cut the flow off there for real, leaving the rest of the book behind a
          wall. Measured in Chrome: a list-heavy book needing 142 spreads showed
          5, one needing 48 showed 2. That is the "book opens with only 14 pages
          and skips whole chunks" report, and it happened in one-column mode too,
          so switching to a single column only ever helped by coincidence.
          It was also a getBoundingClientRect per block, run twice, which is a
          large part of why a 3000-page book took seconds to open. */
    const endEl = this.flow.querySelector(".er-end");
    const measure = () => {
      const fRect = this.flow.getBoundingClientRect();
      let lastX = endEl ? endEl.getBoundingClientRect().right - fRect.left : 0;
      if (lastX <= 0) {
        /* No marker to go by — fall back to the widest block we can find. */
        for (const el of this.flow.querySelectorAll(
          "p,h1,h2,h3,h4,h5,h6,img,li,pre,table,blockquote,figure,dd,dt")) {
          const r = el.getBoundingClientRect().right - fRect.left;
          if (r > lastX) lastX = r;
        }
      }
      return Math.max(1, Math.ceil(lastX / slot));
    };

    /* Scrolling has no columns to count: a "spread" is one screenful, and the
       book is as many of those as its height divides into. Measured from the
       clip's own scroll extent, which is the one number that is always right. */
    if (this.scrollMode) {
      this.sw = aH;
      this.cols = 1;
      this._pitch = aH;
      this._colX = null;
      const viewH = this.clip.clientHeight || aH;
      this.total = Math.max(1, Math.ceil((this.clip.scrollHeight || viewH) / viewH));
      this.spread = Math.max(0, Math.min(savedSpread, this.total - 1));
      this.flow.toggleClass("er-flow-anim", this.animate !== false);
      this.applyTransform(false);
      // Free scrolling has no page turn to hang anything off, so the position
      // has to be picked up from the scroller itself. Without this the progress
      // bar never moved, the place was never saved, and lazy pictures never
      // loaded — the reader would scroll into a book that stayed blank.
      //
      // Debounced: a scroll fires continuously, and re-reading the position on
      // every frame would make the reading itself stutter.
      this.clip.addEventListener("scroll", () => {
        window.clearTimeout(this._scrollT);
        this._scrollT = window.setTimeout(() => {
          const h = this.clip.clientHeight || 1;
          const at = Math.max(0, Math.min(Math.round(this.clip.scrollTop / h), this.total - 1));
          if (at === this.spread) return;
          this.spread = at;
          if (this.onSpreadChange) this.onSpreadChange(at, this.total);
        }, 140);
      }, { passive: true });
      return [this.spread, this.total];
    }

    /* a) count the columns on the roomy layout */
    let nPhys = measure();
    /* b) trim the flow to exactly those columns. The column width is fixed by
          construction, so nothing re-breaks and the count holds still. */
    this.flow.style.width = `${Math.ceil(nPhys * slot) - gap}px`;
    await new Promise(r => window.requestAnimationFrame(r));
    await new Promise(r => window.requestAnimationFrame(r));
    /* c) confirm on the trimmed layout, and never shrink below what was seen */
    nPhys = Math.max(nPhys, measure());

    this.sw = slot * cols;
    this.cols = cols;
    this._pitch = slot;
    // Anchor table: the REAL left offset of each column, keyed by column index.
    //
    // It exists to absorb a drifting stride. When the stride was measured back
    // out of the layout it was a float that could be off by a fraction of a
    // pixel, and multiplying it by the spread number grew that fraction into a
    // ~150px sideways shift by spread 159 — fine at the start of a book, three
    // half-columns deep in. Now that the stride is declared instead of measured
    // the multiplication is exact, so the table is normally not built at all:
    // it costs a getBoundingClientRect per block, which is real time in a long
    // book, and _spreadOffset falls back to spread × stride without it.
    //
    // Verified rather than assumed: the marker sits in the last column of the
    // book, the farthest point from the origin and so where any per-column
    // error would have piled up into its largest value. If it is not where the
    // arithmetic says it should be, the layout is not behaving as declared and
    // the measured table is built after all.
    this._colX = null;
    try {
      const fRect2 = this.flow.getBoundingClientRect();
      const endX = endEl ? endEl.getBoundingClientRect().left - fRect2.left : 0;
      if (endEl && Math.abs(endX - (nPhys - 1) * slot) > 1) {
        this._colX = /* @__PURE__ */ new Map();
        for (const el of this.flow.querySelectorAll("p,h1,h2,h3,h4")) {
          const x = el.getBoundingClientRect().left - fRect2.left;
          const k = Math.round(x / slot);
          // Keep the smallest offset seen for a column: blocks indented by margin
          // (code, tables) sit further right than the column edge.
          if (!this._colX.has(k) || x < this._colX.get(k)) this._colX.set(k, x);
        }
      }
    } catch { this._colX = null; }
    this.total = Math.max(1, Math.ceil(nPhys / cols));
    this.spread = Math.max(0, Math.min(savedSpread, this.total - 1));
    this.flow.toggleClass("er-flow-anim", this.animate !== false);
    this.applyTransform(false);
    return [this.spread, this.total];
  }
  // How far down to nudge the page so a short spread isn't stranded at the top.
  //
  // CSS multi-column can't centre a column's contents, so this measures how much
  // of the page the current spread actually fills and shifts the whole flow by
  // half the leftover. Geometry is cached per spread: it only changes when the
  // book is re-laid out, and reading through a long book would otherwise re-measure
  // thousands of blocks on every page turn.
  _vOffset() {
    const mode = this._vAlign || "top";
    if (mode === "top" || !this.flow) return 0;
    if (!this._vCache) this._vCache = /* @__PURE__ */ new Map();
    if (this._vCache.has(this.spread)) return this._vCache.get(this.spread);
    let off = 0;
    try {
      if (!this._blockGeom) {
        const fRect = this.flow.getBoundingClientRect();
        this._blockGeom = [...this._blocks()].map((el) => {
          const r = el.getBoundingClientRect();
          return { x: r.left - fRect.left, bottom: r.bottom - fRect.top };
        });
      }
      const from = this._spreadOffset(), to = from + this.sw;
      let maxBottom = 0;
      for (const g of this._blockGeom) if (g.x >= from - 2 && g.x < to - 2 && g.bottom > maxBottom) maxBottom = g.bottom;
      const height = this.flow.clientHeight || 0;
      if (maxBottom > 0 && height > 0) {
        const leftover = height - maxBottom;
        // Centre only genuinely short pages — the end of a chapter or of the book.
        // Nudging every ordinary page by its own few leftover pixels is what made
        // the text appear to jump around while paging through a normal chapter.
        if (leftover > height * SHORT_PAGE_GAP) off = mode === "center" ? leftover / 2 : leftover;
      }
    } catch { off = 0; }
    // Whole pixels only: a fractional offset lands glyphs between device pixels
    // and the whole page reads as slightly out of focus.
    off = Math.round(off);
    this._vCache.set(this.spread, off);
    return off;
  }
  // Horizontal offset of the current spread, taken from the measured position of
  // its first column when that column is known. Falls back to stride×index for
  // columns holding no text block (a full-page image, say).
  _spreadOffset() {
    if (this.scrollMode) return this.clip ? this.clip.scrollTop : 0;
    const k = this.spread * (this.cols || 1);
    const exact = this._colX && this._colX.get(k);
    if (typeof exact === "number") return exact;
    // Column with no text block of its own (a full-page figure). Anchor on the
    // nearest column that does have one, so any residual error in the pitch is
    // limited to that short distance instead of accumulating from column zero.
    if (this._colX && this._colX.size) {
      let bestK = null;
      for (const kk of this._colX.keys()) {
        if (bestK === null || Math.abs(kk - k) < Math.abs(bestK - k)) bestK = kk;
      }
      if (bestK !== null) return this._colX.get(bestK) + (k - bestK) * (this._pitch || this.sw / (this.cols || 1));
    }
    return this.spread * this.sw;
  }
  applyTransform(animate = true) {
    if (this.scrollMode) {
      // A screenful at a time, and the browser owns the motion. Smooth scrolling
      // is asked for only when the move was a deliberate jump, not while the
      // reader is dragging — that would fight the finger.
      const viewH = this.clip.clientHeight || 1;
      this.clip.scrollTo({ top: this.spread * viewH, behavior: animate ? "smooth" : "instant" });
      return;
    }
    // Horizontal paging and vertical placement are deliberately carried by two
    // DIFFERENT properties. Both used to live in one `translate(x, y)`, so a page
    // turn animated x and y together and the page visibly slid diagonally toward
    // the corner. `transform` is the only transitioned property; `top` (paint-time
    // offset under position:relative — it does NOT re-flow the columns) applies
    // instantly, so paging is always dead horizontal.
    this.flow.style.top = this._vOffset() + "px";
    // Round to whole pixels: a fractional translate lands glyphs between device
    // pixels and the whole page reads as slightly out of focus.
    const t = `translate3d(${-Math.round(this._spreadOffset())}px, 0, 0)`;
    if (!animate) {
      // Jump rather than slide: drop the animation class, force the layout to
      // settle at the new offset, then put the class back on the next frame so
      // ordinary page turns keep sliding. The forced getBoundingClientRect is
      // what makes the browser apply the class change before the transform.
      this.flow.removeClass("er-flow-anim");
      this.flow.getBoundingClientRect();
      this.flow.style.transform = t;
      window.requestAnimationFrame(() => this.flow.toggleClass("er-flow-anim", this.animate !== false));
    } else {
      this.flow.style.transform = t;
    }
  }
  next() {
    if (this.spread < this.total - 1)
      this.spread++;
    this.applyTransform();
    return [this.spread, this.total];
  }
  prev() {
    if (this.spread > 0)
      this.spread--;
    this.applyTransform();
    return [this.spread, this.total];
  }
  goTo(s, animate = true) {
    this.spread = Math.max(0, Math.min(s, this.total - 1));
    this.applyTransform(animate);
    return [this.spread, this.total];
  }
  // A jump is not a page turn: it must land, not travel. It was an alias for
  // goTo, so restoring the saved position slid the flow from spread 0 all the
  // way to the target — a quarter of a second of pages whipping past, which on
  // a phone reads as the book flickering open. Same for the table of contents,
  // search results and links from a quote: none of them mean "turn the pages".
  jumpTo(s) { return this.goTo(s, false); }
  // ── Content anchor (device-independent reading position) ──────────────
  // All p/h blocks in reading (column-fill) order. The SAME sequence exists on
  // phone and PC, so a block's global index pins the exact reading spot.
  _blocks() { return this.flow ? this.flow.querySelectorAll("p,h1,h2,h3,h4") : []; }
  // First block at or below the top of the visible area, while scrolling.
  // Binary search rather than a walk: on a long book the walk is thousands of
  // rect reads on every scroll settle, and this runs on every saved position.
  _blockIndexAtScroll() {
    const blocks = this._blocks();
    if (!blocks.length || !this.clip) return 0;
    const fTop = this.flow.getBoundingClientRect().top;
    const want = this.clip.scrollTop - 2;
    const scale = this.flow.offsetHeight ? this.flow.getBoundingClientRect().height / this.flow.offsetHeight : 1;
    const topAt = (i) => (blocks[i].getBoundingClientRect().top - fTop) / (scale || 1);
    let lo = 0, hi = blocks.length - 1, ans = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (topAt(mid) >= want) { ans = mid; hi = mid - 1; } else lo = mid + 1;
    }
    return ans;
  }
  // Global index of the first block at the current spread's left edge. x grows
  // monotonically with DOM order under column-fill, so binary-search it.
  currentBlockIndex() {
    if (this.scrollMode) return this._blockIndexAtScroll();
    const blocks = this._blocks();
    if (!blocks.length || !this.sw) return 0;
    const fLeft = this.flow.getBoundingClientRect().left;
    // Same anchored offset the transform uses, so "what is on screen" and "where
    // we scrolled to" can never disagree.
    const winLeft = this._spreadOffset() - 2;
    const xat = (i) => blocks[i].getBoundingClientRect().left - fLeft;
    let lo = 0, hi = blocks.length - 1, ans = blocks.length - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (xat(mid) >= winLeft) { ans = mid; hi = mid - 1; } else lo = mid + 1;
    }
    return ans;
  }
  // Spread that contains the block with the given global index.
  spreadForBlock(idx) {
    if (this.scrollMode) {
      const blocks = this._blocks();
      if (!blocks.length || idx < 0) return 0;
      const el = blocks[Math.min(idx, blocks.length - 1)];
      const scale=this.flow.offsetHeight ? this.flow.getBoundingClientRect().height / this.flow.offsetHeight : 1;
      const top = (el.getBoundingClientRect().top - this.flow.getBoundingClientRect().top) / (scale || 1);
      const viewH = this.clip.clientHeight || 1;
      return Math.max(0, Math.min(Math.floor(top / viewH), this.total - 1));
    }
    const blocks = this._blocks();
    if (!blocks.length || !this.sw || idx < 0) return 0;
    const el = blocks[Math.min(idx, blocks.length - 1)];
    const x = el.getBoundingClientRect().left - this.flow.getBoundingClientRect().left;
    // Via the column index rather than raw division: the stride is a float, and
    // dividing by it drifts by a whole spread once the error accumulates.
    const k = Math.round(x / (this.sw / (this.cols || 1)));
    return Math.max(0, Math.min(Math.floor(k / (this.cols || 1)), this.total - 1));
  }
  restoreBlockPosition(idx) {
    if (!this.scrollMode || !Number.isInteger(idx)) return [this.spread, this.total];
    const el=this.blockEl(idx);
    if (el && this.clip && this.flow) {
      const scale=this.flow.offsetHeight ? this.flow.getBoundingClientRect().height / this.flow.offsetHeight : 1;
      const top=(el.getBoundingClientRect().top-this.flow.getBoundingClientRect().top)/(scale||1);
      this.clip.scrollTo({top:Math.max(0,top),behavior:"instant"});
      this.spread=Math.min(this.total-1,Math.max(0,Math.floor(this.clip.scrollTop/(this.clip.clientHeight||1))));
    }
    return [this.spread,this.total];
  }
  // The block element for the given global index (for the resume flash).
  blockEl(idx) {
    const blocks = this._blocks();
    if (!blocks.length) return null;
    return blocks[Math.min(Math.max(0, idx), blocks.length - 1)] || null;
  }
  get currentSpread() {
    return this.spread;
  }
  get currentPct() {
    return this.total > 1 ? this.spread / (this.total - 1) : 0;
  }
  get totalSpreads() {
    return this.total;
  }
};
async function extractEpub(file, app) {
  const buf = await app.vault.readBinary(file);
  const book = ePub(buf);
  await book.ready;
  const spineItems = book.spine.spineItems;
  const parts = [];
  for (const item of spineItems) {
    try {
      const doc = await item.load(book.load.bind(book));
      const body = doc.querySelector?.("body") ?? doc;
      const imgs = Array.from(body.querySelectorAll?.("img") ?? []);
      for (const img of imgs) {
        const src = img.getAttribute("src");
        if (!src || src.startsWith("data:")) continue;
        try {
          const itemDir = (item.url || "").split("/").slice(0, -1).join("/");
          const resolved = src.startsWith("/") ? src : (itemDir ? itemDir + "/" + src : "/" + src).replace(/\/\.?\//g, "/");
          const dataUrl = await book.archive.getBase64(resolved);
          if (dataUrl) img.setAttribute("src", dataUrl);
        } catch { /* optional step; a failure here must not interrupt reading */ }
      }
      const html = nodeToHtml(body);
      if (html.trim())
        parts.push(`<div class="er-section">${html}</div>`);
      item.unload();
    } catch { /* a chapter that will not parse is skipped, not fatal */ }
  }
  book.destroy();
  return parts.join("\n");
}
// ── Translation ───────────────────────────────────────────────────────────────
// Translate a fragment through Google's public keyless endpoint.
//
// Two deliberate choices:
//  • requestUrl (Obsidian API), not fetch — the reader runs in a renderer where
//    CORS would block this host outright; requestUrl goes through the app.
//  • Chunking — the endpoint silently truncates long input, so a long selection
//    is split on sentence/word boundaries and stitched back together.
//
// This endpoint is free and needs no key, but it's unofficial and rate-limited:
// it is meant for selections, not for translating a whole book.
async function translateText(text, to = "auto") {
  if (!to || to === "auto") to = systemLocale();
  const q = (text || "").replace(/\s+/g, " ").trim();
  if (!q) return "";
  const MAX = 1600;
  const chunks = [];
  let rest = q;
  while (rest.length > MAX) {
    // Prefer a sentence end, else a space; never cut mid-word.
    let cut = rest.lastIndexOf(". ", MAX);
    if (cut < MAX * 0.4) cut = rest.lastIndexOf(" ", MAX);
    if (cut <= 0) cut = MAX; else cut += 1;
    chunks.push(rest.slice(0, cut));
    rest = rest.slice(cut);
  }
  if (rest) chunks.push(rest);
  let out = "";
  for (const chunk of chunks) {
    const url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto"
      + `&tl=${encodeURIComponent(to)}&dt=t&q=${encodeURIComponent(chunk)}`;
    // `throw: false` so the STATUS is visible here. Letting requestUrl throw
    // collapsed every failure into one "you need internet" message, which is
    // what a tablet reader saw while plainly being online: the real answer was
    // Google rate-limiting the free endpoint.
    const res = await requestUrl({ url, method: "GET", throw: false });
    if (res.status === 429 || res.status === 503) {
      const err = new Error("translate rate-limited");
      err.erReason = "limit";
      throw err;
    }
    if (res.status < 200 || res.status >= 300) {
      const err = new Error("translate http " + res.status);
      err.erReason = "http";
      err.erStatus = res.status;
      throw err;
    }
    const data = res.json;
    if (!Array.isArray(data) || !Array.isArray(data[0])) throw new Error("unexpected translate response");
    out += data[0].map((p) => (p && p[0]) || "").join("");
  }
  return out.trim();
}
/* ── Reading a book in a foreign language ──────────────────────────────────
 *
 * Readers described the same routine: copy a passage out of the book, paste it
 * into a chat model, and ask for a translation plus a word-by-word breakdown —
 * why this word and not another, and sometimes where it came from. Then paste
 * the answer back. This does that without leaving the page.
 *
 * Every provider here speaks OpenAI's chat-completions dialect, so a provider
 * is only a base URL, a key and a model name — one request path for all of them.
 *
 * requestUrl, never fetch: a fetch() from a plugin is a browser request and is
 * subject to CORS, and a local Ollama server refuses the app://obsidian.md
 * origin unless the reader sets OLLAMA_ORIGINS by hand. requestUrl is issued by
 * the app itself, so the local option works with no setup — which is the whole
 * reason for offering it.
 */
const AI_PROVIDERS = {
  eltonlabs:  { label: "Elton AI", needsKey: true,  base: "https://api.eltonlabs.org/v1", model: "anthropic/claude-haiku-4.5" },
  openrouter: { label: "OpenRouter", needsKey: true, base: "https://openrouter.ai/api/v1", model: "anthropic/claude-haiku-4.5" },
  openai:     { label: "OpenAI", needsKey: true, base: "https://api.openai.com/v1", model: "gpt-4.1-mini" },
  // Runs on the reader's own machine; nothing leaves the device.
  local:      { label: "Ollama / LM Studio", needsKey: false, base: "http://localhost:11434/v1", model: "qwen2.5:3b" },
};
function aiConfig(settings) {
  const id = settings.aiProvider || "eltonlabs";
  const p = AI_PROVIDERS[id] || AI_PROVIDERS.eltonlabs;
  return {
    id,
    base: (settings.aiBase || p.base).replace(/\/+$/, ""),
    model: settings.aiModel || p.model,
    key: settings.aiKey || "",
    needsKey: p.needsKey,
  };
}
// One instruction for the whole conversation. The breakdown is not a mode of its
// own: it is simply the question most readers ask first, so it is described here
// and sent as an ordinary message.
function aiSystemChat(into) {
  return [
    `You are helping someone read a book in a language they are still learning.`,
    `They send a passage from it and then talk to you about that passage.`,
    `Answer in ${into}. Use Markdown. Be concise — this is read beside the book, not instead of it.`,
    ``,
    `If they ask for a breakdown of the passage, give exactly these sections:`,
    `1. **Translation** — a natural translation of the whole passage, not word-for-word.`,
    `2. **Words and phrases** — a list of only the words and phrases that are genuinely hard`,
    `   (idioms, rare senses, false friends). Skip anything obvious. For each: the word,`,
    `   its meaning HERE, and its dictionary form if that differs.`,
    `3. **Why it is phrased this way** — the tone, register or construction that a learner`,
    `   would miss: why this wording rather than the plain one. Two or three sentences.`,
    `4. **Word origins** — etymology for at most two words, and only where it actually`,
    `   helps remember them. Omit this section entirely if nothing qualifies.`,
    ``,
    `For anything else, just answer what was asked — no fixed sections, and no`,
    `translation of the whole passage unless that is what they asked for.`,
  ].join("\n");
}
// The reader's own instruction replaces the built-in one entirely. The passage
// rides along with their first message, so the model never sees it as an order.
function aiMessages(text, settings, turns, book) {
  const into = !settings.aiInto || settings.aiInto === "auto" ? outputLanguage() : settings.aiInto;
  const own = (settings.aiSystem || "").trim();
  const msgs = [{ role: "system", content: own || aiSystemChat(into) }];
  // Which book this is from, sent quietly with the passage: a page out of context
  // reads very differently from the same page in a book the model knows.
  const from = String(book || "").trim();
  const head = (from ? `From the book «${from}».\n` : "") + `Passage:\n${text}`;
  turns.forEach((turn, i) => {
    msgs.push(i === 0 && turn.role === "user"
      ? { role: "user", content: `${head}\n\n${turn.content}` }
      : { role: turn.role, content: turn.content });
  });
  return msgs;
}
async function aiExplain(text, settings, turns, book) {
  const cfg = aiConfig(settings);
  if (cfg.needsKey && !cfg.key) {
    const err = new Error("no api key");
    err.erReason = "nokey";
    throw err;
  }
  const headers = { "Content-Type": "application/json" };
  if (cfg.key) headers.Authorization = `Bearer ${cfg.key}`;
  const res = await requestUrl({
    url: `${cfg.base}/chat/completions`,
    method: "POST",
    headers,
    throw: false,
    body: JSON.stringify({
      model: cfg.model,
      messages: aiMessages(text, settings, turns, book),
      temperature: 0.2,
      max_tokens: 900,
    }),
  });
  if (res.status === 401 || res.status === 403) {
    const err = new Error("auth"); err.erReason = "auth"; throw err;
  }
  if (res.status === 429) {
    const err = new Error("rate"); err.erReason = "limit"; throw err;
  }
  if (res.status < 200 || res.status >= 300) {
    const err = new Error("http " + res.status);
    err.erReason = "http";
    err.erStatus = res.status;
    // A local server that is simply not running is the single most likely
    // failure of the local option, and "http 0" explains nothing.
    if (cfg.id === "local") err.erReason = "local";
    throw err;
  }
  const data = res.json;
  let out = data && data.choices && data.choices[0] && data.choices[0].message
    ? String(data.choices[0].message.content || "").trim()
    : "";
  if (!out) { const err = new Error("empty"); err.erReason = "empty"; throw err; }
  return out;
}
// Shows the translation of a selection, with the original kept above it so the
// reader can compare. Actions mirror the popup: copy, or save as a note (the
// note keeps the ORIGINAL quote and puts the translation under it).
const TranslateModal = class extends Modal {
  constructor(app, plugin, text, bookFile) {
    super(app);
    this.plugin = plugin;
    this.text = text;
    this.bookFile = bookFile;
  }
  async onOpen() {
    const c = this.contentEl;
    c.empty();
    c.createEl("h3", { text: __ertr("Translation") });
    const box = (label) => {
      const w = c.createDiv();
      w.addClass("er-tr-box");
      const l = w.createDiv();
      l.setText(label);
      l.addClass("er-tr-label");
      const b = w.createDiv();
      b.style.cssText = "max-height:180px;overflow:auto;padding:10px 12px;border:1px solid var(--background-modifier-border);"
        + "border-radius:8px;background:var(--background-secondary);line-height:1.55;white-space:pre-wrap;user-select:text";
      return b;
    };
    box(__ertr("Original")).setText(this.text);
    const outEl = box(__ertr("Translation"));
    outEl.setText(__ertr("Translating…"));
    let tr = "";
    try {
      tr = await translateText(this.text, this.plugin.settings.translateTo || "auto");
      outEl.setText(tr || __ertr("The translator returned nothing"));
    } catch (e) {
      console.error("Elton Reader: translate failed", e);
      const why = e && e.erReason;
      outEl.setText(
        why === "limit"
          ? __ertr("Google is rate-limiting translations. Wait a minute and try again — this is a limit of the free Google Translate, not of your connection.")
          : why === "http"
            ? __ertr("The translator answered with error {0}. Your connection is fine — try again later.", e.erStatus)
            : __ertr("Could not reach the translator. It looks like there is no internet connection."));
      return;
    }
    new Setting(c)
      .addButton((b) => b.setButtonText(__ertr("Copy translation")).onClick(async () => {
        const ok = await copyToClipboard(tr);
        new Notice(ok ? __ertr("Copied ✓") : __ertr("Could not copy"));
      }))
      .addButton((b) => b.setButtonText(__ertr("To a note")).setCta().onClick(async () => {
        // The note keeps the original as the quote (that's what's citable) and
        // adds the translation beneath it.
        await createNoteFromSelection(this.app, this.plugin, this.text, this.bookFile, {
          open: false, silent: true, extra: __ertr("\n\n**Translation:**\n{0}", tr)
        });
        new Notice(__ertr("Note created"));
        this.close();
      }));
  }
  onClose() { this.contentEl.empty(); }
};
/* Detect mobile through Platform with the legacy fallback. Show a skeleton on the reader root while pagination runs; the layout may clear the inner reading area. */
function erShowVeil(view, text) {
  const host = view && view.areaEl && view.areaEl.parentElement;
  if (!host) return;
  erHideVeil(view);
  const veil = host.createDiv("er-veil");
  const sk = veil.createDiv("er-veil-skel");
  for (let i = 0; i < 8; i++) sk.createDiv("er-veil-line");
  veil.createDiv({ cls: "er-veil-text", text: text || __ertr("Laying out the pages…") });
  view._veil = veil;
}
function erHideVeil(view) {
  if (view && view._veil) {
    view._veil.remove();
    view._veil = null;
  }
}
/* Autofocus only with a physical keyboard. On mobile, blur the input on outside pointerdown to dismiss the keyboard without obscuring dialog actions. */
function erBlurOnTapOutside(root, field) {
  if (!root || !field) return;
  root.addEventListener("pointerdown", (e) => {
    const t = e.target;
    if (t === field) return;
    /* The input and send button count as one composer; sending must not blur the input before submission. */
    if (t instanceof HTMLElement && t.closest(".er-ai-bar, .er-find-bar, input, textarea")) return;
    if (docOf(field).activeElement === field) field.blur();
  });
}
function erAutoFocus(el, delayMs) {
  if (!el || erIsMobile()) return;
  if (delayMs) window.setTimeout(() => { try { el.focus(); } catch { /* optional step; a failure here must not interrupt reading */ } }, delayMs);
  else { try { el.focus(); } catch { /* optional step; a failure here must not interrupt reading */ } }
}
function erIsMobile(app) {
  try {
    if (Platform && typeof Platform.isMobile === "boolean") return Platform.isMobile;
  } catch { /* optional step; a failure here must not interrupt reading */ }
  return !!(app && app.isMobile);
}
// Place the highlight bar.
//
// On mobile it is DOCKED to the bottom of the reader rather than floated over the
// selection: Android/iOS draw their own selection toolbar (copy / share / select
// all) directly above the selected text, as an OS-level layer that always wins.
// Ours used to land in exactly that spot and was permanently hidden behind it.
// On desktop there is no such toolbar, so the bar stays next to the selection.
function positionHlPopup(view, rect, fallbackW, fallbackH) {
  const pop = view.hlPopup;
  const root = view.contentEl;
  if (erIsMobile(view.app)) {
    // Docked rather than floated: Android and iOS draw their own selection
    // toolbar (copy / share / select all) directly over the selection, as an
    // OS layer that always wins, and ours used to land underneath it.
    //
    // Which edge it docks to is chosen per selection. Always docking to the
    // bottom left it half a screen away on a tablet — a reader said he did not
    // even notice it had appeared. Docking to the edge FURTHEST from the
    // selection keeps it clear of the OS toolbar while staying in view.
    // Just BELOW the selection, not pinned to the bottom of the screen.
    //
    // Both extremes were wrong. Floating it over the selection buried it under
    // the OS toolbar; pinning it to the bottom edge put it a whole page away
    // from what you had just selected. Below the selection is the one place
    // that is neither: Android and iOS put their own toolbar ABOVE the
    // selection, so the space underneath is free, and the bar appears where the
    // eye already is.
    const rootRect = root.getBoundingClientRect();
    const barH = pop.offsetHeight || fallbackH || 92;
    const barW = pop.offsetWidth || fallbackW || 260;
    // Keep clear of the page controls at the foot of the reader.
    const bottomLimit = rootRect.height - barH - 74;
    const hasRect = rect && rect.height;
    let top = hasRect ? rect.bottom - rootRect.top + 12 : bottomLimit;
    // No room underneath (selection near the foot of the page) — go above it
    // instead, which on that part of the screen is where the OS toolbar is not.
    if (top > bottomLimit) {
      const above = (hasRect ? rect.top - rootRect.top : 0) - barH - 12;
      top = above > 8 ? above : Math.max(8, bottomLimit);
    }
    pop.classList.add("er-hl-popup-docked");
    pop.style.removeProperty("bottom");
    pop.style.top = `${Math.round(Math.max(8, top))}px`;
    // Centred on the selection, then kept inside the page.
    const wantLeft = hasRect
      ? rect.left - rootRect.left + rect.width / 2 - barW / 2
      : (rootRect.width - barW) / 2;
    pop.style.left = `${Math.round(Math.max(8, Math.min(wantLeft, rootRect.width - barW - 8)))}px`;
    return;
  }
  pop.classList.remove("er-hl-popup-docked");
  const rootRect = root.getBoundingClientRect();
  const pw = pop.offsetWidth || fallbackW, ph = pop.offsetHeight || fallbackH;
  let left = rect.left - rootRect.left + rect.width / 2 - pw / 2;
  let top = rect.top - rootRect.top - ph - 10;
  if (top < 4) top = rect.bottom - rootRect.top + 10;
  left = Math.max(6, Math.min(left, root.clientWidth - pw - 6));
  /* Clamp the selection toolbar to the visible reading area, even when its paragraph is offscreen in scrolling mode. */
  top = Math.max(6, Math.min(top, rootRect.height - ph - 6));
  pop.style.left = `${left}px`;
  pop.style.top = `${top}px`;
}
// Wire up the per-page "note" buttons that sit on image/scan pages. Shared by
// both readers. Click → a note for that page, linked back to the book, with the
// page's text as the quote when the PDF has a text layer (on a true scan there
// is none, so the note opens ready for the reader's own words).
function bindPdfNoteButtons(view) {
  const flow = view.pager && view.pager.flow;
  if (!flow) return;
  flow.querySelectorAll("button.er-pdf-note-btn").forEach((btn) => {
    if (btn.dataset.bound === "1") return;
    btn.dataset.bound = "1";
    // The reader turns pages on click in "click" nav mode — this button must not
    // count as a page turn, nor start a text selection.
    btn.addEventListener("mousedown", (e) => { e.stopPropagation(); e.preventDefault(); });
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      e.preventDefault();
      const pageNo = parseInt(btn.dataset.pdfNotePage, 10);
      await createNoteFromPdfPage(view, pageNo, btn);
    });
  });
}
// Build the note for a single PDF page.
async function createNoteFromPdfPage(view, pageNo, btn) {
  const app = view.app, plugin = view.plugin, file = view.file;
  if (!file) return;
  try {
    // Any text the page does have (the figure sits above it in the same page div).
    let pageText = "";
    const holder = btn && btn.closest ? btn.closest("[data-pdf-page-no]") : null;
    if (holder) {
      pageText = [...holder.querySelectorAll("p")]
        .map((p) => (p.textContent || "").trim())
        .filter(Boolean)
        .join("\n\n")
        .slice(0, 4000);
    }
    const linkName = bookNoteLinkFor(plugin, file) || file.basename;
    const title = sanitizeNoteTitle(__ertr("{0} — p. {1}", file.basename, pageNo));
    // Same folder rules as a note made from a highlight, so scan pages don't
    // land somewhere else than the rest of a book's notes.
    let folderOverride = null;
    if (plugin.settings.notesNextToBook && file.parent) {
      const beside = erPath(file.parent.path || "");
      if (beside) folderOverride = beside;
    }
    let filename = title, n = 2;
    while (app.vault.getAbstractFileByPath(inboxNotePath(app, filename, folderOverride))) filename = `${title} ${n++}`;
    const quote = pageText
      ? pageText.split("\n\n").map((p) => `> ${p}`).join("\n>\n")
      : __ertr("> *(scanned page — no text to quote, write it in your own words)*");
    // A scanned page has no paragraph to anchor to, so the backlink points at
    // the page — still one click from the note back to where it came from.
    const back = plugin.settings.quoteBacklinks !== false
      ? ` [${backlinkLabel(plugin)}](obsidian://book-reader-tts?book=${encodeURIComponent(file.path)}&page=${pageNo})`
      : "";
    const body = `${quote}\n\n${__ertr("— from [[{0}]], p. {1}", linkName, pageNo)}${back}\n`;
    await resolveNotesFolder(app, folderOverride);
    const path5 = inboxNotePath(app, filename, folderOverride);
    const note = await app.vault.create(path5, body);
    if (note instanceof TFile) {
      await appendLinkToBookNote(app, plugin, file, note);
      new Notice(__ertr("Note created: {0}", note.basename));
      await openNoteBesideBook(app, plugin, note);
    }
  } catch (e) {
    console.error("Elton Reader: note from PDF page failed", e);
    new Notice(__ertr("Could not create the note"));
  }
}
// Follow a footnote reference, and leave a way back.
//
// A note you can reach but not return from is worse than no link at all: the
// reader ends up in the endnotes with no idea which page they left. So the
// origin spread is remembered and offered as a pill until it is used.
function followFootnote(view, ref) {
  const flow = view.pager && view.pager.flow;
  if (!flow || !ref) return false;
  const target = flow.querySelector(`[data-er-id="${CSS.escape(ref)}"]`);
  if (!target) return false;
  const from = view.pager.currentSpread;
  /* Resolve footnote destinations by paragraph index, which works in both paginated and scrolling layouts; horizontal offsets do not. */
  const blocks = Array.from(flow.querySelectorAll("p,h1,h2,h3,h4"));
  const owner = (target.closest && target.closest("p,h1,h2,h3,h4"))
    || (target.querySelector && target.querySelector("p,h1,h2,h3,h4"))
    || target;
  const idx = blocks.indexOf(owner);
  /* If no destination paragraph exists, leave the reader in place instead of jumping to page one. */
  if (idx < 0) return false;
  const spread = view.pager.spreadForBlock(idx);
  const [cur, tot] = view.pager.jumpTo(spread);
  (view.updateUI || view._updateUI).call(view, cur, tot);
  showFootnoteReturn(view, from);
  return true;
}
function showFootnoteReturn(view, spread) {
  hideFootnoteReturn(view);
  const host = view.areaEl;
  if (!host) return;
  const pill = host.createDiv("er-note-back");
  iconLabel(pill, "arrow-left", __ertr("Back to the text"));
  pill.setAttribute("role", "button");
  pill.setAttribute("tabindex", "0");
  const go = () => {
    const [cur, tot] = view.pager.jumpTo(spread);
    (view.updateUI || view._updateUI).call(view, cur, tot);
    hideFootnoteReturn(view);
  };
  pill.addEventListener("click", go);
  pill.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); }
  });
  view._noteBackEl = pill;
}
function hideFootnoteReturn(view) {
  if (view._noteBackEl) { view._noteBackEl.remove(); view._noteBackEl = null; }
}
function addAiBtn(view, pop) {
  if (!view.plugin.settings.aiEnabled) return;
  const btn = pop.createDiv("er-hl-sw er-hl-ai");
  svgIcon(btn, "sparkles");
  btn.setAttribute("aria-label", __ertr("Break this passage down"));
  btn.addEventListener("click", () => {
    const cur = view._currentHl();
    view._hideHlPopup();
    selOf(view.areaEl)?.removeAllRanges();
    if (!cur) return;
    new AiExplainModal(view.app, view.plugin, cur.text, view.file).open();
  });
}
/* Handle the desktop and mobile method names consistently. Position the selection popup using nonempty line rectangles clipped to the visible page, not the oversized union rectangle. */
function erSelectionRect(range, areaEl) {
  let rects = [];
  try {
    rects = [...range.getClientRects()].filter((r) => r.width > 0.5 && r.height > 0.5);
  } catch { /* optional step; a failure here must not interrupt reading */ }
  if (!rects.length) return range.getBoundingClientRect();
  const box = areaEl ? areaEl.getBoundingClientRect() : null;
  if (box) {
    const seen = rects.filter((r) => r.right > box.left + 1 && r.left < box.right - 1);
    if (seen.length) rects = seen;
  }
  const left = Math.min(...rects.map((r) => r.left));
  const right = Math.max(...rects.map((r) => r.right));
  const top = Math.min(...rects.map((r) => r.top));
  const bottom = Math.max(...rects.map((r) => r.bottom));
  return { left, right, top, bottom, width: right - left, height: bottom - top, x: left, y: top };
}
function erRefreshHlPanel(view) {
  const fn = view.buildHlPanel || view._buildHlPanel;
  if (typeof fn === "function") fn.call(view);
}
function erOpenHlPanel(view) {
  const fn = view.togglePanel || view._togglePanel;
  if (view.panelOpen !== "highlights" && typeof fn === "function") fn.call(view, "highlights");
}
/* Keep frequent desktop selection actions nearby; on mobile use a compact overflow menu so controls do not obscure the selected text. */
function addBarButtons(view, pop) {
  if (erIsMobile()) return;
  for (const c of HL_COLORS) {
    const sw = pop.createDiv("er-hl-sw");
    sw.style.background = c.css;
    sw.setAttribute("aria-label", c.name);
    sw.addEventListener("click", () => view._applyPopupColor(c.id));
  }
  const act = (cls, icon2, label, fn) => {
    const b = pop.createDiv("er-hl-sw " + cls);
    svgIcon(b, icon2);
    b.setAttribute("aria-label", label);
    b.addEventListener("click", fn);
    return b;
  };
  act("er-hl-copy", "copy", __ertr("Copy text"), async () => {
    const cur = view._currentHl();
    view._hideHlPopup();
    selOf(view.areaEl)?.removeAllRanges();
    if (!cur) return;
    const ok = await copyToClipboard(cur.text);
    new Notice(ok ? __ertr("Copied ✓") : __ertr("Could not copy"));
  });
  act("er-hl-note", "note", __ertr("Create note"), () => {
    const cur = view._currentHl();
    view._hideHlPopup();
    selOf(view.areaEl)?.removeAllRanges();
    if (!cur) return;
    createNoteFromSelection(view.app, view.plugin, cur.text, view.file, { extra: hlCommentMd(cur), color: cur.color, hl: cur });
  });
  addAiBtn(view, pop);
}
function addMoreBtn(view, pop) {
  const btn = pop.createDiv("er-hl-sw er-hl-menu");
  svgIcon(btn, "more");
  btn.setAttribute("aria-label", __ertr("More"));
  btn.addEventListener("click", (e) => {
    // Read before hiding: hiding the bar is what forgets which passage this was.
    const cur = view._currentHl();
    const editId = view._editHlId;
    const pending = view._pendingSel;
    view._hideHlPopup();
    selOf(view.areaEl)?.removeAllRanges();
    if (!cur) return;
    const menu = new Menu();
    /* Order menu actions by frequency; include all text actions here because the inline toolbar is intentionally minimal. */
    menu.addItem((it) => it.setTitle(__ertr("Copy text")).setIcon("copy").onClick(async () => {
      const ok = await copyToClipboard(cur.text);
      new Notice(ok ? __ertr("Copied ✓") : __ertr("Could not copy"));
    }));
    menu.addItem((it) => it.setTitle(__ertr("Create note")).setIcon("file-plus").onClick(() => {
      createNoteFromSelection(view.app, view.plugin, cur.text, view.file, { extra: hlCommentMd(cur), color: cur.color, hl: cur });
    }));
    /* Offer append-to-book-note only when a book note is linked; otherwise there is no valid destination. */
    if (bookNoteLinkFor(view.plugin, view.file)) {
      menu.addItem((it) => it.setTitle(__ertr("As text into the book note")).setIcon("text-quote").onClick(() => {
        sendQuoteToBookNote(view, cur);
      }));
    }
    if (view.plugin.settings.aiEnabled) {
      menu.addItem((it) => it.setTitle(__ertr("Break this passage down")).setIcon("sparkles").onClick(() => {
        new AiExplainModal(view.app, view.plugin, cur.text, view.file).open();
      }));
    }
    menu.addSeparator();
    /* Put colors in the menu too, minimizing controls over the book. */
    for (const c of HL_COLORS) {
      menu.addItem((it) => it.setTitle(__ertr("Highlight: {0}", (c.name))).setIcon("highlighter").onClick(() => {
        /* Restore the saved selection after opening the menu, since hiding the popup clears the live selection. */
        view._pendingSel = pending;
        view._editHlId = editId;
        view._applyPopupColor(c.id);
      }));
    }
    menu.addSeparator();
    menu.addItem((it) => it.setTitle(__ertr("Copy as a quote")).setIcon("text-quote").onClick(async () => {
      const md = quoteMarkdown(view.plugin, cur, view.file);
      const ok = md && await copyToClipboard(md);
      new Notice(ok ? __ertr("Quote copied ✓ — paste it into any note") : __ertr("Could not copy"));
    }));
    menu.addItem((it) => it.setTitle(__ertr("Stopped here")).setIcon("bookmark").onClick(() => {
      if (!view.file) return;
      const pct = view.plugin.saveNow(view.file.path, view.pager.spread, view.pager.total, cur.block);
      new Notice(__ertr("\"Stopped here\" bookmark — {0}%", (pct)));
      if (view.panelOpen === "settings" && typeof view._renderHistory === "function") view._renderHistory();
    }));
    // A thought in the margin. Distinct from "create a note": this stays WITH the
    // highlight instead of becoming a separate file.
    menu.addItem((it) => it.setTitle(__ertr("Comment on a highlight")).setIcon("message-square").onClick(() => {
      if (!view.file) return;
      let id = editId;
      const existing = id ? view.plugin.getHighlights(view.file.path).find((h) => h.id === id) : null;
      new HighlightCommentModal(view.app, (existing && existing.comment) || "", async (text) => {
        if (text === null) return;
        // Commenting on a plain selection turns it INTO a highlight first: a
        // comment has to hang on something.
        if (!id && pending) id = view._createHighlight(pending, view.plugin.settings.defaultHlColor || HL_COLORS[0].id);
        if (!id) { new Notice(__ertr("Could not save the comment")); return; }
        await view.plugin.setHighlightComment(view.file.path, id, cur, text);
        view._renderFlowHighlights();
        erRefreshHlPanel(view);
        erOpenHlPanel(view);
      }).open();
    }));
    if (view.plugin.settings.translateEnabled) {
      menu.addItem((it) => it.setTitle(__ertr("Translate")).setIcon("languages").onClick(() => {
        new TranslateModal(view.app, view.plugin, cur.text, view.file).open();
      }));
    }
    menu.addItem((it) => it.setTitle(__ertr("Export to the book note")).setIcon("download").onClick(() => {
      if (view.file) sendQuoteToBookNote(view, cur);
    }));
    // Only for a highlight that already exists — there is nothing to delete
    // about a selection the reader has not coloured yet.
    if (editId) {
      menu.addSeparator();
      menu.addItem((it) => it.setTitle(__ertr("Delete highlight")).setIcon("trash-2").setWarning(true).onClick(() => {
        if (!view.file) return;
        view.plugin.removeHighlight(view.file.path, editId);
        view._unwrapHighlight(editId);
        if (view.panelOpen === "highlights") erRefreshHlPanel(view);
      }));
    }
    menu.showAtMouseEvent(e);
  });
}
// The breakdown itself: the passage on top, the answer under it, and the two
// things a reader wants to do with it — copy it, or keep it under the quote.
const AiExplainModal = class extends Modal {
  constructor(app, plugin, text, bookFile) {
    super(app);
    this.plugin = plugin;
    this.text = text;
    this.bookFile = bookFile;
    this.book = bookFile ? bookNoteLinkFor(plugin, bookFile) || bookFile.basename : "";
    // What has been said so far, in the shape the service wants it. Nothing is
    // sent until the reader says something: the passage alone is not a question.
    this.turns = [];
  }
  async onOpen() {
    const c = this.contentEl;
    c.empty();
    this.modalEl.addClass("er-ai-modal");
    // A chat is a column: a head that stays, a log that grows and scrolls, and
    // a composer pinned under it. On a phone the three used to be four stacked
    // rows of buttons with the conversation squeezed into the gap between them.
    const head = c.createDiv("er-ai-head");
    head.createDiv({ cls: "er-ai-title", text: __ertr("Talking about the passage") });
    if (this.book) head.createDiv({ cls: "er-ai-book", text: this.book });
    // The passage is context, not the subject: two lines, and it opens on a tap
    // for the times the reader wants to check the wording.
    const quote = c.createDiv({ cls: "er-ai-quote", text: this.text });
    quote.addEventListener("click", () => quote.classList.toggle("er-ai-quote-open"));
    this.log = c.createDiv("er-ai-log");
    this._buildEmpty();
    const bar = c.createDiv("er-ai-bar");
    const input = bar.createEl("input", { cls: "er-ai-input", type: "text" });
    input.placeholder = __ertr("Message…");
    const send = bar.createEl("button", { cls: "er-ai-send" });
    svgIcon(send, "send");
    send.setAttribute("aria-label", __ertr("Send"));
    const fire = async () => {
      const q = input.value.trim();
      if (!q) return;
      /* Blur the composer immediately while waiting for a response so the mobile keyboard does not hide the conversation. */
      input.blur();
      /* Clear the composer as soon as the message is appended; restore its text on failure to allow retrying. */
      input.value = "";
      if (!await this._send(q)) input.value = q;
    };
    send.addEventListener("click", fire);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); fire(); }
    });
    erAutoFocus(input);
    erBlurOnTapOutside(c, input);
    this._watchKeyboard();
  }
  /* Use Capacitor keyboard height events to resize mobile dialogs; iOS visualViewport does not reliably shrink above the keyboard. */
  _watchKeyboard() {
    const modal = this.modalEl;
    const height = (e) => {
      const h = e && (e.keyboardHeight != null ? e.keyboardHeight
        : e.detail && e.detail.keyboardHeight);
      return typeof h === "number" && h > 0 ? h : 0;
    };
    this._kbShow = (e) => {
      const h = height(e);
      if (!h) return;
      modal.style.setProperty("--er-kb", h + "px");
      modal.addClass("er-kb-up");
      window.setTimeout(() => this._scroll(), 60);
    };
    this._kbHide = () => {
      modal.removeClass("er-kb-up");
      modal.style.removeProperty("--er-kb");
    };
    window.addEventListener("keyboardWillShow", this._kbShow);
    window.addEventListener("keyboardDidShow", this._kbShow);
    window.addEventListener("keyboardWillHide", this._kbHide);
  }
  // An empty chat should say what it is for and offer the one thing most
  // readers want first, instead of showing a bare input and a lone chip.
  _buildEmpty() {
    const empty = this.log.createDiv("er-ai-empty");
    svgIcon(empty.createDiv("er-ai-empty-icon"), "sparkles");
    empty.createDiv({ cls: "er-ai-empty-title", text: __ertr("What would you like to ask?") });
    empty.createDiv({
      cls: "er-ai-empty-sub",
      text: __ertr("Ask anything about this passage — or start with a breakdown."),
    });
    const chip = empty.createEl("button", { cls: "er-ai-chip", text: __ertr("Break this passage down") });
    chip.addEventListener("click", () => this._send(chip.textContent));
    this.empty = empty;
  }
  _scroll() { this.log.scrollTop = this.log.scrollHeight; }
  // Copy / keep, hung under the answer they belong to. A single pair of buttons
  // at the bottom of the window could only ever act on the last answer, and it
  // cost a whole row of a phone screen to say so.
  _actions(group, answer) {
    const row = group.createDiv("er-ai-acts");
    const act = (icon2, label, fn) => {
      const b = row.createEl("button", { cls: "er-ai-act" });
      svgIcon(b, icon2);
      b.createSpan({ text: label });
      b.addEventListener("click", fn);
      return b;
    };
    act("copy", __ertr("Copy"), async () => {
      const ok = await copyToClipboard(answer);
      new Notice(ok ? __ertr("Copied ✓") : __ertr("Could not copy"));
    });
    act("note", __ertr("To a note"), async () => {
      await createNoteFromSelection(this.app, this.plugin, this.text, this.bookFile, {
        extra: "\n\n" + answer,
        // The note is written mid-reading: it gets its own tab, but the book
        // stays in front — the reader goes to the note when they want to.
        openMode: "tab",
        openBackground: true,
      });
      this.close();
    });
  }
  // Sends one message and hangs the answer under it. Returns whether it went
  // through, so the input knows whether to clear itself.
  async _send(text) {
    if (this.busy || !text) return false;
    this.busy = true;
    if (this.empty) { this.empty.remove(); this.empty = null; }
    const me = this.log.createDiv("er-ai-msg er-ai-msg-me");
    me.setText(text);
    this.turns.push({ role: "user", content: text });
    const group = this.log.createDiv("er-ai-group");
    const bubble = group.createDiv("er-ai-msg er-ai-msg-ai");
    // Waiting looks like waiting: three dots that actually move, the same
    // indicator Elton AI uses. A still line of text reads as a frozen window.
    const ind = bubble.createDiv("er-ai-typing");
    const dots = ind.createDiv("er-ai-typing-dots");
    for (let i = 0; i < 3; i++) dots.createDiv("er-ai-typing-dot");
    ind.createDiv({ cls: "er-ai-typing-text", text: __ertr("Thinking…") });
    this._scroll();
    let answer = "";
    try {
      answer = await aiExplain(this.text, this.plugin.settings, this.turns, this.book);
    } catch (e) {
      console.error("Book Reader TTS: AI chat failed", e);
      // The unanswered message leaves the thread: keeping it would send the same
      // question twice as soon as the next one is asked.
      this.turns.pop();
      const why = e && e.erReason;
      bubble.addClass("er-ai-msg-err");
      bubble.setText(
        why === "nokey" ? __ertr("No key set. Open the plugin settings → AI breakdown and paste the key for your service.")
          : why === "auth" ? __ertr("The service rejected the key. Check it in the plugin settings.")
            : why === "limit" ? __ertr("The service is rate-limiting. Wait a minute and try again.")
              : why === "local" ? __ertr("The local model is not answering. Check that Ollama or LM Studio is running.")
                : why === "empty" ? __ertr("The model returned nothing.")
                  : why === "http" ? __ertr("The service answered with error {0}.", e.erStatus)
                    : __ertr("Could not reach the service. It looks like there is no internet connection."));
      this._scroll();
      this.busy = false;
      return false;
    }
    this.turns.push({ role: "assistant", content: answer });
    this.answer = answer;
    bubble.empty();
    // Rendered as Markdown so the sections and lists read as sections and lists.
    await MarkdownRenderer.render(this.app, answer, bubble, this.bookFile ? this.bookFile.path : "", this);
    this._actions(group, answer);
    this._scroll();
    this.busy = false;
    return true;
  }
  onClose() {
    if (this._kbShow) {
      window.removeEventListener("keyboardWillShow", this._kbShow);
      window.removeEventListener("keyboardDidShow", this._kbShow);
    }
    if (this._kbHide) window.removeEventListener("keyboardWillHide", this._kbHide);
    this.contentEl.empty();
  }
};
function decodeFb2(buf) {
  const bytes = new Uint8Array(buf);
  let head = "";
  for (let i = 0; i < Math.min(bytes.length, 256); i++) head += String.fromCharCode(bytes[i]);
  const m = head.match(/encoding\s*=\s*["']([\w-]+)["']/i);
  const enc = (m ? m[1] : "utf-8").toLowerCase();
  try {
    return new TextDecoder(enc).decode(bytes);
  } catch {
    return new TextDecoder("utf-8").decode(bytes);
  }
}
function fb2Href(el) {
  let href = "";
  try {
    href = el.getAttributeNS("http://www.w3.org/1999/xlink", "href") || "";
  } catch { /* optional step; a failure here must not interrupt reading */ }
  if (!href) {
    for (const a of Array.from(el.attributes || [])) {
      if (a.name === "href" || a.name.endsWith(":href")) {
        href = a.value;
        break;
      }
    }
  }
  return href.replace(/^#/, "");
}
function fb2ImgSrc(el, images) {
  const id = fb2Href(el);
  return id ? images[id] || "" : "";
}
function fb2Img(src) {
  return `<img src="${escHtml(src)}" style="max-width:100%;height:auto;display:block;margin:8px auto">`;
}
function fb2Inline(el) {
  let out = "";
  for (const node of Array.from(el.childNodes || [])) {
    if (node.nodeType === 3) {
      out += escHtml(node.textContent || "");
      continue;
    }
    if (node.nodeType !== 1) continue;
    const t = (node.tagName || "").toLowerCase();
    const inner = fb2Inline(node);
    if (t === "emphasis") out += `<i>${inner}</i>`;
    else if (t === "strong") out += `<b>${inner}</b>`;
    else if (t === "strikethrough") out += `<s>${inner}</s>`;
    else if (t === "sup") out += `<sup>${inner}</sup>`;
    else if (t === "sub") out += `<sub>${inner}</sub>`;
    else if (t === "code") out += `<code>${inner}</code>`;
    else if (t === "a") {
      const ref = fb2Href(node);
      out += ref ? `<a class="er-fb2-ref" data-er-ref="${escHtml(ref)}">${inner}</a>` : inner;
    } else out += inner;
  }
  return out;
}
function fb2IsCodeLine(el) {
  const all = (el.textContent || "").replace(/\s/g, "").length;
  if (!all) return false;
  let inCode = 0;
  for (const c of Array.from(el.children || [])) {
    if ((c.tagName || "").toLowerCase() === "code") inCode += (c.textContent || "").replace(/\s/g, "").length;
  }
  return inCode / all >= 0.9;
}
function fb2MergeCode(out) {
  const html = [];
  let block = null;
  const flush = () => {
    if (!block || !block.length) {
      block = null;
      return;
    }
    const body = block.join("\n");
    if (body.trim()) html.push(`<pre class="er-code"><code>${escHtml(body)}</code></pre>`);
    block = null;
  };
  for (const item of out) {
    if (item && typeof item === "object" && typeof item.codeLine === "string") {
      (block || (block = [])).push(item.codeLine);
      continue;
    }
    flush();
    if (typeof item === "string") html.push(item);
  }
  flush();
  return html;
}
function fb2Node(el, images, out) {
  const tag = (el.tagName || "").toLowerCase();
  if (tag === "title") {
    const t = (el.textContent || "").replace(/\s+/g, " ").trim();
    if (t) out.push(`<h2>${escHtml(t)}</h2>`);
    return;
  }
  if (tag === "subtitle") {
    const t = (el.textContent || "").replace(/\s+/g, " ").trim();
    if (t) out.push(`<h3>${escHtml(t)}</h3>`);
    return;
  }
  if (tag === "p" || tag === "v" || tag === "text-author") {
    if (tag === "p" && fb2IsCodeLine(el)) {
      out.push({ codeLine: (el.textContent || "").replace(/\s+$/, "") });
      return;
    }
    const raw = (el.textContent || "").replace(/\s+/g, " ").trim();
    const toc = tocLineHtml(raw);
    if (toc) {
      out.push(toc);
      return;
    }
    const inner = fb2Inline(el);
    if (inner.trim()) out.push(`<p>${inner}</p>`);
    return;
  }
  if (tag === "empty-line") return;
  if (tag === "image") {
    const src = fb2ImgSrc(el, images);
    if (src) out.push(fb2Img(src));
    return;
  }
  if (tag === "binary" || tag === "description") return;
  for (const child of Array.from(el.children || [])) fb2Node(child, images, out);
}
async function extractFb2(file, app) {
  const buf = await app.vault.readBinary(file);
  const bytes = new Uint8Array(buf);
  if (bytes[0] === 80 && bytes[1] === 75) {
    new Notice(__ertr("This FB2 is packed in a ZIP. Unpack the archive and put the .fb2 file itself into your vault."), 8e3);
    throw new Error("FB2 is zipped");
  }
  const doc = new DOMParser().parseFromString(decodeFb2(buf), "application/xml");
  if (doc.getElementsByTagName("parsererror").length) throw new Error("FB2 parse error");
  const images = {};
  for (const b of Array.from(doc.getElementsByTagName("binary"))) {
    const id = b.getAttribute("id");
    const ct = b.getAttribute("content-type") || "image/jpeg";
    const data = (b.textContent || "").replace(/\s+/g, "");
    if (id && data) images[id] = `data:${ct};base64,${data}`;
  }
  const parts = [];
  const cp = doc.getElementsByTagName("coverpage")[0];
  const coverImg = cp && cp.getElementsByTagName("image")[0];
  if (coverImg) {
    const src = fb2ImgSrc(coverImg, images);
    if (src) parts.push(`<div class="er-section">${fb2Img(src)}</div>`);
  }
  for (const body of Array.from(doc.getElementsByTagName("body"))) {
    for (const child of Array.from(body.children || [])) {
      let out = [];
      fb2Node(child, images, out);
      const html = fb2MergeCode(out).join("\n");
      const secId = child.getAttribute && child.getAttribute("id");
      const idAttr = secId ? ` data-er-id="${escHtml(secId)}"` : "";
      if (html.trim()) parts.push(`<div class="er-section"${idAttr}>${html}</div>`);
    }
  }
  if (!parts.length) throw new Error("FB2 has no readable text");
  return parts.join("\n");
}
async function extractPdf(file, app, settings = {}, onProgress) {
  await setupWorker(app);
  const alsoFigOnText = settings.pdfShowFiguresOnTextPages === true;
  const buf = await app.vault.readBinary(file);
  const doc = await pdfjsLib.getDocument({
      data: buf,
      /* Disable PDF font evaluation to mitigate CVE-2024-4367 without changing page layout. */
      isEvalSupported: false,
    }).promise;
  const total = doc.numPages;
  const parts = [];
  const figRects = {};
  for (let i = 1; i <= total; i++) {
    if (onProgress && (i === 1 || i % 4 === 0 || i === total)) onProgress(i, total);
    const page = await doc.getPage(i);
    const tc = await page.getTextContent();
    pdfFixShiftedCyrillic(tc.items);
    const textLen = tc.items.reduce((n, it) => n + (typeof it.str === "string" ? it.str.replace(/\s+/g, "").length : 0), 0);
    const view = page.view || [0, 0, 612, 792];
    const pw = Math.max(1, Math.round(Math.abs(view[2] - view[0])));
    const ph = Math.max(1, Math.round(Math.abs(view[3] - view[1])));
    const textHtml = textLen > 0 ? pdfItemsToHtml(tc.items, tc.styles) : "";
    let html = textHtml;
    const brokenText = textLen >= 40 && pdfTextLooksUnreadable(tc.items);
    if (textLen < 40 || brokenText) {
      const fig = await pdfFigureScore(page);
      if (brokenText || fig && (fig.imgFrac >= 0.02 || fig.vectorOps >= 20 || fig.shading > 0)) {
        html = `<figure class="er-pdf-figure"><img class="er-pdf-page-img er-pdf-lazy" data-pdf-page="${i}" width="${pw}" height="${ph}" alt="">${pdfNoteBtn(i)}</figure>` + (brokenText ? "" : textHtml);
      }
    } else if (alsoFigOnText) {
      const fig = await pdfFigureScore(page);
      const picked = fig ? pdfPickFigures(fig.rects, view) : [];
      if (picked.length) {
        figRects[i] = picked;
        const figsHtml = picked.map((r, k) => {
          const rw = Math.max(1, Math.round(r.x1 - r.x0));
          const rh = Math.max(1, Math.round(r.y1 - r.y0));
          return `<figure class="er-pdf-figure"><img class="er-pdf-page-img er-pdf-lazy" data-pdf-page="${i}" data-pdf-rect="${k}" width="${rw}" height="${rh}" alt=""></figure>`;
        }).join("");
        const inside = (it) => {
          const x = it.transform[4], y = it.transform[5];
          return picked.some((r) => x >= r.x0 - 1 && x <= r.x1 + 1 && y >= r.y0 - 1 && y <= r.y1 + 1);
        };
        const outside = tc.items.filter((it) => !inside(it));
        const keptEnough = outside.length >= tc.items.length * 0.25;
        const bodyHtml = outside.length < tc.items.length && keptEnough ? pdfItemsToHtml(outside, tc.styles) : textHtml;
        html = figsHtml + bodyHtml;
      } else if (fig && fig.imgFrac >= 0.02) {
        html = `<figure class="er-pdf-figure"><img class="er-pdf-page-img er-pdf-lazy" data-pdf-page="${i}" width="${pw}" height="${ph}" alt="">${pdfNoteBtn(i)}</figure>` + textHtml;
      }
    }
    if (html) parts.push(`<div class="er-pdf-page-break" data-pdf-page-no="${i}">${html}</div>`);
  }
  const outline = [];
  try {
    const walk2 = async (nodes, level) => {
      for (const n of nodes || []) {
        let page = null;
        try {
          const dest = typeof n.dest === "string" ? await doc.getDestination(n.dest) : n.dest;
          if (Array.isArray(dest) && dest[0]) page = await doc.getPageIndex(dest[0]) + 1;
        } catch { /* optional step; a failure here must not interrupt reading */ }
        const label = String(n.title || "").replace(/\s+/g, " ").trim();
        if (label && page) outline.push({ label, page, level });
        if (n.items && n.items.length) await walk2(n.items, level + 1);
      }
    };
    await walk2(await doc.getOutline(), 0);
  } catch (e) {
    console.warn("Book Reader TTS: PDF outline unavailable", e);
  }
  const lazy = {
    _doc: doc,
    _rects: figRects,
    // Painting a page has to be given a deadline. pdf.js will happily spend
    // minutes on one pathological page — measured at over 90 seconds on a page
    // whose neighbours needed five — and while it does, the figure loader is
    // holding its "busy" flag, so every other picture in the book waits behind
    // that one page and the reader looks as though images simply stopped
    // appearing. Racing the deadline is not enough on its own: the abandoned
    // render must be CANCELLED, or it keeps burning the same CPU it was taken
    // off. The task's own rejection is swallowed here, since by then the caller
    // has already been told by the deadline.
    async _paint(task, ms) {
      task.promise.catch(() => {
      });
      let timer = null;
      try {
        await Promise.race([
          task.promise,
          new Promise((_, rej) => {
            timer = window.setTimeout(() => {
              try {
                task.cancel();
              } catch { /* optional step; a failure here must not interrupt reading */ }
              rej(new Error("er-render-budget"));
            }, ms);
          })
        ]);
      } finally {
        window.clearTimeout(timer);
      }
    },
    // rectIdx === null → the whole page (a scan: the page IS the content).
    // Otherwise crop to one picture: the canvas is sized to the FIGURE and the
    // context shifted, so only that region lands on it — the reader sees the
    // illustration itself rather than a screenshot of the page around it.
    async render(pageNum, rectIdx) {
      const page = await doc.getPage(pageNum);
      const base = page.getViewport({ scale: 1 });
      const r = rectIdx == null ? null : (this._rects[pageNum] || [])[rectIdx] || null;
      if (!r) {
        const full = Math.max(1, Math.min(2, 1600 / Math.max(base.width, base.height, 1)));
        for (const [scale2, budget] of [[full, 15e3], [full / 2, 8e3]]) {
          const vp2 = page.getViewport({ scale: scale2 });
          const cv2 = document.createElement("canvas");
          cv2.width = Math.ceil(vp2.width);
          cv2.height = Math.ceil(vp2.height);
          const ctx2 = cv2.getContext("2d");
          ctx2.fillStyle = "#ffffff";
          ctx2.fillRect(0, 0, cv2.width, cv2.height);
          try {
            await this._paint(page.render({ canvasContext: ctx2, viewport: vp2 }), budget);
            return cv2.toDataURL("image/jpeg", 0.78);
          } catch (e) {
            if (String(e && e.message) !== "er-render-budget") throw e;
          }
        }
        throw new Error("er-render-too-heavy");
      }
      const rw = Math.max(1, r.x1 - r.x0), rh = Math.max(1, r.y1 - r.y0);
      const scale = Math.max(1, Math.min(3, 1400 / Math.max(rw, rh)));
      const vp = page.getViewport({ scale });
      const [ax, ay] = vp.convertToViewportPoint(r.x0, r.y0);
      const [bx, by] = vp.convertToViewportPoint(r.x1, r.y1);
      const left = Math.min(ax, bx), top = Math.min(ay, by);
      const cw = Math.max(1, Math.round(Math.abs(bx - ax)));
      const ch = Math.max(1, Math.round(Math.abs(by - ay)));
      const cv = document.createElement("canvas");
      cv.width = cw;
      cv.height = ch;
      const ctx = cv.getContext("2d");
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, cw, ch);
      ctx.translate(-left, -top);
      try {
        await this._paint(page.render({ canvasContext: ctx, viewport: vp }), 15e3);
      } catch (e) {
        throw String(e && e.message) === "er-render-budget" ? new Error("er-render-too-heavy") : e;
      }
      return cv.toDataURL("image/jpeg", 0.85);
    },
    destroy() {
      try {
        doc.destroy();
      } catch { /* optional step; a failure here must not interrupt reading */ }
    }
  };
  return { html: parts.join("\n"), lazy, outline };
}
function searchBookBlocks(blocks, query, limit = 300) {
  const q = String(query || "").trim().toLowerCase();
  if (q.length < 2) return [];
  let out = [];
  for (let i = 0; i < blocks.length && out.length < limit; i++) {
    const text = blocks[i];
    const hay = text.toLowerCase();
    let from = 0;
    while (out.length < limit) {
      const at = hay.indexOf(q, from);
      if (at < 0) break;
      const s = Math.max(0, at - 45), e = Math.min(text.length, at + q.length + 55);
      let pre = text.slice(s, at), post = text.slice(at + q.length, e);
      if (s > 0) pre = pre.replace(/^\S*\s/, "");
      if (e < text.length) post = post.replace(/\s\S*$/, "");
      out.push({
        block: i,
        pre: (s > 0 ? "…" : "") + pre,
        hit: text.slice(at, at + q.length),
        post: post + (e < text.length ? "…" : "")
      });
      from = at + q.length;
    }
  }
  return out;
}
function markFoundIn(view, query) {
  clearFoundIn(view);
  const flow = view.pager && view.pager.flow;
  const q = String(query || "").trim().toLowerCase();
  if (!flow || q.length < 2) return;
  if (typeof CSS === "undefined" || !CSS.highlights || typeof Highlight === "undefined") return;
  view._foundQuery = q;
  const ranges = [];
  const CAP = 2e3;
  try {
    const walker = docOf(flow).createTreeWalker(flow, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode()) && ranges.length < CAP) {
      const text = node.nodeValue || "";
      const hay = text.toLowerCase();
      let from = 0;
      while (ranges.length < CAP) {
        const at = hay.indexOf(q, from);
        if (at < 0) break;
        const r = docOf(flow).createRange();
        r.setStart(node, at);
        r.setEnd(node, at + q.length);
        ranges.push(r);
        from = at + q.length;
      }
    }
    if (ranges.length) CSS.highlights.set("er-found", new Highlight(...ranges));
    window.clearTimeout(view._foundTimer);
    view._foundTimer = window.setTimeout(() => clearFoundIn(view), FOUND_PAINT_MS);
  } catch { /* optional step; a failure here must not interrupt reading */ }
}
function clearFoundIn(view) {
  window.clearTimeout(view._foundTimer);
  view._foundQuery = "";
  try {
    if (typeof CSS !== "undefined" && CSS.highlights) CSS.highlights.delete("er-found");
  } catch { /* optional step; a failure here must not interrupt reading */ }
}
function buildFindPanelFor(view, p, { close, jump }) {
  p.empty();
  p.createDiv("er-pan-title").setText(__ertr("Search the book"));
  const box = p.createDiv("er-toc-find");
  const inp = box.createEl("input", { type: "text" });
  inp.addClass("er-toc-find-input");
  inp.placeholder = __ertr("What to find in the book…");
  const info = p.createDiv("er-find-info");
  const off = p.createDiv("er-find-off");
  off.setText(__ertr("Clear highlight"));
  const list = p.createDiv("er-toc-list");
  off.addEventListener("click", () => {
    inp.value = "";
    clearFoundIn(view);
    list.empty();
    info.setText("");
  });
  view._findInput = inp;
  const run = () => {
    const q = inp.value;
    list.empty();
    if (q.trim().length < 2) {
      info.setText(__ertr("Type at least two characters"));
      clearFoundIn(view);
      return;
    }
    if (!view._findCorpus) view._findCorpus = blockTexts(view.pager && view.pager.flow);
    const hits = searchBookBlocks(view._findCorpus, q);
    if (!hits.length) {
      info.setText(__ertr("Nothing found"));
      clearFoundIn(view);
      return;
    }
    info.setText(__ertr("Found: {0}. The word is highlighted in the text.", hits.length));
    markFoundIn(view, q);
    for (const h of hits) {
      const el = list.createDiv("er-toc-item er-find-item");
      const line = el.createDiv("er-find-text");
      line.createSpan({ text: h.pre });
      line.createSpan({ cls: "er-find-hit", text: h.hit });
      line.createSpan({ text: h.post });
      const spread = view.pager && view.pager.spreadForBlock ? view.pager.spreadForBlock(h.block) : null;
      if (typeof spread === "number") el.createDiv("er-toc-where").setText(__ertr("spr. {0}", spread + 1));
      el.addEventListener("click", () => {
        close();
        jump(h.block);
        markFoundIn(view, q);
      });
    }
  };
  let timer = null;
  inp.addEventListener("input", () => {
    window.clearTimeout(timer);
    timer = window.setTimeout(run, 180);
  });
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      window.clearTimeout(timer);
      run();
    }
  });
}
function buildTocPanelFor(view, p, { close, jump }) {
  p.empty();
  p.createDiv("er-pan-title").setText(__ertr("Contents"));
  const items = view.tocItems || [];
  if (!items.length) {
    p.createDiv("er-toc-empty").setText(__ertr("No contents and no headings were found in this book."));
    return null;
  }
  let filter = "";
  if (items.length > 12) {
    const box = p.createDiv("er-toc-find");
    const inp = box.createEl("input", { type: "text" });
    inp.addClass("er-toc-find-input");
    inp.placeholder = __ertr("Filter by title…");
    inp.addEventListener("input", () => {
      filter = inp.value.trim().toLowerCase();
      render();
    });
  }
  const list = p.createDiv("er-toc-list");
  const render = () => {
    list.empty();
    const cur = view.pager ? view.pager.spread : 0;
    let shown = 0;
    for (const item of items) {
      if (filter && !item.label.toLowerCase().includes(filter)) continue;
      shown++;
      const el = list.createDiv("er-toc-item");
      const row = el.createDiv("er-toc-row");
      row.createSpan({ cls: "er-toc-label", text: item.label });
      const spread = view.pager && view.pager.spreadForBlock ? view.pager.spreadForBlock(item.block) : null;
      const bits = [];
      if (item.page) bits.push(__ertr("p. {0}", item.page));
      if (typeof spread === "number") bits.push(__ertr("spr. {0}", spread + 1));
      if (bits.length) row.createSpan({ cls: "er-toc-where", text: bits.join(" \xB7 ") });
      if (item.level) el.style.paddingLeft = `${8 + item.level * 12}px`;
      if (typeof spread === "number" && spread === cur) el.addClass("active");
      el.addEventListener("click", () => {
        close();
        jump(item.block);
      });
    }
    if (!shown) list.createDiv("er-toc-empty").setText(__ertr("Nothing found"));
  };
  render();
  return render;
}
function chapterForBlock(toc, block) {
  if (!toc || !toc.length || typeof block !== "number") return "";
  let best = "";
  for (const it of toc) {
    if (it.block <= block) best = it.label;
    else break;
  }
  return best;
}
function pageForBlock(flow, block) {
  try {
    const blocks = flow ? flow.querySelectorAll("p,h1,h2,h3,h4") : null;
    const el = blocks && blocks[block];
    const holder = el && el.closest ? el.closest("[data-pdf-page-no]") : null;
    const p = holder ? parseInt(holder.getAttribute("data-pdf-page-no"), 10) : NaN;
    return isNaN(p) ? null : p;
  } catch {
    return null;
  }
}
function enrichHighlights(view, list) {
  const flow = view && view.pager ? view.pager.flow : null;
  const toc = view && view.tocItems || [];
  return (list || []).map((hl) => {
    if (typeof hl.block !== "number") return hl;
    return {
      ...hl,
      chapter: hl.chapter || chapterForBlock(toc, hl.block),
      page: hl.page || pageForBlock(flow, hl.block)
    };
  });
}
function currentBookPage(view) {
  try {
    const flow = view && view.pager ? view.pager.flow : null;
    if (!flow) return null;
    const block = view.pager.currentBlockIndex();
    if (typeof block !== "number" || block < 0) return null;
    return pageForBlock(flow, block);
  } catch {
    return null;
  }
}
function sendQuoteToBookNote(view, hl) {
  if (!hl || !hl.text) return;
  const [full] = enrichHighlights(view, [hl]);
  exportHighlightsToBookNote(view.app, view.plugin, view.file, [full]);
}
function pdfTextLooksUnreadable(items) {
  const text = (items || []).map((it) => typeof it.str === "string" ? it.str : "").join(" ");
  const tokens = text.split(/\s+/).filter(Boolean);
  if (tokens.length < 30) return false;
  const singles = tokens.filter((t) => t.length === 1).length;
  if (singles / tokens.length > 0.7) return true;
  /* Detect broken PDF text maps through phonetic, private-use and control character blocks, not unfamiliar writing systems; preserve Arabic, Hebrew and CJK text. */
  const letters = text.replace(/\s/g, "");
  if (letters.length < 60) return false;
  let junk = 0;
  for (const ch of letters) {
    const c = ch.codePointAt(0);
    if ((c >= 384 && c <= 767) || (c >= 57344 && c <= 63743) || (c < 32 && c !== 9 && c !== 10 && c !== 13)) junk++;
  }
  return junk / letters.length > 0.35;
}
/* Repair legacy PDF Cyrillic mappings shifted downward by 0x1D6 into Latin extensions, keeping text selectable instead of rendering only images. */
const PDF_CYR_SHIFT = 470;
function unshiftCyrillic(s) {
  let out = "";
  for (const ch of String(s)) {
    const c = ch.codePointAt(0);
    /* Replace control codes used as malformed spaces with actual spaces. */
    if (c < 32 && c !== 9 && c !== 10 && c !== 13) out += " ";
    else out += c >= 384 && c <= 687 ? String.fromCodePoint(c + PDF_CYR_SHIFT) : ch;
  }
  return out;
}
/* Apply the shift only if the repaired characters are Cyrillic; otherwise retain the original text and use the image fallback. */
function pdfItemsLookShifted(items) {
  const text = (items || []).map((it) => typeof it.str === "string" ? it.str : "").join(" ");
  const letters = text.replace(/\s/g, "");
  if (letters.length < 40) return false;
  const odd = letters.match(/[ƀ-ʯ]/g);
  if (!odd || odd.length / letters.length < 0.3) return false;
  const fixed = odd.filter((ch) => /[\u0410-\u044f\u0401\u0451]/.test(unshiftCyrillic(ch)));
  return fixed.length / odd.length > 0.9;
}
function pdfFixShiftedCyrillic(items) {
  if (!pdfItemsLookShifted(items)) return false;
  for (const it of items) {
    if (typeof it.str === "string") it.str = unshiftCyrillic(it.str);
  }
  return true;
}
function blockTexts(flow) {
  if (!flow) return [];
  return [...flow.querySelectorAll("p,h1,h2,h3,h4")].map((el) => (el.textContent || "").replace(/\s+/g, " ").trim());
}
function tocLooksLikeNoise(items, all) {
  if (!items || items.length < 30) return false;
  const pages = /* @__PURE__ */ new Set();
  for (const el of all) {
    const h = el.closest ? el.closest("[data-pdf-page-no]") : null;
    if (h) pages.add(h.getAttribute("data-pdf-page-no"));
  }
  const limit = pages.size ? Math.max(30, pages.size * 0.6) : Math.max(30, all.length / 12);
  return items.length > limit;
}
function buildTocItems(html, outline) {
  try {
    const doc = new DOMParser().parseFromString(`<body>${html}</body>`, "text/html");
    const all = [...doc.body.querySelectorAll("p,h1,h2,h3,h4")];
    const pageOfBlock = (i) => {
      const el = all[i];
      const holder = el && el.closest ? el.closest("[data-pdf-page-no]") : null;
      const p = holder ? parseInt(holder.getAttribute("data-pdf-page-no"), 10) : NaN;
      return isNaN(p) ? null : p;
    };
    const withPages = (items2) => items2.map((it) => ({ ...it, page: pageOfBlock(it.block) }));
    if (outline && outline.length) {
      const firstBlockOf = /* @__PURE__ */ new Map();
      all.forEach((el, i) => {
        const holder = el.closest ? el.closest("[data-pdf-page-no]") : null;
        const p = holder ? parseInt(holder.getAttribute("data-pdf-page-no"), 10) : NaN;
        if (!isNaN(p) && !firstBlockOf.has(p)) firstBlockOf.set(p, i);
      });
      const pages = [...firstBlockOf.keys()].sort((a, b) => a - b);
      const items2 = [];
      for (const o of outline) {
        let block = firstBlockOf.get(o.page);
        if (block === void 0) {
          const nxt = pages.find((p) => p >= o.page);
          if (nxt === void 0) continue;
          block = firstBlockOf.get(nxt);
        }
        items2.push({ label: String(o.label).slice(0, 60), block, level: o.level || 0 });
      }
      if (items2.length) return withPages(items2);
    }
    const items = [];
    all.forEach((el, i) => {
      if (/^H[1-3]$/.test(el.tagName)) {
        const label = (el.textContent || "").trim().slice(0, 60);
        if (label) items.push({ label, block: i, level: 0 });
      }
    });
    if (items.length && !tocLooksLikeNoise(items, all)) return withPages(items);
    const printed = tocFromPrintedContents(all);
    if (printed.length && !tocLooksLikeNoise(printed, all)) return withPages(printed);
    const bold = tocFromBoldParagraphs(all);
    return tocLooksLikeNoise(bold, all) ? [] : withPages(bold);
  } catch {
    return [];
  }
}
function tocNorm(s) {
  return String(s || "").toLowerCase().replace(/[«»"'`.,:;!?()[\]—–-]/g, " ").replace(/\s+/g, " ").trim();
}
function tocFromPrintedContents(all) {
  const lines = [];
  all.forEach((el, i) => {
    if (el.classList && el.classList.contains("er-toc-line")) {
      const t = el.querySelector ? el.querySelector(".er-toc-t") : null;
      const label = ((t ? t.textContent : el.textContent) || "").trim();
      if (label) lines.push({ label, at: i });
    }
  });
  if (!lines.length) return [];
  const lastContents = lines[lines.length - 1].at;
  const body = [];
  all.forEach((el, i) => {
    if (i <= lastContents) return;
    if (el.classList && el.classList.contains("er-toc-line")) return;
    const txt = tocNorm(el.textContent);
    if (txt) body.push({ i, txt });
  });
  const items = [];
  let from = 0;
  for (const ln of lines) {
    const want = tocNorm(ln.label);
    if (!want) continue;
    let hit = -1;
    for (let k = from; k < body.length; k++) {
      const txt = body[k].txt;
      if (txt === want || txt.startsWith(want + " ") || want.length >= 12 && txt.startsWith(want)) {
        hit = k;
        break;
      }
    }
    if (hit < 0) continue;
    items.push({ label: ln.label.slice(0, 60), block: body[hit].i, level: 0 });
    from = hit + 1;
  }
  return items.length >= 3 ? items : [];
}
function tocFromBoldParagraphs(all) {
  const items = [];
  all.forEach((el, i) => {
    if (el.tagName !== "P") return;
    if (el.classList && el.classList.contains("er-toc-line")) return;
    const text = (el.textContent || "").trim();
    if (!text || text.length > 80 || text.length < 3) return;
    if (/[.!?;:]$/.test(text)) return;
    const kids = [...el.children || []];
    const bold = kids.length === 1 && /^(B|STRONG)$/.test(kids[0].tagName) && (kids[0].textContent || "").trim() === text;
    if (!bold) return;
    if (!/\s/.test(text) && text.length < 12) return;
    if (/^[\dIVXLC\u041c.,\s—–-]+$/i.test(text)) return;
    items.push({ label: text.slice(0, 60), block: i, level: 0 });
  });
  const seen = /* @__PURE__ */ new Map();
  for (const it of items) seen.set(it.label, (seen.get(it.label) || 0) + 1);
  const unique = items.filter((it) => seen.get(it.label) <= 2);
  const pages = Math.max(1, all.length / 12);
  if (unique.length > pages) return [];
  return unique.length >= 3 ? unique : [];
}
async function renderVisibleFigures(view) {
  const lazy = view._pdfLazy;
  if (!lazy || !view.pager || !view.pager.flow) return;
  bindPdfNoteButtons(view);
  if (view._figBusy) {
    view._figPending = true;
    return;
  }
  view._figBusy = true;
  try {
    const flow = view.pager.flow;
    const sw = view.pager.sw || 1;
    const cur = view.pager.spread;
    const fRect = flow.getBoundingClientRect();
    const scrolling = view.pager.scrollMode;
    const distOf = (img) => {
      const r = img.getBoundingClientRect();
      const at = scrolling ? r.top - fRect.top : r.left - fRect.left;
      return Math.abs(Math.floor(at / sw + 0.01) - cur);
    };
    const imgs = [...flow.querySelectorAll("img.er-pdf-lazy")];
    for (const img of imgs) {
      const dist = distOf(img);
      const loaded = img.dataset.loaded === "1";
      const gaveUp = img.dataset.loaded === "skip";
      if (dist <= 2 && !loaded && !gaveUp) {
        const ri = img.dataset.pdfRect;
        try {
          img.src = await lazy.render(parseInt(img.dataset.pdfPage), ri == null ? null : parseInt(ri));
          img.dataset.loaded = "1";
        } catch (e) {
          if (String(e && e.message) === "er-render-too-heavy") {
            img.dataset.loaded = "skip";
            img.addClass("er-pdf-heavy");
            img.alt = __ertr("This page is too heavy to draw");
          }
        }
      } else if (dist > 6 && loaded) {
        img.removeAttribute("src");
        img.dataset.loaded = "0";
      }
    }
  } finally {
    view._figBusy = false;
    if (view._figPending) {
      view._figPending = false;
      renderVisibleFigures(view);
    }
  }
}
async function pdfFigureScore(page) {
  let ops;
  try {
    ops = await page.getOperatorList();
  } catch {
    return null;
  }
  const fn = ops.fnArray, args = ops.argsArray;
  const view = page.view || [0, 0, 612, 792];
  const pageArea = (Math.abs(view[2] - view[0]) || 1) * (Math.abs(view[3] - view[1]) || 1);
  let m = [1, 0, 0, 1, 0, 0];
  const stack = [];
  let imgArea = 0, vectorOps = 0, shading = 0;
  const rects = [];
  const paths = [];
  for (let i = 0; i < fn.length; i++) {
    const f = fn[i];
    if (f === 10) stack.push(m);
    else if (f === 11) {
      if (stack.length) m = stack.pop();
    } else if (f === 12) {
      const t = args[i];
      m = [
        m[0] * t[0] + m[2] * t[1],
        m[1] * t[0] + m[3] * t[1],
        m[0] * t[2] + m[2] * t[3],
        m[1] * t[2] + m[3] * t[3],
        m[0] * t[4] + m[2] * t[5] + m[4],
        m[1] * t[4] + m[3] * t[5] + m[5]
      ];
    } else if (f >= 83 && f <= 90) {
      imgArea += Math.abs(m[0] * m[3] - m[1] * m[2]);
      const xs = [m[4], m[0] + m[4], m[2] + m[4], m[0] + m[2] + m[4]];
      const ys = [m[5], m[1] + m[5], m[3] + m[5], m[1] + m[3] + m[5]];
      rects.push({ x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) });
    } else if (f === 91) {
      const mm = args[i][2];
      if (mm && mm.length === 4) {
        const cx = [mm[0], mm[1], mm[0], mm[1]], cy = [mm[2], mm[2], mm[3], mm[3]];
        const xs = [], ys = [];
        for (let k = 0; k < 4; k++) {
          xs.push(m[0] * cx[k] + m[2] * cy[k] + m[4]);
          ys.push(m[1] * cx[k] + m[3] * cy[k] + m[5]);
        }
        paths.push({ x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) });
      }
    } else if (f >= 20 && f <= 27) vectorOps++;
    else if (f === 62) shading++;
  }
  const drawn = paths.length > 1 ? mergeRects(paths, 4) : [];
  return { imgFrac: imgArea / pageArea, vectorOps, shading, rects: rects.concat(drawn) };
}
function pdfNoteBtn(pageNo) {
  return `<button class="er-pdf-note-btn" data-pdf-note-page="${pageNo}" type="button" title="${escHtml(__ertr("Note from this page"))}">${icon("note")}</button>`;
}
function rectsNear(a, b, pad) {
  return !(a.x1 + pad < b.x0 || b.x1 + pad < a.x0 || a.y1 + pad < b.y0 || b.y1 + pad < a.y0);
}
function mergeRects(rects, pad) {
  let out = [];
  for (const r of rects) {
    let cur = { ...r };
    let merged = true;
    while (merged) {
      merged = false;
      for (let i = out.length - 1; i >= 0; i--) {
        if (rectsNear(cur, out[i], pad)) {
          const o = out.splice(i, 1)[0];
          cur = {
            x0: Math.min(cur.x0, o.x0),
            y0: Math.min(cur.y0, o.y0),
            x1: Math.max(cur.x1, o.x1),
            y1: Math.max(cur.y1, o.y1)
          };
          merged = true;
        }
      }
    }
    out.push(cur);
  }
  return out;
}
function pdfPickFigures(rects, view) {
  const pw = Math.abs(view[2] - view[0]) || 612;
  const ph = Math.abs(view[3] - view[1]) || 792;
  const pageArea = pw * ph;
  const big = (rects || []).filter((r) => {
    const w = r.x1 - r.x0, h = r.y1 - r.y0;
    if (w < 48 || h < 48) return false;
    if (w * h < pageArea * 0.015) return false;
    if (w * h > pageArea * 0.92) return false;
    return true;
  });
  return mergeRects(big, 6).filter((r) => r.x1 - r.x0 >= 56 && r.y1 - r.y0 >= 56).sort((a, b) => b.y1 - a.y1);
}
const BLOCK_TAGS = /^(p|div|section|article|main|aside|figure|figcaption|h[1-6]|ul|ol|dl|li|dt|dd|table|pre|blockquote|hr|img)$/i;
function tableToHtml(el) {
  let _a, _b;
  const rows = Array.from((_b = (_a = el.querySelectorAll) == null ? void 0 : _a.call(el, "tr")) != null ? _b : []);
  if (!rows.length) return "";
  const body = rows.map((tr) => {
    const cells = Array.from(tr.children || []).filter((c) => /^(td|th)$/i.test(c.tagName || ""));
    if (!cells.length) return "";
    return "<tr>" + cells.map((c) => {
      const t = (c.tagName || "").toLowerCase() === "th" ? "th" : "td";
      const inner = inlineHtml(c).trim();
      return `<${t}>${inner}</${t}>`;
    }).join("") + "</tr>";
  }).filter(Boolean).join("");
  return body ? `<table class="er-table">${body}</table>` : "";
}
function nodeToHtml(el) {
  let _a2, _b2, _c2;
  let _a, _b, _c, _d;
  if (!el)
    return "";
  const tag = (_b = (_a = el.tagName) == null ? void 0 : _a.toLowerCase()) != null ? _b : "";
  const text = (_d = (_c = el.textContent) == null ? void 0 : _c.trim()) != null ? _d : "";
  if (!text && !["br", "hr", "img"].includes(tag) && !((_a2 = el.querySelector) == null ? void 0 : _a2.call(el, "img")))
    return "";
  if (/^h[1-6]$/.test(tag))
    return `<${tag}>${escHtml(text)}</${tag}>`;
  if (tag === "br")
    return "<br>";
  if (tag === "hr")
    return "<hr>";
  if (tag === "img") {
    const src = (_c2 = (_b2 = el.getAttribute) == null ? void 0 : _b2.call(el, "src")) != null ? _c2 : "";
    if (!src) return "";
    return `<img src="${escHtml(src)}" style="max-width:100%;height:auto;display:block;margin:8px auto">`;
  }
  if (tag === "pre") {
    const code = (el.textContent || "").replace(/\s+$/, "");
    return code.trim() ? `<pre class="er-code"><code>${escHtml(code)}</code></pre>` : "";
  }
  if (tag === "table") return tableToHtml(el);
  if (tag === "aside") {
    const inner = Array.from(el.children).map((c) => nodeToHtml(c)).filter(Boolean).join("\n") || (inlineHtml(el).trim() ? `<p>${inlineHtml(el)}</p>` : "");
    return inner ? `<div class="er-side-notes">${inner}</div>` : "";
  }
  if (["div", "section", "article", "body", "main", "aside", "figure"].includes(tag)) {
    const hasBlockChild = Array.from(el.children).some((c) => BLOCK_TAGS.test(c.tagName || ""));
    if (!hasBlockChild) {
      const inner = inlineHtml(el);
      return inner.trim() ? `<p>${inner}</p>` : "";
    }
    const childHtml = Array.from(el.children).map((c) => nodeToHtml(c)).filter(Boolean).join("\n");
    if (!childHtml) {
      const direct = directText(el).trim();
      return direct ? `<p>${escHtml(direct)}</p>` : "";
    }
    return childHtml;
  }
  if (["p", "li", "dt", "dd", "blockquote"].includes(tag)) {
    const toc = tocLineHtml(text);
    if (toc) return toc;
    const inner = inlineHtml(el);
    return inner.trim() ? `<p>${inner}</p>` : "";
  }
  if (["ul", "ol", "dl"].includes(tag)) {
    return Array.from(el.children).map((c) => nodeToHtml(c)).filter(Boolean).join("\n");
  }
  return text ? `<p>${escHtml(text)}</p>` : "";
}
function inlineHtml(el) {
  let _a2;
  let _a, _b, _c;
  let out = "";
  for (const node of Array.from(el.childNodes)) {
    if (node.nodeType === Node.TEXT_NODE) {
      out += escHtml((_a = node.textContent) != null ? _a : "");
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const t = (_c = (_b = node.tagName) == null ? void 0 : _b.toLowerCase()) != null ? _c : "";
      const inner = inlineHtml(node);
      if (["b", "strong"].includes(t))
        out += `<strong>${inner}</strong>`;
      else if (["i", "em"].includes(t))
        out += `<em>${inner}</em>`;
      else if (["code", "kbd", "samp", "tt", "var"].includes(t))
        out += `<code>${inner}</code>`;
      else if (t === "sup")
        out += `<sup>${inner}</sup>`;
      else if (t === "sub")
        out += `<sub>${inner}</sub>`;
      else if (t === "br")
        out += "<br>";
      else if (t === "img") {
        const src = ((_a2 = node.getAttribute) == null ? void 0 : _a2.call(node, "src")) || "";
        if (src) out += `<img src="${escHtml(src)}" style="max-width:100%;height:auto">`;
      } else
        out += inner;
    }
  }
  return out;
}
function directText(el) {
  return Array.from(el.childNodes).filter((n) => n.nodeType === Node.TEXT_NODE).map((n) => {
    let _a;
    return (_a = n.textContent) != null ? _a : "";
  }).join("");
}
function fixPunct(s) {
  return (s || "").replace(/­/g, "").replace(/[ \t\u00A0]+/g, " ").replace(/\s+([,.;:!?…)\]»%”’])/g, "$1").replace(/([([«“‘])\s+/g, "$1").replace(/([\u0410-\u042f\u0430-\u044f\u0401\u0451A-Za-z]) - ([\u0410-\u042f\u0430-\u044f\u0401\u0451A-Za-z])/g, "$1—$2").replace(/ +/g, " ").trim();
}
function dehyphenate(prev, next) {
  if (/[\u0430-\u044f\u0451a-z]-$/i.test(prev) && /^[\u0430-\u044f\u0451]/.test(next)) return prev.slice(0, -1) + next;
  return prev + (prev ? " " : "") + next;
}
function isListStart(s) {
  const t = (s || "").replace(/^[\s"«(]+/, "");
  if (/^[✓✔•·◦‣▪▫●○■□◆◉➤●❖*]/.test(t)) return true;
  if (/^\d{1,3}[.)]\s/.test(t)) return true;
  if (/^[\u0430-\u044f\u0451a-z][.)]\s/.test(t)) return true;
  return false;
}
function isMonoRun(it, styles, measured) {
  const st = styles && it.fontName ? styles[it.fontName] : null;
  if (st && /mono/i.test(String(st.fontFamily || ""))) return true;
  if (measured && it.fontName && measured.has(it.fontName)) return true;
  return /courier|consol|menlo|monaco|mono/i.test(String(it.fontName || ""));
}
function pdfMeasureMonoFonts(items) {
  let _a, _b;
  const byFont = /* @__PURE__ */ new Map();
  for (const it of items) {
    if (!it || typeof it.str !== "string" || !it.fontName) continue;
    if (it.str.replace(/\s/g, "").length < 4 || !(it.width > 0)) continue;
    const size = Math.abs((_b = (_a = it.transform) == null ? void 0 : _a[3]) != null ? _b : 0) || 12;
    const adv = it.width / it.str.length / size;
    if (!(adv > 0)) continue;
    (byFont.get(it.fontName) || byFont.set(it.fontName, []).get(it.fontName)).push(adv);
  }
  const mono = /* @__PURE__ */ new Set();
  for (const [name, adv] of byFont) {
    if (adv.length < 4) continue;
    const mean = adv.reduce((a, b) => a + b, 0) / adv.length;
    if (!(mean > 0)) continue;
    const sd = Math.sqrt(adv.reduce((a, b) => a + (b - mean) ** 2, 0) / adv.length);
    if (sd / mean < 0.02) mono.add(name);
  }
  return mono;
}
function tocLineHtml(text) {
  const t = splitTocLine(text);
  if (!t) return null;
  return `<p class="er-toc-line"><span class="er-toc-t">${escHtml(t.title)}</span><span class="er-toc-n">${escHtml(t.page)}</span></p>`;
}
function splitTocLine(s) {
  const m = String(s || "").trim().match(/^(.*?)[\s.]*\.{4,}[\s.]*(\d{1,4})\s*$/);
  if (!m) return null;
  const title = m[1].replace(/[\s.]+$/, "").trim();
  return title ? { title, page: m[2] } : null;
}
function pdfAsideBoundary(lines, pageLeft, pageRight) {
  const width = pageRight - pageLeft;
  if (!(width > 0)) return null;
  const minX = pageLeft + width * 0.45;
  const candidates = lines.filter((l) => l.x >= minX && l.monoInk === 0 && l.propInk > 0);
  if (candidates.length < 3) return null;
  const left = Math.min(...candidates.map((l) => l.x));
  if (left < minX) return null;
  return left - 6;
}
function looksLikeCodeLine(text) {
  const s = String(text || "").trim();
  if (!s) return false;
  if (!/[{}()[\];=]|>>>|^\s*(def |class |import |from |#include|@)/.test(s)) return false;
  const words = s.split(/\s+/).filter(Boolean).length;
  if (words >= 9 && /^[A-Z\u0410-\u042f\u0401][a-z\u0430-\u044f\u0451]{2,}\s/.test(s) && !/[;{}=]|>>>/.test(s)) return false;
  return true;
}
function pdfItemsToHtml(items, styles) {
  let _a, _b, _c, _d, _e, _f, _g;
  const runs = items.filter((it) => it && typeof it.str === "string");
  if (!runs.length) return "";
  const monoFonts = pdfMeasureMonoFonts(runs);
  const sorted = runs.slice().sort((a, b) => {
    let _a2, _b2, _c2, _d2, _e2, _f2, _g2, _h;
    const ay = (_b2 = (_a2 = a.transform) == null ? void 0 : _a2[5]) != null ? _b2 : 0, by = (_d2 = (_c2 = b.transform) == null ? void 0 : _c2[5]) != null ? _d2 : 0;
    if (Math.abs(ay - by) > 3) return by - ay;
    return ((_f2 = (_e2 = a.transform) == null ? void 0 : _e2[4]) != null ? _f2 : 0) - ((_h = (_g2 = b.transform) == null ? void 0 : _g2[4]) != null ? _h : 0);
  });
  const lines = [];
  for (const it of sorted) {
    const str = it.str;
    const y = (_b = (_a = it.transform) == null ? void 0 : _a[5]) != null ? _b : 0;
    const x = (_d = (_c = it.transform) == null ? void 0 : _c[4]) != null ? _d : 0;
    const size = Math.abs((_f = (_e = it.transform) == null ? void 0 : _e[3]) != null ? _f : 12) || 12;
    let w = (_g = it.width) != null ? _g : 0;
    if (!w && str) w = str.length * size * 0.5;
    const ink = str.replace(/\s/g, "").length;
    const mono = isMonoRun(it, styles, monoFonts);
    const piece = { str, x, w, size, mono, ink };
    const last = lines[lines.length - 1];
    if (last && Math.abs(y - last.y) <= Math.max(2, size * 0.35)) {
      last.pieces.push(piece);
      last.endX = Math.max(last.endX, x + w);
      last.size = Math.max(last.size, size);
      last.x = Math.min(last.x, x);
      if (mono) last.monoInk += ink;
      else last.propInk += ink;
    } else if (str.trim() !== "") {
      lines.push({ y, x, endX: x + w, size, monoInk: mono ? ink : 0, propInk: mono ? 0 : ink, pieces: [piece] });
    }
  }
  if (!lines.length) return "";
  const stitch = (pieces) => {
    let text = "";
    let endX = null;
    for (const p of pieces) {
      if (endX !== null && !/\s$/.test(text) && !/^\s/.test(p.str)) {
        const gapRight = p.x - endX > p.size * 0.2;
        const wrapped = p.x < endX - p.size;
        if (gapRight || wrapped) text += " ";
      }
      text += p.str;
      endX = p.x + p.w;
    }
    return text;
  };
  const pageLeft = Math.min(...lines.map((l) => l.x));
  const pageRight = Math.max(...lines.map((l) => l.endX));
  const asideAt = pdfAsideBoundary(lines, pageLeft, pageRight);
  const asides = [];
  if (asideAt !== null) {
    for (const l of lines) {
      const hasMono = l.pieces.some((p) => p.mono);
      const allProp = !hasMono;
      const wholeLineAside = allProp && l.x >= asideAt;
      if (!wholeLineAside && !hasMono) continue;
      const keep = [], moved = [];
      for (const p of l.pieces) ((wholeLineAside || p.x >= asideAt) && !p.mono ? moved : keep).push(p);
      if (!moved.length) continue;
      if (!keep.length) {
        l.dropped = true;
        asides.push({ y: l.y, text: stitch(moved) });
        continue;
      }
      l.pieces = keep;
      l.endX = Math.max(...keep.map((p) => p.x + p.w));
      l.monoInk = keep.filter((p) => p.mono).reduce((s, p) => s + p.ink, 0);
      l.propInk = keep.filter((p) => !p.mono).reduce((s, p) => s + p.ink, 0);
      asides.push({ y: l.y, text: stitch(moved) });
    }
  }
  for (const l of lines) l.text = stitch(l.pieces);
  const real = lines.filter((l) => !l.dropped && l.text.trim() !== "");
  if (!real.length && !asides.length) return "";
  const avg = real.length ? real.reduce((s, l) => s + l.size, 0) / real.length : 12;
  const measure = Math.max(...real.map((l) => l.endX - l.x)) || 1;
  const gaps = [];
  for (let i = 1; i < real.length; i++) {
    const g = Math.abs(real[i - 1].y - real[i].y);
    if (g > 0.5 && g < avg * 6) gaps.push(g);
  }
  gaps.sort((a, b) => a - b);
  const bucket = /* @__PURE__ */ new Map();
  for (const g of gaps) {
    const k = Math.round(g * 2) / 2;
    bucket.set(k, (bucket.get(k) || 0) + 1);
  }
  let mode = 0, modeN = 0;
  for (const [k, n] of bucket) if (n > modeN || n === modeN && k > mode) {
    mode = k;
    modeN = n;
  }
  const lineGap = gaps.length ? Math.min(modeN >= 3 ? mode : gaps[Math.floor(gaps.length * 0.3)], avg * 2.2) : avg * 1.4;
  const paraGap = Math.max(lineGap * 1.45, avg * 1.1);
  const leftXs = real.map((l) => l.x).sort((a, b) => a - b);
  const bodyLeft = leftXs.length ? leftXs[Math.floor(leftXs.length * 0.15)] : 0;
  const indentMin = Math.max(avg * 0.8, (pageRight - bodyLeft) * 0.015);
  const indentedLines = real.filter((l) => l.x - bodyLeft > indentMin).length;
  const indentMarksParas = indentedLines / (real.length || 1) <= 0.35;
  const monoInk = real.reduce((s, l) => s + l.monoInk, 0);
  const allInk = real.reduce((s, l) => s + l.monoInk + l.propInk, 0) || 1;
  const codeAllowed = monoInk / allInk < 0.8;
  const isSeed = (l) => {
    if (!codeAllowed || !(l.monoInk > 0) || l.monoInk < l.propInk) return false;
    const ratio = l.monoInk / (l.monoInk + l.propInk || 1);
    return ratio >= 0.8 || looksLikeCodeLine(l.text);
  };
  const codeFlag = new Array(real.length).fill(false);
  for (let i = 0; i < real.length; i++) if (isSeed(real[i])) codeFlag[i] = true;
  for (let i = 0; i < real.length; i++) {
    if (!codeFlag[i]) continue;
    let j = i, inner = [];
    while (j + 1 < real.length && codeFlag[j + 1]) {
      inner.push(real[j].y - real[j + 1].y);
      j++;
    }
    const tight = inner.length ? Math.min(...inner) * 1.3 : lineGap * 0.95;
    const blockLeft = Math.min(...real.slice(i, j + 1).map((l) => l.x));
    for (let k = j + 1; k < real.length; k++) {
      const gap = real[k - 1].y - real[k].y;
      if (!(gap > 0 && gap <= tight)) break;
      if (real[k].x < blockLeft - real[k].size) break;
      if (real[k].size > avg * 1.22) break;
      if (!looksLikeCodeLine(real[k].text)) break;
      if (real[k].endX - real[k].x > measure * 0.92) break;
      codeFlag[k] = true;
    }
    i = j;
  }
  const html = [];
  let para = "";
  let lastY = null;
  let code = null;
  const flush = () => {
    if (para.trim()) {
      const li = isListStart(para) ? ' class="er-pdf-li"' : "";
      html.push(`<p${li}>${escHtml(fixPunct(para))}</p>`);
      para = "";
    }
  };
  const flushCode = () => {
    if (!code || !code.lines.length) {
      code = null;
      return;
    }
    const minX = Math.min(...code.lines.map((l) => l.x));
    const unit = Math.max(1, code.size * 0.5);
    const body = code.lines.map((l) => " ".repeat(Math.min(60, Math.max(0, Math.round((l.x - minX) / unit)))) + l.text.replace(/\s+$/, "")).join("\n");
    if (body.trim()) html.push(`<pre class="er-code"><code>${escHtml(body)}</code></pre>`);
    code = null;
  };
  for (let i = 0; i < real.length; i++) {
    const line = real[i];
    if (codeFlag[i]) {
      flush();
      if (!code) code = { lines: [], size: line.size };
      code.lines.push(line);
      code.size = Math.max(code.size, line.size);
      lastY = line.y;
      continue;
    }
    const t2 = fixPunct(line.text);
    if (!t2) continue;
    flushCode();
    const toc = tocLineHtml(t2);
    if (toc) {
      flush();
      html.push(toc);
      lastY = line.y;
      continue;
    }
    const fillsMeasure = line.endX - line.x > measure * 0.9;
    const isH = line.size > avg * 1.22 && !fillsMeasure && t2.length < 120;
    const gap = lastY !== null ? Math.abs(lastY - line.y) : 0;
    if (isH) {
      flush();
      html.push(`<h3>${escHtml(t2)}</h3>`);
      lastY = line.y;
      continue;
    }
    if (lastY !== null && gap > paraGap) flush();
    else if (indentMarksParas && para && line.x - bodyLeft > indentMin) flush();
    if (para && isListStart(t2)) flush();
    para = para ? dehyphenate(para, t2) : t2;
    lastY = line.y;
  }
  flush();
  flushCode();
  if (asides.length) {
    const merged = [];
    for (const a of asides) {
      const prev = merged[merged.length - 1];
      if (prev && prev.y - a.y > 0 && prev.y - a.y <= avg * 1.8) {
        prev.text += " " + a.text;
        prev.y = a.y;
      } else merged.push({ y: a.y, text: a.text });
    }
    const body = merged.map((a) => fixPunct(a.text)).filter(Boolean);
    if (body.length) {
      html.push(`<div class="er-side-notes">${body.map((t) => `<p>${escHtml(t)}</p>`).join("")}</div>`);
    }
  }
  return html.join("\n");
}
function offsetInBlock(block, container, offset) {
  try {
    const r = docOf(block).createRange();
    r.setStart(block, 0);
    r.setEnd(container, offset);
    return r.toString().length;
  } catch {
    return 0;
  }
}
function nthIndexOf(text, sub, occ) {
  let idx = -1;
  for (let i = 0; i <= occ; i++) {
    idx = text.indexOf(sub, idx + 1);
    if (idx < 0) return -1;
  }
  return idx;
}
function countOccurrencesBefore(text, sub, limit) {
  if (!sub) return 0;
  let n = 0, idx = -1;
  while ((idx = text.indexOf(sub, idx + 1)) >= 0 && idx < limit) n++;
  return n;
}
function _hlNormMap(s) {
  s = s || "";
  let norm = "";
  const map = [];
  let prevSpace = false;
  for (let i = 0; i < s.length; i++) {
    let c = s[i];
    if (c === "\xA0" || c === " " || /\s/.test(c)) {
      if (prevSpace) continue;
      norm += " ";
      map.push(i);
      prevSpace = true;
      continue;
    }
    prevSpace = false;
    if (c === "‘" || c === "’" || c === "‚" || c === "‛") c = "'";
    else if (c === "“" || c === "”" || c === "„" || c === "‟") c = '"';
    else if (c === "–" || c === "—" || c === "−") c = "-";
    norm += c;
    map.push(i);
  }
  return { norm, map };
}
function locateHl(blockText, hl) {
  if (!hl || !hl.text) return null;
  const occ = typeof hl.occ === "number" ? hl.occ : 0;
  let start = nthIndexOf(blockText, hl.text, occ);
  if (start >= 0) return { start, len: hl.text.length };
  if (hl.pre != null || hl.post != null) {
    let from = 0, idx;
    while ((idx = blockText.indexOf(hl.text, from)) >= 0) {
      const preOk = !hl.pre || blockText.slice(Math.max(0, idx - hl.pre.length), idx).endsWith(hl.pre);
      const endPos = idx + hl.text.length;
      const postOk = !hl.post || blockText.slice(endPos, endPos + hl.post.length).startsWith(hl.post);
      if (preOk && postOk) return { start: idx, len: hl.text.length };
      from = idx + 1;
    }
  }
  const { norm: nBlock, map } = _hlNormMap(blockText);
  const nText = _hlNormMap(hl.text).norm.trim();
  if (nText) {
    let nIdx = -1;
    const nPre = hl.pre ? _hlNormMap(hl.pre).norm.trim() : "";
    if (nPre) {
      const p = nBlock.indexOf(nPre);
      if (p >= 0) nIdx = nBlock.indexOf(nText, Math.max(0, p + nPre.length - 1));
    }
    if (nIdx < 0) nIdx = nBlock.indexOf(nText);
    if (nIdx >= 0 && nIdx < map.length) {
      const lastN = Math.min(nIdx + nText.length - 1, map.length - 1);
      const startRaw = map[nIdx];
      const endRaw = map[lastN] + 1;
      if (endRaw > startRaw) return { start: startRaw, len: endRaw - startRaw };
    }
  }
  return null;
}
/* Remove existing highlight wrappers before repainting; reused book DOM survives font changes and must not accumulate nested wrappers. */
function unwrapAllHighlights(flow) {
  if (!flow) return;
  flow.querySelectorAll("[data-hl-id]").forEach((span) => {
    const parent = span.parentNode;
    if (!parent) return;
    while (span.firstChild) parent.insertBefore(span.firstChild, span);
    parent.removeChild(span);
    parent.normalize();
  });
}
function wrapBlockRange(block, start, end, hl) {
  if (end <= start) return;
  const walker = docOf(block).createTreeWalker(block, NodeFilter.SHOW_TEXT, null);
  let node, pos = 0;
  const targets = [];
  while ((node = walker.nextNode())) {
    const len = node.textContent.length;
    const nodeStart = pos, nodeEnd = pos + len;
    pos = nodeEnd;
    if (nodeEnd <= start || nodeStart >= end) continue;
    targets.push({ node, s: Math.max(0, start - nodeStart), e: Math.min(len, end - nodeStart) });
  }
  for (const t of targets) {
    let n = t.node;
    if (t.e < n.textContent.length) n.splitText(t.e);
    if (t.s > 0) n = n.splitText(t.s);
    const span = docOf(block).createElement("span");
    span.className = "er-hl";
    span.style.background = hl.color;
    span.setAttribute("data-hl-id", hl.id);
    n.parentNode.insertBefore(span, n);
    span.appendChild(n);
  }
}
function _readerSettings(app) {
  const p = app && app.plugins && app.plugins.plugins ? app.plugins.plugins["book-reader-tts"] : null;
  return p && p.settings || {};
}
function noteTemplatePath(app, bookFile) {
  const s = _readerSettings(app);
  if (bookFile && s.bookTemplates && s.bookTemplates[bookFile.path]) return erPath(s.bookTemplates[bookFile.path]);
  return erPath(s.noteTemplate);
}
function notesFolderPath(app) {
  return erPath(_readerSettings(app).notesFolder);
}
function bookNotesFolderPath(app) {
  return erPath(_readerSettings(app).bookNotesFolder);
}
function inboxNotePath(app, name, override) {
  const f = typeof override === "string" && override !== "" ? erPath(override) : notesFolderPath(app);
  return erPath(f ? `${f}/${name}.md` : `${name}.md`);
}
async function resolveNotesFolder(app, override) {
  const f = typeof override === "string" && override !== "" ? erPath(override) : notesFolderPath(app);
  if (!f) return app.vault.getRoot();
  let folder = app.vault.getAbstractFileByPath(f);
  if (!folder) {
    await app.vault.createFolder(f).catch(() => {
    });
    folder = app.vault.getAbstractFileByPath(f);
  }
  return folder || app.vault.getRoot();
}
function bookNoteFiles(app) {
  const base = bookNotesFolderPath(app);
  const all = app.vault.getMarkdownFiles();
  if (!base) return all;
  const prefix = base + "/";
  return all.filter((f) => f.path.startsWith(prefix));
}
function resolveBookNote(app, name) {
  if (!name) return null;
  const byLink = app.metadataCache.getFirstLinkpathDest ? app.metadataCache.getFirstLinkpathDest(name, "") : null;
  if (byLink instanceof TFile) return byLink;
  const base = bookNotesFolderPath(app);
  const direct = app.vault.getAbstractFileByPath(erPath(base ? `${base}/${name}.md` : `${name}.md`));
  if (direct instanceof TFile) return direct;
  const hit = app.metadataCache.getFirstLinkpathDest(name, "");
  return hit instanceof TFile ? hit : null;
}
const BookNotePicker = class extends FuzzySuggestModal {
  constructor(app, files, onChoose) {
    super(app);
    this._files = files;
    this._onChoose = onChoose;
    this.setPlaceholder(__ertr("Book note for links — start typing a name…"));
  }
  getItems() {
    return this._files;
  }
  getItemText(f) {
    return f.basename;
  }
  onChooseItem(f) {
    this._onChoose(f);
  }
};
const BookQuickOpen = class extends FuzzySuggestModal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
    this.setPlaceholder(__ertr("Which book do you want to open?"));
  }
  getItems() {
    const prog = this.plugin.progress || {};
    const started = (f) => {
      const p = prog[f.path];
      return p && typeof p.pct === "number" && p.pct > 0 ? p.pct : -1;
    };
    return this.plugin.bookFiles().sort((a, b) => {
      const sa = started(a), sb = started(b);
      if (sa >= 0 !== sb >= 0) return sa >= 0 ? -1 : 1;
      return a.basename.localeCompare(b.basename);
    });
  }
  getItemText(f) {
    const p = (this.plugin.progress || {})[f.path];
    const pct = p && typeof p.pct === "number" ? Math.round(p.pct * 100) : 0;
    return pct > 0 ? `${f.basename} — ${pct}%` : f.basename;
  }
  onChooseItem(f) {
    this.plugin.openFile(f);
  }
};
const TemplatePicker = class extends FuzzySuggestModal {
  constructor(app, files, onChoose) {
    super(app);
    this._files = files;
    this._onChoose = onChoose;
    this.setPlaceholder(__ertr("Note template — start typing a path…"));
  }
  getItems() {
    return this._files;
  }
  getItemText(f) {
    return f.path;
  }
  onChooseItem(f) {
    this._onChoose(f);
  }
};
const FolderSuggest = AbstractInputSuggest ? class extends AbstractInputSuggest {
  constructor(app, inputEl) {
    super(app, inputEl);
    this._inputEl = inputEl;
  }
  getSuggestions(query) {
    const q = (query || "").toLowerCase();
    let out = [];
    for (const f of this.app.vault.getAllLoadedFiles()) {
      if (f instanceof TFolder && f.path && f.path.toLowerCase().includes(q)) out.push(f.path);
    }
    return out.sort().slice(0, 50);
  }
  renderSuggestion(path5, el) {
    el.setText(path5);
  }
  selectSuggestion(path5) {
    this._inputEl.value = path5;
    this._inputEl.dispatchEvent(new Event("input"));
    this._inputEl.dispatchEvent(new Event("er-path-pick"));
    this.close();
  }
} : null;
function attachFolderSuggest(app, textComp) {
  try {
    if (FolderSuggest && textComp && textComp.inputEl) new FolderSuggest(app, textComp.inputEl);
  } catch (e) {
    console.warn("Book Reader TTS: folder suggest unavailable", e);
  }
}
function attachPathInput(app, textComp, commit) {
  attachFolderSuggest(app, textComp);
  const el = textComp.inputEl;
  let dirty = false;
  textComp.onChange(() => {
    dirty = true;
  });
  const flush = () => {
    if (!dirty) return;
    dirty = false;
    commit(el.value.trim());
  };
  el.addEventListener("blur", flush);
  el.addEventListener("er-path-pick", flush);
  el.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    e.preventDefault();
    flush();
  });
  return textComp;
}
async function appendLinkToBookNote(app, plugin, bookFile, newFile) {
  try {
    const name = bookNoteLinkFor(plugin, bookFile);
    if (!name) return;
    const noteFile = resolveBookNote(app, name);
    if (!noteFile || noteFile.path === newFile.path) return;
    const heading = __ertr("## Notes from highlights");
    const link = `- [[${newFile.basename}]]`;
    const add = (data) => {
      const base = data.replace(/\s*$/, "");
      return data.includes(heading) ? `${base}
${link}
` : `${base}

${heading}
${link}
`;
    };
    if (typeof app.vault.process === "function") await app.vault.process(noteFile, add);
    else await app.vault.modify(noteFile, add(await app.vault.read(noteFile)));
  } catch (e) {
    console.error("Elton Reader: append to book note failed", e);
  }
}
const RESERVED_NAMES = /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i;
function sanitizeNoteTitle(raw, max = 100) {
  // Control characters are exactly what has to go from a file name.
  // eslint-disable-next-line no-control-regex -- stripping them is the point
  let t = (raw || "").replace(/[\\/:*?"<>|#^[\]]/g, "").replace(/[\x00-\x1F\x7F]/g, "").replace(/\s+/g, " ").trim();
  t = t.replace(/^[.\s]+/, "").replace(/[.\s]+$/, "");
  if (t.length > max) t = t.slice(0, max).replace(/[.\s]+$/, "");
  if (!t) t = __ertr("Note");
  if (RESERVED_NAMES.test(t)) t = `_${t}`;
  return t;
}
function suggestNoteTitle(text, max = 60) {
  const clean = (text || "").replace(/\s+/g, " ").trim();
  if (!clean) return "";
  if (clean.length <= max) return clean.replace(/[.,;:!?…\s]+$/, "");
  const m = clean.match(/^(.{10,}?[.!?…])(\s|$)/);
  if (m && m[1].length <= max && /[\p{L}]{3}[.!?…]+$/u.test(m[1])) {
    return m[1].replace(/[.,;:!?…\s]+$/, "");
  }
  let cut = clean.slice(0, max + 1);
  const sp = cut.lastIndexOf(" ");
  if (sp > max * 0.5) cut = cut.slice(0, sp);
  return cut.replace(/\s+[a-z\u0430-\u044f\u0451]{1,2}$/i, "").replace(/[.,;:!?…\-—\s]+$/, "");
}
const ReadSettingsModal = class extends Modal {
  constructor(app, view) {
    super(app);
    this.view = view;
  }
  /* Apply colors immediately and reflow only when needed, using the appropriate reader method. */
  async _apply(needsRepagination) {
    const v = this.view;
    /* Debounce settings writes so mobile storage and synchronization do not block each button press. */
    window.clearTimeout(this._saveT);
    this._saveT = window.setTimeout(() => { v.plugin.saveAll(); }, 500);
    if (typeof v.applyVars === "function") v.applyVars();
    if (typeof v._applyTheme === "function") v._applyTheme();
    /* Mobile _applyContentStyle fully rebuilds the book. Do not call it for color-only changes, especially on large PDFs. */
    if (needsRepagination && v.bookHtml) {
      /* Capture the current paragraph before rebuilding and restore it afterwards; spread indices are layout-dependent. */
      let block = null;
      try { block = v.pager ? v.pager.currentBlockIndex() : null; } catch { /* optional step; a failure here must not interrupt reading */ }
      if (v.file && v.pager && typeof block === "number" && block >= 0) {
        v.plugin.saveNow(v.file.path, v.pager.spread, v.pager.total, block);
      }
      if (typeof v.repaginate === "function") await v.repaginate();
      else if (typeof v._repaginate === "function") await v._repaginate();
      if (v.pager && typeof block === "number" && block >= 0) {
        const [cur, tot] = v.pager.jumpTo(v.pager.spreadForBlock(block));
        const ui = v.updateUI || v._updateUI;
        if (typeof ui === "function") ui.call(v, cur, tot);
        if (v.file) v.plugin.saveNow(v.file.path, cur, tot, block);
      }
    }
    this._paintPreview();
  }
  _paintPreview() {
    const p = this.previewEl;
    if (!p) return;
    const s = this.view.plugin.settings;
    const t = erTheme(s);
    p.style.fontFamily = FONTS[s.fontFamily] || FONTS.georgia;
    p.style.fontSize = `${s.fontSize || 18}px`;
    p.style.lineHeight = String(s.lineHeight || 1.8);
    p.style.textAlign = s.textAlign || "left";
    p.style.background = t.bg;
    p.style.color = t.text;
  }
  /* Use a label above equal-width segmented controls to avoid uneven wrapping. */
  _seg(host, label, items, current, onPick, hint, compact) {
    host.createDiv("er-pan-sec").setText(label);
    const row = host.createDiv("er-col-row er-rs-seg" + (compact ? " er-rs-num" : ""));
    const btns = [];
    for (const [value, text, font] of items) {
      const b = row.createDiv("er-col-btn");
      b.setText(text);
      if (font) b.style.fontFamily = font;
      if (value === current()) b.addClass("active");
      b.addEventListener("click", async () => {
        for (const x of btns) x.removeClass("active");
        b.addClass("active");
        await onPick(value);
      });
      btns.push(b);
    }
    if (hint) host.createDiv("er-pan-hint").setText(hint);
    return row;
  }
  onOpen() {
    const v = this.view;
    const s = v.plugin.settings;
    this.modalEl.addClass("er-rs-modal");
    const c = this.contentEl;
    c.empty();
    c.addClass("er-rs");
    c.createDiv("er-rs-title").setText(__ertr("Reading settings"));
    this.previewEl = c.createDiv("er-rs-preview");
    this.previewEl.setText(__ertr("Book text preview"));
    this._paintPreview();
    c.addEventListener("click", () => window.setTimeout(() => this._paintPreview(), 80), true);
    const grid = c.createDiv("er-rs-grid");
    const colA = grid.createDiv("er-rs-col");
    const colB = grid.createDiv("er-rs-col");
    const colC = grid.createDiv("er-rs-col");
    colA.createDiv("er-rs-h").setText(__ertr("Appearance"));
    this._seg(
      colA,
      __ertr("Theme"),
      [["auto", __ertr("Match Obsidian")], ["light", __ertr("Light")], ["dark", __ertr("Dark")], ["sepia", "Sepia"], ["eink", "E-ink"]],
      () => s.einkMode ? "eink" : s.theme,
      async (t) => {
        if (t === "eink") s.einkMode = true;
        else {
          s.einkMode = false;
          s.theme = t;
        }
        await this._apply(false);
      }
    );
    this._seg(
      colA,
      __ertr("Font"),
      Object.keys(FONTS).map((f) => [f, f.charAt(0).toUpperCase() + f.slice(1), FONTS[f]]),
      () => s.fontFamily,
      async (f) => {
        s.fontFamily = f;
        await this._apply(true);
      }
    );
    colA.createDiv("er-pan-sec").setText(__ertr("Font size"));
    const szRow = colA.createDiv("er-sz-row");
    const szMinus = szRow.createDiv("er-sz-btn");
    szMinus.setText("A−");
    const szLbl = szRow.createDiv("er-sz-label");
    szLbl.setText(`${s.fontSize}px`);
    const szPlus = szRow.createDiv("er-sz-btn");
    szPlus.setText("A+");
    const chSz = async (d) => {
      s.fontSize = Math.min(32, Math.max(12, (s.fontSize || 18) + d));
      szLbl.setText(`${s.fontSize}px`);
      await this._apply(true);
    };
    szMinus.addEventListener("click", () => chSz(-1));
    szPlus.addEventListener("click", () => chSz(1));
    const steps = [1.4, 1.6, 1.8, 2.1];
    this._seg(
      colA,
      __ertr("Line spacing"),
      steps.map((x) => [x, String(x)]),
      () => steps.find((x) => Math.abs((s.lineHeight || 1.8) - x) < 0.05),
      async (x) => {
        s.lineHeight = x;
        await this._apply(true);
      },
      null,
      true
    );
    colB.createDiv("er-rs-h").setText(__ertr("Page"));
    /* Only offer two-page layout on devices where the reading width can exceed 700 pixels. */
    if (erDeviceKey() !== "phone") this._seg(
      colB,
      __ertr("Pages side by side"),
      [["1", __ertr("One")], ["2", __ertr("Two")]],
      () => String(s.columns || "2"),
      async (n) => {
        s.columns = n;
        await this._apply(true);
      },
      __ertr("Two pages are displayed only on wide screens.")
    );
    this._seg(
      colB,
      __ertr("Navigation"),
      [["pages", __ertr("Pages")], ["scroll", __ertr("Scrolling")]],
      () => s.readMode || "pages",
      async (m) => {
        if (m === (s.readMode || "pages")) return;
        const v = this.view;
        /* Save the current paragraph before switching between pages and scrolling, then reopen through the regular position-restoration path. */
        try {
          if (v.file && v.pager) {
            v.plugin.saveNow(v.file.path, v.pager.spread, v.pager.total, v.pager.currentBlockIndex());
          }
        } catch { /* optional step; a failure here must not interrupt reading */ }
        s.readMode = m;
        await this._apply(false);
        const file = v.file;
        if (!file) return;
        if (typeof v.openFile === "function") await v.openFile(file);
        else if (typeof v._loadBook === "function") await v._loadBook();
      }
    );
    /* Line-width controls are useful on tablets and desktops; phone columns are already too narrow. */
    if (erDeviceKey() !== "phone") this._seg(
      colB,
      __ertr("Line width"),
      [[0, __ertr("Auto")], [60, "60"], [70, "70"], [80, "80"], [90, "90"]],
      () => Number(s.maxLineCh) || 0,
      async (n) => {
        s.maxLineCh = n;
        await this._apply(true);
      },
      __ertr("Characters per line. Shorter lines are easier to read."),
      true
    );
    colC.createDiv("er-rs-h").setText(__ertr("Reading"));
    buildReaderExtraSettings(v, colC);
    const foot = c.createDiv("er-rs-foot");
    if (typeof v._renderHistory === "function") {
      foot.createDiv("er-pan-sec").setText(__ertr("Jump back"));
      v._histRow = foot.createDiv("er-hist-row");
      v._renderHistory();
    }
    const act = foot.createDiv("er-act-row");
    const help = act.createDiv("er-act-btn");
    iconLabel(help, "info", __ertr("Help"));
    help.addEventListener("click", () => {
      this.close();
      new InfoModal(this.app, v.plugin, v.file).open();
    });
  }
  onClose() {
    /* Flush debounced settings immediately when closing the dialog. */
    window.clearTimeout(this._saveT);
    if (this.view && this.view.plugin) this.view.plugin.saveAll();
    if (this.view) this.view._histRow = null;
    this.contentEl.empty();
  }
};
const HighlightCommentModal = class extends Modal {
  constructor(app, initial, onDone) {
    super(app);
    this.initial = initial || "";
    this.onDone = onDone;
    this._answered = false;
  }
  onOpen() {
    const c = this.contentEl;
    c.addClass("er-title-modal");
    c.createDiv("er-info-title").setText(this.initial ? __ertr("Edit comment") : __ertr("Comment on a highlight"));
    const w = c.createDiv("er-setup-field");
    const ta = w.createEl("textarea");
    ta.addClass("er-cmt-input");
    ta.value = this.initial;
    ta.placeholder = __ertr("Your thought about this passage…");
    c.createDiv("er-setup-hint").setText(__ertr("The comment is kept with the highlight and travels with it into your notes. Clear the field to remove it."));
    const foot = c.createDiv("er-setup-foot");
    const ok = foot.createEl("button", { text: __ertr("Save") });
    ok.addClass("er-setup-btn", "er-setup-btn-primary");
    const cancel = foot.createEl("button", { text: __ertr("Cancel") });
    cancel.addClass("er-setup-btn", "er-setup-btn-quiet");
    const submit = () => {
      this._answered = true;
      this.close();
      this.onDone(ta.value.trim());
    };
    ok.addEventListener("click", submit);
    cancel.addEventListener("click", () => this.close());
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        submit();
      }
    });
    erAutoFocus(ta, 30);
    erBlurOnTapOutside(c, ta);
  }
  onClose() {
    this.contentEl.empty();
    if (!this._answered) this.onDone(null);
  }
};
function parseNoteTags(raw) {
  return String(raw || "").replace(/\s+#/g, ",#").split(/[,;\n]+/).map((t) => t.trim().replace(/^#+/, "").replace(/\s+/g, "-")).filter(Boolean).filter((t, i, a) => a.indexOf(t) === i);
}
function allVaultTags(app) {
  try {
    const counts = app.metadataCache && app.metadataCache.getTags && app.metadataCache.getTags();
    if (!counts) return [];
    return Object.keys(counts).map((t) => t.replace(/^#/, "")).sort((a, b) => (counts["#" + b] || 0) - (counts["#" + a] || 0)).slice(0, 60);
  } catch {
    return [];
  }
}
const NoteTitleModal = class extends Modal {
  constructor(app, plugin, fragment, bookFile, onDone) {
    super(app);
    this.plugin = plugin;
    this.fragment = fragment;
    this.bookFile = bookFile || null;
    this.onDone = onDone;
    this._answered = false;
  }
  onOpen() {
    const c = this.contentEl;
    c.addClass("er-title-modal");
    c.createDiv("er-info-title").setText(__ertr("New note from a highlight"));
    const field = (label, hint) => {
      const w = c.createDiv("er-setup-field");
      w.createDiv("er-setup-label").setText(label);
      const el = w.createEl("input", { type: "text" });
      el.addClass("er-setup-input");
      if (hint) el.placeholder = hint;
      return el;
    };
    const input = field(__ertr("Title"));
    input.value = suggestNoteTitle(this.fragment);
    const full = sanitizeNoteTitle(this.fragment);
    if (full && full !== input.value) {
      const useFull = c.createDiv("er-title-alt");
      useFull.setText(__ertr("Use the whole passage as the title"));
      useFull.addEventListener("click", () => {
        input.value = full;
        input.focus();
      });
    }
    const folderInput = field(__ertr("Folder"), notesFolderPath(this.app) || __ertr("Vault root"));
    folderInput.value = this.plugin.settings.lastNoteFolder || "";
    try {
      if (FolderSuggest) new FolderSuggest(this.app, folderInput);
    } catch { /* optional step; a failure here must not interrupt reading */ }
    const tagsInput = field(__ertr("Tags"), __ertr("For example: ideas, psychology"));
    tagsInput.value = this.plugin.settings.lastNoteTags || "";
    const known = allVaultTags(this.app);
    if (known.length) {
      const dl = c.createEl("datalist");
      dl.id = "er-note-tags-" + Math.random().toString(36).slice(2, 8);
      known.forEach((t) => dl.createEl("option", { value: t }));
      tagsInput.setAttr("list", dl.id);
    }
    c.createDiv("er-setup-hint").setText(__ertr("The folder and tags are remembered for the next note. The passage itself goes into the note in full — the title does not affect that."));
    const foot = c.createDiv("er-setup-foot");
    const ok = foot.createEl("button", { text: __ertr("Create note") });
    ok.addClass("er-setup-btn", "er-setup-btn-primary");
    /* Allow subsequent quotes to append to the same book note without disabling separate-note creation globally. */
    const bookNote = this.bookFile ? bookNoteLinkFor(this.plugin, this.bookFile) : "";
    if (bookNote) {
      const toBook = foot.createEl("button", { text: __ertr("Into the book's note") });
      toBook.addClass("er-setup-btn", "er-setup-btn-quiet");
      toBook.setAttribute("aria-label", __ertr("Append the quote to «{0}» instead of making a separate note", bookNote));
      toBook.addEventListener("click", () => {
        this._answered = true;
        this.close();
        this.onDone({ toBookNote: true });
      });
    }
    const cancel = foot.createEl("button", { text: __ertr("Cancel") });
    cancel.addClass("er-setup-btn", "er-setup-btn-quiet");
    const submit = async () => {
      const v = input.value.trim();
      if (!v) {
        input.focus();
        return;
      }
      this._answered = true;
      const folder = erPath(folderInput.value.trim());
      const tags = parseNoteTags(tagsInput.value);
      this.plugin.settings.lastNoteFolder = folder;
      this.plugin.settings.lastNoteTags = tagsInput.value.trim();
      try {
        await this.plugin._saveLocalData();
      } catch { /* optional step; a failure here must not interrupt reading */ }
      this.close();
      this.onDone({ title: v, folder, tags });
    };
    ok.addEventListener("click", submit);
    cancel.addEventListener("click", () => this.close());
    for (const el of [input, folderInput, tagsInput]) {
      el.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          submit();
        }
      });
    }
    erAutoFocus(input, 30);
  }
  onClose() {
    this.contentEl.empty();
    if (!this._answered) this.onDone(null);
  }
};
function processTemplateManually(tplText, title) {
  let today;
  try {
    today = window.moment ? window.moment().format("YYYY-MM-DD") : (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  } catch {
    today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  }
  return tplText.replace(/<%[-_]?\s*tp\.file\.title\s*[-_]?%>/g, title).replace(/<%[-_]?\s*tp\.date\.now\([^)]*\)\s*[-_]?%>/g, today).replace(/<%[-_]?\s*tp\.file\.cursor\([^)]*\)\s*[-_]?%>/g, "").replace(/<%[\s\S]*?%>/g, "");
}
function bookNoteLinkFor(plugin, bookFile) {
  let _a, _b;
  if (!bookFile) return "";
  const map = (_a = plugin == null ? void 0 : plugin.settings) == null ? void 0 : _a.bookNoteLinks;
  const raw = map ? (_b = map[bookFile.path]) != null ? _b : "" : "";
  const fromSettings = String(raw).trim().replace(/^\[\[|\]\]$/g, "").trim();
  if (fromSettings) return fromSettings;
  return bookNoteFromFrontmatter(plugin, bookFile);
}
function bookNoteFromFrontmatter(plugin, bookFile) {
  let _a;
  try {
    const app = plugin && plugin.app;
    if (!app || !bookFile) return "";
    const want = erPath(bookFile.path);
    const wantName = bookFile.basename;
    for (const md of app.vault.getMarkdownFiles()) {
      const fm = app.metadataCache.getFileCache(md);
      const v = fm && fm.frontmatter && ((_a = fm.frontmatter.book) != null ? _a : fm.frontmatter["annotation-target"]);
      if (!v) continue;
      const target = String(v).trim().replace(/^\[\[|\]\]$/g, "").split("|")[0].trim();
      if (!target) continue;
      if (erPath(target) === want || target === wantName) return md.basename;
    }
  } catch { /* optional step; a failure here must not interrupt reading */ }
  return "";
}
async function writeBookProperty(app, noteName, bookFile) {
  try {
    if (!noteName || !bookFile) return;
    const note = resolveBookNote(app, noteName);
    if (!note) return;
    await app.fileManager.processFrontMatter(note, (fm) => {
      fm.book = `[[${bookFile.path}]]`;
    });
  } catch (e) {
    console.warn("Book Reader TTS: could not write the book property into the note", e);
  }
}
async function createNoteFromSelection(app, plugin, selText, bookFile, opts = {}) {
  let _a, _b;
  const {
    open = true,
    silent = false,
    reserved = null,
    color = null,
    extra = "",
    openMode = null,
    openBackground = false
  } = opts;
  const clean = (selText || "").replace(/[ \t]+/g, " ").replace(/\s*\n\s*/g, " ").trim();
  if (!clean) {
    if (!silent) new Notice(__ertr("Empty highlight"));
    return null;
  }
  let title = sanitizeNoteTitle(clean);
  let chosenFolder = null, chosenTags = [];
  if (!silent && plugin.settings.askNoteTitle !== false) {
    const chosen = await new Promise((resolve) => {
      new NoteTitleModal(app, plugin, clean, bookFile, resolve).open();
    });
    if (chosen === null) return null;
    if (chosen.toBookNote) {
      const base = opts.hl && typeof opts.hl === "object" ? opts.hl : {};
      await exportHighlightsToBookNote(app, plugin, bookFile, [{ ...base, text: clean, color: color != null ? color : base.color }]);
      return null;
    }
    title = sanitizeNoteTitle(chosen.title);
    chosenFolder = chosen.folder || null;
    chosenTags = chosen.tags || [];
  } else if (!silent && plugin.settings.shortNoteTitles) {
    title = sanitizeNoteTitle(suggestNoteTitle(clean));
  }
  if (!chosenFolder && plugin.settings.notesNextToBook && bookFile && bookFile.parent) {
    const beside = erPath(bookFile.parent.path || "");
    if (beside) chosenFolder = beside;
  }
  let filename = title, n = 2;
  const taken = (name) => app.vault.getAbstractFileByPath(inboxNotePath(app, name, chosenFolder)) || reserved && reserved.has(name);
  while (taken(filename)) filename = `${title} ${n++}`;
  if (reserved) reserved.add(filename);
  const linkName = bookFile ? bookNoteLinkFor(plugin, bookFile) || bookFile.basename : "";
  const src = bookFile ? __ertr("\n\n— from [[{0}]]", linkName) : "";
  const marked = color ? hlMark(app, clean.replace(/\n/g, "\n> "), color) : clean.replace(/\n/g, "\n> ");
  const tagLine = chosenTags.length ? chosenTags.map((t) => "#" + t).join(" ") + "\n\n" : "";
  const quote = `${tagLine}> ${marked}${extra}${src}`;
  const cursorRe = /<%\s*tp\.file\.cursor\([^)]*\)\s*%>/;
  const cursorReAll = /<%\s*tp\.file\.cursor\([^)]*\)\s*%>/g;
  try {
    const tplPlugin = (_b = (_a = app.plugins) == null ? void 0 : _a.plugins) == null ? void 0 : _b["templater-obsidian"];
    const templater = tplPlugin == null ? void 0 : tplPlugin.templater;
    const _tplPath = noteTemplatePath(app, bookFile);
    const templateFile = _tplPath ? app.vault.getAbstractFileByPath(_tplPath) : null;
    let folder = await resolveNotesFolder(app, chosenFolder);
    let newFile = null;
    if (templater && templateFile && folder && typeof templater.create_new_note_from_template === "function") {
      newFile = await templater.create_new_note_from_template(templateFile, folder, filename, false);
      if (!newFile) newFile = app.vault.getAbstractFileByPath(inboxNotePath(app, filename, chosenFolder));
      if (newFile) {
        const transform = (data) => {
          let out = cursorRe.test(data) ? data.replace(cursorRe, `
${quote}
`) : `${data.replace(/\s*$/, "")}

${quote}
`;
          return out.replace(cursorReAll, "");
        };
        if (typeof app.vault.process === "function") await app.vault.process(newFile, transform);
        else await app.vault.modify(newFile, transform(await app.vault.read(newFile)));
      }
    } else {
      let body = "";
      if (templateFile) {
        try {
          body = processTemplateManually(await app.vault.read(templateFile), filename);
        } catch { /* optional step; a failure here must not interrupt reading */ }
      }
      newFile = await app.vault.create(inboxNotePath(app, filename, chosenFolder), `${body}

${quote}
`);
    }
    if (newFile) {
      if (!silent && bookFile) await appendLinkToBookNote(app, plugin, bookFile, newFile);
      if (open) await openNoteBesideBook(app, plugin, newFile, null, { mode: openMode, background: openBackground });
      if (!silent) new Notice(__ertr("Note created"));
    }
    return newFile;
  } catch (e) {
    console.error("Elton Reader: note creation failed", e);
    if (!silent) new Notice(__ertr("Could not create the note"));
    return null;
  }
}
function _escHtml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function hlMark(app, text, colorId) {
  const c = HL_COLORS.find((x) => x.id === colorId);
  if (!c || _readerSettings(app).exportColors === false) return text;
  return `<mark style="background:${c.css}">${_escHtml(text)}</mark>`;
}
function normalizeHlText(s) {
  return String(s || "").replace(/<[^>]*>/g, " ").replace(/==+/g, " ").replace(/^\s*>+\s?/gm, " ").replace(/\s+/g, " ").trim().toLowerCase();
}
function splitExportedHighlights(noteText, highlights) {
  const hay = normalizeHlText(noteText);
  const fresh = [], already = [];
  for (const hl of highlights || []) {
    const needle = normalizeHlText(hl && hl.text);
    if (needle && hay && hay.includes(needle)) already.push(hl);
    else fresh.push(hl);
  }
  return { fresh, already };
}
async function openNoteBesideBook(app, plugin, file, line, opts = {}) {
  const mode = opts.mode || plugin && plugin.settings && plugin.settings.noteOpenMode || "split";
  if (mode === "none" || !file) return null;
  const back = opts.background === true;
  const prev = back ? app.workspace.getMostRecentLeaf() : null;
  const leaf = app.workspace.getLeaf(mode === "tab" ? "tab" : "split");
  await leaf.openFile(file, back ? { active: false } : void 0);
  if (back && prev) app.workspace.setActiveLeaf(prev, { focus: true });
  if (typeof line === "number" && line > 0) {
    try {
      const view = leaf.view;
      if (view && view.editor) view.editor.setCursor({ line, ch: 0 });
    } catch { /* optional step; a failure here must not interrupt reading */ }
  }
  return leaf;
}
function addBookFileMenu(app, menu, file) {
  if (!file) return menu;
  menu.addSeparator();
  menu.addItem((it) => it.setTitle(__ertr("Reveal in file explorer")).setIcon("folder-open").onClick(() => {
    const explorer = app.workspace.getLeavesOfType("file-explorer")[0];
    if (!explorer) return;
    app.workspace.revealLeaf(explorer);
    const tree = explorer.view;
    if (tree && typeof tree.revealInFolder === "function") tree.revealInFolder(file);
  }));
  app.workspace.trigger("file-menu", menu, file, "elton-reader");
  return menu;
}
function deleteBookFromVault(app, plugin, file, after) {
  if (!file) return;
  new ConfirmModal(app, {
    title: __ertr("Delete book?"),
    body: __ertr("\"{0}\" will be deleted from the vault along with its reading progress and highlights. The book note will remain.", file.basename),
    okText: __ertr("Delete"),
    cancelText: __ertr("Cancel"),
    onYes: async () => {
      try {
        await app.fileManager.trashFile(file);
        const path5 = file.path;
        if (plugin.progress) delete plugin.progress[path5];
        if (plugin.progressBackups) delete plugin.progressBackups[path5];
        if (plugin.highlights) delete plugin.highlights[path5];
        if (plugin.settings && plugin.settings.coverFits) delete plugin.settings.coverFits[path5];
        await plugin.saveAll();
        new Notice(__ertr("Book deleted: {0}", file.basename));
        if (typeof after === "function") after();
      } catch (e) {
        console.error("Elton Reader: delete book failed", e);
        new Notice(__ertr("Could not delete book"));
      }
    }
  }).open();
}
const QUOTE_TEMPLATE_DEFAULT = "> {text}\n\n— from [[{book}]]{page}{link}";
/* Use the configured return-to-book label, or the interface default. */
function backlinkLabel(plugin) {
  const own = String(plugin && plugin.settings && plugin.settings.quoteBacklinkLabel || "").trim();
  return own || __ertr("↪ to this spot in the book");
}
function quoteMarkdown(plugin, hl, bookFile) {
  const clean = String(hl && hl.text || "").replace(/[ \t]+/g, " ").replace(/\s*\n\s*/g, " ").trim();
  if (!clean) return "";
  const bookName = bookFile ? bookNoteLinkFor(plugin, bookFile) || bookFile.basename : "";
  const page = hl && hl.page ? __ertr(", p. {0}", hl.page) : "";
  let link = "";
  if (plugin.settings.quoteBacklinks !== false && bookFile && typeof hl.block === "number" && hl.block >= 0) {
    link = ` [${backlinkLabel(plugin)}](obsidian://book-reader-tts?book=${encodeURIComponent(bookFile.path)}&block=${hl.block})`;
  }
  const comment = hl && hl.comment ? `
>
> — ${String(hl.comment).replace(/\n/g, "\n> ")}` : "";
  const tpl = plugin.settings.quoteTemplate || QUOTE_TEMPLATE_DEFAULT;
  return tpl.split("{text}").join(clean + comment).split("{book}").join(bookName).split("{page}").join(page).split("{link}").join(link).split("{comment}").join(comment.replace(/^\n>\n> /, "")).trim();
}
function hlCommentMd(hl) {
  const c = hl && hl.comment ? String(hl.comment).trim() : "";
  return c ? "\n>\n> — " + c.replace(/\n/g, "\n> ") : "";
}
async function exportHighlightsSeparate(app, plugin, bookFile, highlights) {
  if (!highlights || !highlights.length) {
    new Notice(__ertr("No highlights to export"));
    return;
  }
  new Notice(__ertr("Creating notes: {0}…", highlights.length));
  const reserved = /* @__PURE__ */ new Set();
  let ok = 0, fail = 0;
  for (const hl of highlights) {
    const f = await createNoteFromSelection(app, plugin, hl.text, bookFile, { open: false, silent: true, reserved, extra: hlCommentMd(hl), color: hl.color });
    if (f) ok++;
    else fail++;
  }
  new Notice(fail ? __ertr("Notes created: {0}, errors: {1}", ok, fail) : __ertr("Notes created: {0}", ok));
}
async function openNoteInTab(app, file, line) {
  const leaf = app.workspace.getLeaf("tab");
  if (!leaf) return;
  const eState = typeof line === "number" ? { line, cursor: { from: { line, ch: 0 }, to: { line, ch: 0 } }, focus: true } : void 0;
  await leaf.openFile(file, eState ? { eState } : void 0);
}
const ConfirmModal = class extends Modal {
  constructor(app, opts) {
    super(app);
    this.opts = opts || {};
  }
  onOpen() {
    const { contentEl, modalEl } = this;
    modalEl.addClass("er-confirm-modal");
    contentEl.empty();
    if (this.opts.title) contentEl.createDiv("er-confirm-title").setText(this.opts.title);
    if (this.opts.body) contentEl.createDiv("er-confirm-body").setText(this.opts.body);
    const btns = contentEl.createDiv("er-confirm-btns");
    const no = btns.createEl("button", { text: this.opts.cancelText || __ertr("No") });
    no.addClass("er-confirm-no");
    no.addEventListener("click", () => {
      this._done = true;
      this.close();
      this.opts.onNo && this.opts.onNo();
    });
    const yes = btns.createEl("button", { text: this.opts.okText || __ertr("Yes") });
    yes.addClass("er-confirm-yes");
    yes.addEventListener("click", () => {
      this._done = true;
      this.close();
      this.opts.onYes && this.opts.onYes();
    });
    window.setTimeout(() => yes.focus(), 0);
  }
  onClose() {
    this.contentEl.empty();
  }
};
const GoToPageModal = class extends Modal {
  constructor(app, total, current, onSubmit) {
    super(app);
    this.total = total;
    this.current = current || 0;
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl, modalEl } = this;
    modalEl.addClass("er-confirm-modal");
    contentEl.empty();
    contentEl.createDiv("er-confirm-title").setText(__ertr("Go to page"));
    const input = contentEl.createEl("input", { cls: "er-gotopage-input", attr: { type: "number", min: "1", max: String(this.total), placeholder: `1–${this.total}` } });
    input.value = String(this.current + 1);
    const submit = () => {
      const n = parseInt(input.value, 10);
      this.close();
      if (!isNaN(n)) this.onSubmit(Math.max(1, Math.min(this.total, n)));
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        submit();
      }
    });
    const btns = contentEl.createDiv("er-confirm-btns");
    const go = btns.createEl("button", { text: __ertr("Go") });
    go.addClass("er-confirm-yes");
    go.addEventListener("click", submit);
    erAutoFocus(input, 0);
  }
  onClose() {
    this.contentEl.empty();
  }
};
async function exportHighlightsToBookNote(app, plugin, bookFile, highlights) {
  if (!highlights || !highlights.length) {
    new Notice(__ertr("No highlights to export"));
    return;
  }
  const name = bookFile ? bookNoteLinkFor(plugin, bookFile) : "";
  if (!name) {
    new Notice(__ertr("No note is linked to this book — set it in settings"));
    return;
  }
  const noteFile = resolveBookNote(app, name);
  if (!noteFile) {
    new Notice(__ertr("Book note not found: {0}", name));
    return;
  }
  let existingText = "";
  try {
    existingText = await app.vault.read(noteFile);
  } catch {
    existingText = "";
  }
  const split = splitExportedHighlights(existingText, highlights);
  if (!split.fresh.length) {
    new Notice(split.already.length === 1 ? __ertr("That quote is already in \"{0}\"", noteFile.basename) : __ertr("All the selected quotes are already in \"{0}\"", noteFile.basename));
    return;
  }
  const skipped = split.already.length;
  highlights = split.fresh;
  const groups = [];
  for (const hl of highlights) {
    const clean = (hl.text || "").replace(/[ \t]+/g, " ").replace(/\s*\n\s*/g, " ").trim();
    if (!clean) continue;
    const chapter = hl.chapter || "";
    let g = groups.find((x) => x.chapter === chapter);
    if (!g) {
      g = { chapter, lines: [] };
      groups.push(g);
    }
    let where = hl.page ? __ertr(" *(p. {0})*", hl.page) : "";
    if (plugin.settings.quoteBacklinks !== false && bookFile && typeof hl.block === "number" && hl.block >= 0) {
      const uri = `obsidian://book-reader-tts?book=${encodeURIComponent(bookFile.path)}&block=${hl.block}`;
      where += ` [${backlinkLabel(plugin)}](${uri})`;
    }
    const cmt = hl.comment ? `
>
> — ${hl.comment.replace(/\n/g, "\n> ")}` : "";
    g.lines.push(`> ${hlMark(app, clean, hl.color)}${where}${cmt}`);
  }
  const parts = groups.flatMap((g) => g.lines);
  if (!parts.length) {
    new Notice(__ertr("No highlights to export"));
    return;
  }
  const heading = __ertr("## Quotes");
  const block = groups.map((g) => (g.chapter ? `**${g.chapter}**

` : "") + g.lines.join("\n\n")).join("\n\n");
  let targetLine = 0;
  const add = (data) => {
    const base = data.replace(/\s*$/, "");
    const prefix = data.includes(heading) ? `${base}

` : `${base}

${heading}

`;
    targetLine = (prefix.match(/\n/g) || []).length;
    return `${prefix}${block}
`;
  };
  try {
    if (typeof app.vault.process === "function") await app.vault.process(noteFile, add);
    else await app.vault.modify(noteFile, add(await app.vault.read(noteFile)));
    new Notice(skipped ? __ertr("Added to \"{0}\": {1}; skipped as already present: {2}", noteFile.basename, parts.length, skipped) : __ertr("Quotes added to \"{0}\": {1}", noteFile.basename, parts.length));
  } catch (e) {
    console.error("Elton Reader: append quotes to book note failed", e);
    new Notice(__ertr("Could not add quotes to the book note"));
  }
}
const HighlightExportModal = class extends Modal {
  constructor(app, plugin, bookFile, highlights, noteText, noteName) {
    super(app);
    this.plugin = plugin;
    this.bookFile = bookFile;
    this.noteName = noteName || "";
    const split = splitExportedHighlights(noteText, highlights);
    this.already = new Set(split.already);
    this.items = highlights.map((hl) => ({ hl, on: !split.already.includes(hl) }));
    this.newCount = split.fresh.length;
  }
  onOpen() {
    const c = this.contentEl;
    c.addClass("er-exp-modal");
    c.createDiv("er-info-title").setText(__ertr("What to copy into the note"));
    const sub = c.createDiv("er-info-sub");
    sub.setText(this.noteName ? this.already.size ? __ertr("Note \"{0}\" — {1} already there, {2} new ones ticked", this.noteName, this.already.size, this.newCount) : __ertr("Note \"{0}\" — none of the {1} are there yet", this.noteName, this.items.length) : __ertr("No book note linked — separate notes only"));
    const bar = c.createDiv("er-exp-bar");
    const counter = bar.createSpan({ cls: "er-exp-count" });
    const mkLink = (label, fn) => {
      const a = bar.createSpan({ cls: "er-exp-link", text: label });
      a.addEventListener("click", () => {
        fn();
        refresh();
      });
      return a;
    };
    mkLink(__ertr("Select all"), () => this.items.forEach((i) => i.on = true));
    mkLink(__ertr("Clear all"), () => this.items.forEach((i) => i.on = false));
    if (this.already.size) mkLink(__ertr("New only"), () => this.items.forEach((i) => i.on = !this.already.has(i.hl)));
    const list = c.createDiv("er-exp-list");
    const rows = this.items.map((item) => {
      const row = list.createDiv("er-exp-row");
      const box = row.createEl("input", { type: "checkbox" });
      box.addClass("er-exp-box");
      box.checked = item.on;
      const body = row.createDiv("er-exp-body");
      const txt = (item.hl.text || "").replace(/\s+/g, " ").trim();
      body.createDiv("er-exp-text").setText(txt.length > 220 ? txt.slice(0, 220) + "…" : txt);
      if (this.already.has(item.hl)) {
        row.addClass("er-exp-done");
        body.createDiv("er-exp-tag").setText(__ertr("already in the note"));
      }
      const toggle = () => {
        item.on = !item.on;
        box.checked = item.on;
        refresh();
      };
      box.addEventListener("click", (e) => {
        e.stopPropagation();
        item.on = box.checked;
        refresh();
      });
      row.addEventListener("click", toggle);
      return { item, box };
    });
    const refresh = () => {
      for (const r of rows) r.box.checked = r.item.on;
      const n = this.items.filter((i) => i.on).length;
      counter.setText(__ertr("Ticked: {0} of {1}", n, this.items.length));
      toNote.disabled = !n || !this.noteName;
      toSep.disabled = !n;
    };
    const foot = c.createDiv("er-setup-foot");
    const toNote = foot.createEl("button", { text: __ertr("Into the book's note") });
    toNote.addClass("er-setup-btn", "er-setup-btn-primary");
    const toSep = foot.createEl("button", { text: __ertr("As separate notes") });
    toSep.addClass("er-setup-btn");
    const picked = () => this.items.filter((i) => i.on).map((i) => i.hl);
    toNote.addEventListener("click", () => {
      const sel = picked();
      this.close();
      exportHighlightsToBookNote(this.app, this.plugin, this.bookFile, sel);
    });
    toSep.addEventListener("click", () => {
      const sel = picked();
      this.close();
      exportHighlightsSeparate(this.app, this.plugin, this.bookFile, sel);
    });
    refresh();
  }
  onClose() {
    this.contentEl.empty();
  }
};
async function exportHighlightsMenu(app, plugin, bookFile, highlights, evt) {
  if (!highlights || !highlights.length) {
    new Notice(__ertr("No highlights to export"));
    return;
  }
  const name = bookFile ? bookNoteLinkFor(plugin, bookFile) : "";
  const noteFile = name ? resolveBookNote(app, name) : null;
  let noteText = "";
  if (noteFile) {
    try {
      noteText = await app.vault.cachedRead(noteFile);
    } catch {
      noteText = "";
    }
  }
  new HighlightExportModal(app, plugin, bookFile, highlights, noteText, noteFile ? noteFile.basename : "").open();
}
const InfoModal = class extends Modal {
  constructor(app, plugin, file) {
    super(app);
    this.plugin = plugin || null;
    this.file = file || null;
  }
  onOpen() {
    const { contentEl, modalEl } = this;
    modalEl.addClass("er-info-modal");
    contentEl.empty();
    contentEl.createDiv("er-info-title").setText(__ertr("How to use Book Reader TTS"));
    contentEl.createDiv("er-info-sub").setText(__ertr("What each button does and why"));
    const groups = [
      { head: __ertr("Top bar"), rows: [
        ["save", __ertr("Save position"), __ertr("Remembers where you left off and drops a restore point (marked 💾 in \"Settings → Jump back\"). It's like a \"save\" in a game — press it before closing the book if you want to be completely sure your spot won't be lost.")],
        ["refresh", __ertr("Refresh"), __ertr("Rebuilds the page if the layout breaks — for example, after resizing the window or opening/closing a sidebar panel or tab (the text may look misaligned). Your current position is preserved.")],
        ["search", __ertr("Search"), __ertr("Search across the whole book's text — a list of matches with context around each, click to jump to that spot.")],
        ["highlighter", __ertr("Highlights"), __ertr("Opens every highlight you have made in this book. Click a row to jump to that spot. Each highlight has a comment icon — a short thought that stays with the quote. The export-to-notes button sits above the list.")],
        ["list", __ertr("Contents"), __ertr("The book's contents: PDF bookmarks, headings, the book's own printed contents page or bold paragraphs — whichever turns up first. Each entry shows a page number and the current spread. When there are many entries, a filter appears at the top.")],
        ["sliders", __ertr("Settings"), __ertr("Theme, font, text size, column count and the \"Jump back\" block — a list of points you can roll back to.")],
        ["info", __ertr("Help"), __ertr("This window.")]
      ] },
      { head: __ertr("Reading and navigation"), rows: [
        ["chevron-left", __ertr("Turn pages"), __ertr("The arrows at the bottom of the screen, the ← → ↑ ↓ keys and space, or a finger swipe on mobile. Every page turn saves your position automatically — you don't need to press \"Save\" separately.")]
      ] },
      { head: __ertr("Highlights and notes"), rows: [
        ["highlighter", __ertr("Highlight text"), __ertr("Select a fragment with the mouse or a finger — a color palette pops up. Click an existing highlight to change its color or remove it.")],
        ["note", __ertr("Create a note from a highlight"), __ertr("Right-click the highlighted text → \"Create new note\". The note is created from your template in the chosen folder, with the quote and a link to the book.")],
        ["download", __ertr("Move highlights into notes"), __ertr("The button at the top of the Highlights panel. It opens a list where you tick what you want — one by one, \"Select all\" or \"New only\". Anything already copied into the book note is marked and left unticked, so exporting again never duplicates it. Then choose: paste them as text into the book note, or make a separate note for each passage.")]
      ] }
    ];
    groups.forEach((g) => {
      contentEl.createDiv("er-info-group").setText(g.head);
      g.rows.forEach(([ic, title, desc]) => {
        const row = contentEl.createDiv("er-info-row");
        const ig = row.createDiv("er-info-ic");
        svgIcon(ig, ic);
        const tx = row.createDiv("er-info-tx");
        tx.createDiv("er-info-rowtitle").setText(title);
        tx.createDiv("er-info-rowdesc").setText(desc);
      });
    });
    const note = contentEl.createDiv("er-info-note");
    note.createDiv("er-info-rowtitle").setText(__ertr("About autosave"));
    note.createDiv("er-info-rowdesc").setText(__ertr("Your position is saved automatically on every page turn and kept in a shared file that syncs across devices (Obsidian Sync). Rebuilding the page (resizing the window, panels, zoom) no longer moves or re-saves progress — so it won't \"drift\" on its own."));
  }
  onClose() {
    let _a, _b;
    (_b = (_a = this._pdfLazy) == null ? void 0 : _a.destroy) == null ? void 0 : _b.call(_a);
    this._pdfLazy = null;
    this.contentEl.empty();
  }
};
const ONBOARD_SLIDES = [
 {emoji:"📖",title:__ertr("Read without interruptions"),body:[__ertr("Open EPUB, PDF or FB2 files from your vault or import books from the library."),__ertr("Opening a book does not ask you to create or link a note. Use the book settings whenever you want to link one.")]},
 {emoji:"🎧",title:__ertr("Reading and listening"),body:[__ertr("Use Appearance for fonts, wallpaper and page layout. Use Voice for speed, language and installed system voices."),__ertr("The progress bar seeks through the book. Reading time starts only when you press the timer in the footer.")]},
 {emoji:"📝",title:__ertr("Highlights and notes"),body:[__ertr("Select text to highlight or create a note. New notes are saved quietly by default; existing notes and highlights are preserved."),__ertr("Progress and highlights sync as vault files. Let syncing finish before continuing on another device.")]}
];
const WHATS_NEW = [{v:"0.4.2",items:[__ertr("Notes no longer interrupt reading."),__ertr("Interface text follows the application language; unsupported languages use English.")]}];
function whatsNewSince(lastSeen, current, log) {
  return (log || WHATS_NEW).filter((r) => cmpVer(r.v, lastSeen) > 0 && cmpVer(r.v, current) <= 0);
}
/* Persist release notes in the vault so they remain searchable after the dialog closes. Never overwrite an existing note that the user may have edited. */
async function writeWhatsNewNote(app, plugin, releases) {
  try {
    if (!releases || !releases.length) return null;
    const title = sanitizeNoteTitle(__ertr("Book Reader TTS {0} - what's new", plugin.manifest.version));
    const path = inboxNotePath(app, title, null);
    const exist = app.vault.getAbstractFileByPath(path);
    if (exist instanceof TFile) return exist;
    const body = releases.map((r) => `## ${r.v}

${r.items.map((i) => `- ${i}`).join("\n")}`).join("\n\n");
    await resolveNotesFolder(app, null);
    const f = await app.vault.create(path, `${__ertr("Book Reader TTS has been updated to {0}. Here is what changed:", plugin.manifest.version)}

${body}
`);
    return f instanceof TFile ? f : null;
  } catch (e) {
    console.warn("Book Reader TTS: could not write the what's-new note", e);
    return null;
  }
}
const WhatsNewModal = class extends Modal {
  constructor(app, plugin, releases, noteFile) {
    super(app);
    this.plugin = plugin;
    this.releases = releases;
    this.noteFile = noteFile || null;
  }
  onOpen() {
    const c = this.contentEl;
    this.modalEl.addClass("er-onb-modal");
    c.empty();
    const card = c.createDiv("er-onb-card er-wn-card");
    card.createDiv("er-onb-emoji").setText("✨");
    card.createDiv("er-onb-title").setText(__ertr("What's new"));
    card.createDiv("er-wn-sub").setText(__ertr("Book Reader TTS updated to {0}", this.plugin.manifest.version));
    const wrap = card.createDiv("er-wn-wrap");
    for (const r of this.releases) {
      const grp = wrap.createDiv("er-wn-rel");
      grp.createDiv("er-wn-ver").setText(r.v);
      const ul = grp.createDiv("er-wn-list");
      for (const it of r.items) {
        const row = ul.createDiv("er-wn-item");
        row.createSpan({ cls: "er-wn-dot", text: "✦" });
        row.createSpan({ text: it });
      }
    }
    const nav = c.createDiv("er-onb-nav er-wn-nav");
    const ok = nav.createEl("button", { text: __ertr("Got it") });
    ok.addClass("er-onb-start", "er-wn-ok");
    ok.addEventListener("click", () => this.close());
    if (this.noteFile) {
      const open = c.createDiv("er-onb-skip");
      open.setText(__ertr("Saved as the note «{0}» - open it", this.noteFile.basename));
      open.addEventListener("click", () => {
        this.close();
        this.app.workspace.getLeaf(true).openFile(this.noteFile);
      });
    }
    const help = c.createDiv("er-onb-skip");
    help.setText(__ertr("Guide: every setting, step by step"));
    help.addEventListener("click", () => {
      this.close();
      new OnboardingModal(this.app, this.plugin).open();
    });
  }
  onClose() {
    this.contentEl.empty();
  }
};
const BookSetupModal = class extends Modal {
  constructor(app, plugin, file, onDone) {
    super(app);
    this.plugin = plugin;
    this.file = file;
    this.onDone = onDone || (() => {
    });
    this._answered = false;
    this._step = 1;
  }
  onOpen() {
    this.modalEl.addClass("er-setup-modal");
    this._render();
  }
  _render() {
    this.contentEl.empty();
    if (this._step === 1) this._renderPick();
    else this._renderCreate();
  }
  // ── Step 1: link an existing note ─────────────────────────────────────────
  // One job per screen: here you only choose. Everything about MAKING a note
  // lives on step 2, so this screen stays a short list instead of a form.
  _renderPick() {
    const c = this.contentEl;
    c.createDiv("er-info-title").setText(__ertr("A note for this book"));
    c.createDiv("er-info-sub").setText(this.file.basename);
    c.createDiv("er-setup-lead").setText(__ertr("Quotes and thoughts from this book will link to this note."));
    const search = c.createEl("input", { type: "text" });
    search.addClass("er-setup-input");
    search.placeholder = __ertr("Search notes…");
    const listEl = c.createDiv("er-setup-list");
    const all = bookNoteFiles(this.app);
    const paint = (q) => {
      listEl.empty();
      const needle = (q || "").trim().toLowerCase();
      const shown = (needle ? all.filter((f) => f.basename.toLowerCase().includes(needle)) : all).slice(0, 200);
      if (!all.length) {
        listEl.createDiv("er-setup-empty").setText(__ertr("No notes in the vault yet — create one below"));
        return;
      }
      if (!shown.length) {
        listEl.createDiv("er-setup-empty").setText(__ertr("Nothing found"));
        return;
      }
      for (const f of shown) {
        const row = listEl.createDiv("er-setup-row");
        row.createDiv("er-setup-row-name").setText(f.basename);
        const dir = f.parent && f.parent.path && f.parent.path !== "/" ? f.parent.path : "";
        if (dir) row.createDiv("er-setup-row-path").setText(dir);
        row.addEventListener("click", async () => {
          this.plugin.settings.bookNoteLinks[this.file.path] = f.basename;
          await this.plugin.saveAll();
          await writeBookProperty(this.app, f.basename, this.file);
          this._finish(__ertr("Book note: {0}", f.basename));
        });
      }
    };
    search.addEventListener("input", () => paint(search.value));
    paint("");
    const foot = c.createDiv("er-setup-foot");
    const mk = foot.createEl("button", { text: __ertr("Create a note…") });
    mk.addClass("er-setup-btn", "er-setup-btn-primary");
    mk.addEventListener("click", () => {
      this._step = 2;
      this._render();
    });
    const skip = foot.createEl("button", { text: __ertr("Read without a note") });
    skip.addClass("er-setup-btn", "er-setup-btn-quiet");
    skip.addEventListener("click", () => this._finish(""));
    erAutoFocus(search, 30);
    erBlurOnTapOutside(this.contentEl, search);
  }
  // ── Step 2: create a new note ─────────────────────────────────────────────
  _renderCreate() {
    const c = this.contentEl;
    const back = c.createDiv("er-setup-back");
    back.setText(__ertr("← Back"));
    back.addEventListener("click", () => {
      this._step = 1;
      this._render();
    });
    c.createDiv("er-info-title").setText(__ertr("Create note"));
    c.createDiv("er-info-sub").setText(this.file.basename);
    const field = (label, value, placeholder) => {
      const w = c.createDiv("er-setup-field");
      w.createDiv("er-setup-label").setText(label);
      const el = w.createEl("input", { type: "text" });
      el.addClass("er-setup-input");
      if (value) el.value = value;
      if (placeholder) el.placeholder = placeholder;
      return el;
    };
    const nameInput = field(__ertr("Note name"), sanitizeNoteTitle(this.file.basename));
    const folderInput = field(__ertr("Folder"), bookNotesFolderPath(this.app) || notesFolderPath(this.app) || "", __ertr("Vault root"));
    try {
      if (FolderSuggest) new FolderSuggest(this.app, folderInput);
    } catch { /* optional step; a failure here must not interrupt reading */ }
    const tagsInput = field(__ertr("Category"), bookTagsOf(this.plugin.settings, this.file.path).join(", "), __ertr("e.g. Psychology, Business"));
    const known = allBookTags(this.plugin.settings);
    if (known.length) {
      const dl = c.createEl("datalist");
      dl.id = "er-setup-tags-" + Math.random().toString(36).slice(2, 8);
      known.forEach((t) => dl.createEl("option", { value: t }));
      tagsInput.setAttr("list", dl.id);
    }
    c.createDiv("er-setup-hint").setText(__ertr("Genre or topic — books are grouped by it in the library. Separate several with commas. Can be left empty."));
    const foot = c.createDiv("er-setup-foot");
    const createBtn = foot.createEl("button", { text: __ertr("Create and start reading") });
    createBtn.addClass("er-setup-btn", "er-setup-btn-primary");
    createBtn.addEventListener("click", async () => {
      createBtn.disabled = true;
      const note = await this.plugin.createBookNote(this.file, nameInput.value, folderInput.value);
      if (!note) {
        createBtn.disabled = false;
        return;
      }
      await this.plugin.setBookTags(this.file.path, parseBookTags(tagsInput.value));
      this._finish(__ertr("Book note created: {0}", note.basename));
    });
    [nameInput, folderInput, tagsInput].forEach((el) => el.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        createBtn.click();
      }
    }));
    erAutoFocus(nameInput, 30);
    erBlurOnTapOutside(this.contentEl, nameInput);
  }
  async _finish(msg) {
    this._answered = true;
    const s = this.plugin.settings;
    if (!s.bookNotePrompted) s.bookNotePrompted = {};
    s.bookNotePrompted[this.file.path] = true;
    await this.plugin.saveAll();
    if (msg) new Notice(msg);
    this.close();
    this.onDone();
  }
  onClose() {
    this.contentEl.empty();
    if (!this._answered) this.onDone();
  }
};
const OnboardingModal = class extends Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin || null;
    this.idx = 0;
    this._finished = false;
  }
  onOpen() {
    this.modalEl.addClass("er-onb-modal");
    this.scope.register([], "ArrowRight", (e) => {
      e.preventDefault();
      this._go(1);
    });
    this.scope.register([], "ArrowLeft", (e) => {
      e.preventDefault();
      this._go(-1);
    });
    this._render();
  }
  _go(dir) {
    const n = this.idx + dir;
    if (n < 0 || n >= ONBOARD_SLIDES.length) return;
    this.idx = n;
    this._render();
  }
  _markSeen() {
    if (this._finished) return;
    this._finished = true;
    if (this.plugin && !this.plugin.settings.onboarded) {
      this.plugin.settings.onboarded = true;
      this.plugin.saveAll();
    }
  }
  _render() {
    const { contentEl } = this;
    contentEl.empty();
    const s = ONBOARD_SLIDES[this.idx];
    const total = ONBOARD_SLIDES.length;
    const last = this.idx === total - 1;
    const card = contentEl.createDiv("er-onb-card" + (s.tone === "warn" ? " er-onb-warn" : ""));
    card.createDiv("er-onb-emoji").setText(s.emoji);
    card.createDiv("er-onb-title").setText(s.title);
    const body = card.createDiv("er-onb-body");
    (Array.isArray(s.body) ? s.body : [s.body]).forEach((p) => body.createEl("p").setText(p));
    const dots = contentEl.createDiv("er-onb-dots");
    ONBOARD_SLIDES.forEach((_, i) => {
      const d = dots.createDiv("er-onb-dot" + (i === this.idx ? " er-onb-dot-on" : ""));
      d.setAttribute("aria-label", __ertr("Screen {0}", i + 1));
      d.addEventListener("click", () => {
        this.idx = i;
        this._render();
      });
    });
    const nav = contentEl.createDiv("er-onb-nav");
    const prev = nav.createEl("button", { text: __ertr("‹ Back") });
    prev.addClass("er-onb-prev");
    prev.disabled = this.idx === 0;
    prev.addEventListener("click", () => this._go(-1));
    nav.createDiv("er-onb-counter").setText(`${this.idx + 1} / ${total}`);
    const next = nav.createEl("button", { text: last ? __ertr("Start reading") : __ertr("Next ›") });
    next.addClass(last ? "er-onb-start" : "er-onb-next");
    next.addEventListener("click", () => {
      if (last) {
        this._markSeen();
        this.close();
      } else this._go(1);
    });
    const skip = contentEl.createDiv("er-onb-skip");
    skip.setText(last ? "" : __ertr("Skip"));
    if (!last) skip.addEventListener("click", () => {
      this._markSeen();
      this.close();
    });
  }
  onClose() {
    this._markSeen();
    this.contentEl.empty();
  }
};
const ReaderView = class extends ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.file = null;
    this.ext = null;
    this.pager = new Paginator();
    this.pager.onSpreadChange = (cur, tot) => {
      (this.updateUI || this._updateUI).call(this, cur, tot);
      if (this.file) this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
    };
    this.bookHtml = "";
    this.tocItems = [];
    this.panelOpen = null;
    this.plugin = plugin;
    this._resizeTimer = null;
    this._lastWidth = 0;
    this._pendingSel = null;
    this._editHlId = null;
  }
  getViewType() {
    return VIEW_TYPE;
  }
  // The tab's "..." menu. A book opened in the reader used to have none of the
  // things every other file in Obsidian offers there — reveal in the folder
  // tree, rename, move, delete — which readers reported as the reader "taking
  // the file hostage". These come from Obsidian itself, so they stay correct.
  onPaneMenu(menu, source) {
    super.onPaneMenu(menu, source);
    addBookFileMenu(this.app, menu, this.file);
  }
  getDisplayText() {
    let _a, _b;
    return (_b = (_a = this.file) == null ? void 0 : _a.basename) != null ? _b : "Book Reader TTS";
  }
  getIcon() {
    return "book-open";
  }
  getState() {
    let _a, _b;
    const p = (_b = (_a = this.file) == null ? void 0 : _a.path) != null ? _b : "";
    return { file: p, path: p };
  }
  async setState(state, result) {
    const path5 = (state == null ? void 0 : state.file) != null ? state.file : state == null ? void 0 : state.path;
    if (!path5)
      return;
    if (this.file && this.file.path === path5 && this.bookHtml)
      return;
    const f = this.app.vault.getAbstractFileByPath(path5);
    if (f instanceof TFile)
      await this.openFile(f);
  }
  async onOpen() {
    this.buildDOM();
    this._resizeObs = new ResizeObserver(() => {
      let _a;
      if (!this.bookHtml) return;
      if (this.containerEl.offsetParent === null) return;
      const w = this.areaEl.clientWidth;
      if (!w) return;
      if (Math.abs(w - (this._laidOutWidth || 0)) < 8) return;
      this._setRelayout(true);
      window.clearTimeout(this._resizeTimer);
      const delay = ((_a = this.app) == null ? void 0 : _a.isMobile) ? 500 : 260;
      this._resizeTimer = window.setTimeout(() => {
        const fw = this.areaEl.clientWidth;
        if (!fw || this.containerEl.offsetParent === null) {
          this._setRelayout(false);
          return;
        }
        if (Math.abs(fw - (this._laidOutWidth || 0)) < 8) {
          this._setRelayout(false);
          return;
        }
        this.repaginate();
      }, delay);
    });
    this._resizeObs.observe(this.areaEl);
    const recheck = () => {
      if (this._layoutWidthStale()) this.repaginate();
    };
    this.registerEvent(this.app.workspace.on("layout-change", recheck));
    this.registerEvent(this.app.workspace.on("active-leaf-change", (leaf) => {
      if (leaf === this.leaf) recheck();
    }));
  }
  async openFile(file) {
    let _a2, _b;
    let _a;
    this._tts?.stop?.();
    this.file = file;
    this._tts?.reset();
    this._readingProgress?.reset();
    this.ext = file.extension === "epub" ? "epub" : file.extension === "fb2" ? "fb2" : "pdf";
    this.bookHtml = "";
    this.tocItems = [];
    (_b = (_a2 = this._pdfLazy) == null ? void 0 : _a2.destroy) == null ? void 0 : _b.call(_a2);
    this._pdfLazy = null;
    this._pdfOutline = null;
    this.titleEl.setText(file.basename);
    this.applyVars();
    this.areaEl.empty();
    const loading = this.areaEl.createDiv("er-loading");
    loading.createDiv("er-spin");
    const loadText = loading.createDiv("er-loading-text");
    loadText.setText(__ertr("Loading the book…"));
    await new Promise((r) => window.requestAnimationFrame(r));
    await new Promise((r) => window.requestAnimationFrame(r));
    try {
      if (this.ext === "epub") {
        this.bookHtml = await extractEpub(file, this.app);
      } else if (this.ext === "fb2") {
        this.bookHtml = await extractFb2(file, this.app);
      } else {
        const res = await extractPdf(file, this.app, this.plugin.settings, (i, n) => loadText.setText(__ertr("Preparing the book… {0}%", Math.round(i / n * 100))));
        this.bookHtml = res.html;
        this._pdfLazy = res.lazy;
        this._pdfOutline = res.outline;
      }
      this.tocItems = buildTocItems(this.bookHtml, this._pdfOutline);
      this.buildTocPanel();
      await this.plugin.refreshProgress();
      await this.plugin.refreshHighlights();
      const saved = this.plugin.getProgress(file.path);
      if(saved?.pct>0&&this.plugin.readerSync?.remotePositions.delete(file.path))new Notice(__ertr('Continuing from synced reading position: {0}%',saved.percent));
      const pct = (saved == null ? void 0 : saved.pct) != null ? saved.pct : 0;
      await this.paginate(pct, saved == null ? void 0 : saved.block);
      this.buildSettPanel();
      this._maybePromptBookNote(file);
      this._sessionSec = 0;
      this._running = false;
      startTimerSession(this);
      updateTimerBtn(this);
    } catch (e) {
      console.error("Elton Reader:", e);
      new Notice(__ertr("Error opening the file"));
    }
  }
  // On a book's first open, offer to pick its index note (from the configured
  // book-notes folder). Asks once per book; afterwards use the field/button in
  // the info panel. Skipped entirely unless a dedicated folder is configured, so
  // it never pops up over the whole vault for users who don't use this feature.
  _maybePromptBookNote(file) {
    const s = this.plugin.settings;
    if (!file) return;
    if (!s.bookNoteLinks) s.bookNoteLinks = {};
    if (!s.bookNotePrompted) s.bookNotePrompted = {};
    const action = bookNoteAction(s, file.path);
    if (action === "linked" || action === "prompted" || action === "quiet") return;
    if (action === "auto") {
      s.bookNotePrompted[file.path] = true;
      this.plugin.ensureBookNote(file).then((note) => {
        if (note) new Notice(__ertr("Book note created: {0}", note.basename));
        if (this.panelOpen === "settings") this.buildSettPanel();
      });
      return;
    }
    new BookSetupModal(this.app, this.plugin, file, () => {
      if (this.panelOpen === "settings") this.buildSettPanel();
    }).open();
  }
  async paginate(savedPct = 0, savedBlock = null) {
    this.areaEl.empty();
    let w = this.areaEl.clientWidth, a = 0;
    while (!w && a < 60) {
      await new Promise((r) => window.requestAnimationFrame(r));
      w = this.areaEl.clientWidth;
      a++;
    }
    if (!w) return;
    this.areaEl.addClass("er-booting");
    erShowVeil(this);
    window.setTimeout(() => {
      if (this.areaEl) this.areaEl.removeClass("er-booting");
      erHideVeil(this);
    }, 3e3);
    const [, total] = await this.pager.build(
      this.areaEl,
      this.bookHtml,
      this.plugin.settings,
      0
    );
    this._laidOutWidth = this.pager.builtWidth || w;
    const hasBlock = typeof savedBlock === "number" && savedBlock >= 0;
    const targetSpread = hasBlock ? this.pager.spreadForBlock(savedBlock) : Math.round(savedPct * Math.max(0, total - 1));
    this._renderFlowHighlights();
    this.pager.jumpTo(targetSpread);
      const [cur, tot] = this.pager.restoreBlockPosition(savedBlock);
    this.updateUI(cur, tot);
    erRevealWhenSettled(this);
    if (hasBlock) this._flashBlock(savedBlock);
  }
  // Briefly highlight the paragraph the reader resumed at, so the eye finds it.
  // Jump to a paragraph as soon as the book is laid out. Called from a backlink,
  // which arrives while the book is still being built, so it waits for the
  // pager rather than assuming the text is already there. Gives up after a few
  // seconds instead of polling forever on a book that failed to open.
  // Land on a PDF page once the book is laid out. Pages are marked in the flow
  // with data-pdf-page-no, so this is a lookup rather than a guess.
  jumpToPdfPageWhenReady(pageNo) {
    let tries = 0;
    const tick = () => {
      const flow = this.pager && this.pager.flow;
      if (flow && this.pager.total) {
        const el = flow.querySelector(`[data-pdf-page-no="${pageNo}"]`);
        if (el) {
          const x = el.getBoundingClientRect().left - flow.getBoundingClientRect().left;
          const stride = this.pager.sw / (this.pager.cols || 1);
          const spread = Math.floor(Math.round(x / stride) / (this.pager.cols || 1));
          const [cur, tot] = this.pager.jumpTo(Math.max(0, Math.min(spread, this.pager.total - 1)));
          (this.updateUI || this._updateUI).call(this, cur, tot);
          return;
        }
      }
      if (++tries > 40) return;
      window.setTimeout(tick, 100);
    };
    tick();
  }
  jumpToBlockWhenReady(idx) {
    let tries = 0;
    const tick = () => {
      if (this.pager && this.pager.flow && this.pager.total) {
        const [cur, tot] = this.pager.jumpTo(this.pager.spreadForBlock(idx));
        (this.updateUI || this._updateUI).call(this, cur, tot);
        this._flashBlock(idx);
        return;
      }
      if (++tries > 40) return;
      window.setTimeout(tick, 100);
    };
    tick();
  }
  _flashBlock(idx) {
    const el = this.pager.blockEl(idx);
    if (!el) return;
    el.classList.remove("er-resume-flash");
    void el.offsetWidth;
    el.classList.add("er-resume-flash");
    window.setTimeout(() => el.classList.remove("er-resume-flash"), 2400);
  }
  // Paint every occurrence of the search term in the book, so that after jumping
  // to a result the eye finds the actual word instead of hunting through the
  // paragraph.
  //
  // Uses the CSS Custom Highlight API: it draws over existing text WITHOUT
  // touching the DOM. Wrapping matches in <span> would have been the obvious
  // route, but inserting elements into the flow re-runs the column layout and
  // would disturb both pagination and the reader's own <mark> highlights.
  _markFound(query) {
    markFoundIn(this, query);
  }
  _clearFound() {
    clearFoundIn(this);
  }
  // Jump to the page holding a global block index, flash it, save the position.
  // Used by the TOC panel.
  _jumpToBlock(block, flash = true) {
    if (!this.bookHtml || typeof block !== "number") return;
    const [cur, tot] = this.pager.jumpTo(this.pager.spreadForBlock(block));
    this.updateUI(cur, tot);
    if (this.file) this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
    if (flash) this._flashBlock(block);
  }
  // Repaginate preserving current reading % (used on settings change)
  // Show/hide the "re-laying out" veil: the page blurs and a spinner fades in.
  // The class goes on the ROOT, not on the reading area, because the spinner has
  // to sit OUTSIDE the blurred element — a child of it would be blurred too.
  _setRelayout(on) {
    if (!on) erHideVeil(this);
    const root = this.contentEl;
    if (!root) return;
    if (on && !this._spinEl) {
      this._spinEl = root.createDiv("er-relayout-spin");
      this._spinEl.createDiv("er-relayout-ring");
    }
    root.toggleClass("er-relayouting", !!on);
  }
  async repaginate(anchor = null) {
    if (!this.bookHtml) return;
    if (!this.areaEl.clientWidth || this.containerEl.offsetParent === null) return;
    const savedBlock = Number.isInteger(anchor) ? anchor : this.pager.currentBlockIndex();
    const savedPct = this.pager.currentPct;
    this._setRelayout(true);
    erShowVeil(this);
    try {
      await new Promise((r) => window.requestAnimationFrame(r));
      this.areaEl.empty();
      const [, total] = await this.pager.build(
        this.areaEl,
        this.bookHtml,
        this.plugin.settings,
        0
      );
      this._laidOutWidth = this.pager.builtWidth || this.areaEl.clientWidth;
      const w = this.areaEl.clientWidth;
      this._staleGaveUpAt = w && Math.abs(w - (this.pager.builtWidth || 0)) >= 8 ? this.pager.builtWidth : null;
      const targetSpread = typeof savedBlock === "number" && savedBlock >= 0 ? this.pager.spreadForBlock(savedBlock) : Math.round(savedPct * Math.max(0, total - 1));
      this._renderFlowHighlights();
      this.pager.jumpTo(targetSpread);
      const [cur, tot] = this.pager.restoreBlockPosition(savedBlock);
      this.updateUI(cur, tot);
      if (this._tocRender) this._tocRender();
      this._findCorpus = null;
      if (this._foundQuery) this._markFound(this._foundQuery);
    } finally {
      window.requestAnimationFrame(() => this._setRelayout(false));
    }
  }
  // ── DOM ──────────────────────────────────────────────
  buildDOM() {
    const root = this.contentEl;
    root.empty();
    root.addClass("er-view");
    this.applyVars();
    const pb = root.createDiv("er-pbar");
    this.pbarFill = pb.createDiv("er-pbar-fill");
    const top = root.createDiv("er-top");
    mountSpeech(this, root, top); mountReadingControls(this, root, top);
    const lb = top.createDiv("er-ibtn");
    svgIcon(lb, "arrow-left");
    lb.addEventListener("click", () => this.plugin.openLibrary());
    this.titleEl = top.createDiv("er-top-title");
    this.titleEl.setText("Book Reader TTS");
    const tr = top.createDiv("er-top-right");
    const saveBtn = tr.createDiv("er-ibtn");
    svgIcon(saveBtn, "save");
    saveBtn.setAttribute("aria-label", __ertr("Save position"));
    saveBtn.addEventListener("click", () => this.saveNow());
    const refBtn = tr.createDiv("er-ibtn");
    svgIcon(refBtn, "refresh");
    refBtn.setAttribute("aria-label", __ertr("Refresh (redraw the view)"));
    refBtn.addEventListener("click", () => this.reloadView());
    const hlBtn = tr.createDiv("er-ibtn");
    svgIcon(hlBtn, "highlighter");
    hlBtn.setAttribute("aria-label", __ertr("Highlights"));
    hlBtn.addEventListener("click", () => this.togglePanel("highlights"));
    const findBtn = tr.createDiv("er-ibtn");
    svgIcon(findBtn, "search");
    findBtn.setAttribute("aria-label", __ertr("Search the book"));
    findBtn.addEventListener("click", () => {
      this.togglePanel("find");
      if (this._findInput) erAutoFocus(this._findInput, 60);
    });
    const tocBtn = tr.createDiv("er-ibtn");
    svgIcon(tocBtn, "list");
    tocBtn.setAttribute("aria-label", __ertr("Table of contents"));
    tocBtn.addEventListener("click", () => this.togglePanel("toc"));
    const setBtn = tr.createDiv("er-ibtn");
    svgIcon(setBtn, "sliders");
    setBtn.setAttribute("aria-label", __ertr("Reading settings"));
    setBtn.addEventListener("click", () => new ReadSettingsModal(this.app, this).open());
    this.areaEl = root.createDiv("er-area");
    if ((this.plugin.settings.navMode || "buttons") === "click") root.addClass("er-navclick");
    const bot = root.createDiv("er-bot");
    const pv = bot.createDiv("er-navbtn");
    svgIcon(pv, "chevron-left");
    pv.addEventListener("click", () => this.nav("prev"));
    const center = bot.createDiv("er-bot-center");
    this.locEl = center.createDiv("er-loc er-loc-clickable");
    this.locEl.setAttribute("aria-label", __ertr("Go to page"));
    this.locEl.addEventListener("click", () => {
      if (!this.file || !this.pager || !this.pager.total) return;
      new GoToPageModal(this.app, this.pager.total, this.pager.spread, (n) => {
        const [cur, tot] = this.pager.jumpTo(n - 1);
        this.updateUI(cur, tot);
        this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
      }).open();
    });
    this.pctEl = center.createDiv("er-pct");
    this.pctEl.setText("0%");
    mountReadingProgress(this, bot,()=>toggleTimerSession(this));
    const nx = bot.createDiv("er-navbtn");
    svgIcon(nx, "chevron-right");
    nx.addEventListener("click", () => this.nav("next"));
    this.overlayEl = root.createDiv("er-overlay");
    this.overlayEl.addEventListener("click", () => this.closePanel());
    this.settPan = root.createDiv("er-panel");
    this.tocPan = root.createDiv("er-panel er-toc-panel");
    this.hlPan = root.createDiv("er-panel er-toc-panel er-hl-panel");
    this.findPan = root.createDiv("er-panel er-toc-panel er-find-panel");
    this.buildSettPanel();
    this.buildTocPanel();
    this.buildHlPanel();
    this.buildFindPanel();
    this.hlPopup = root.createDiv("er-hl-popup");
    this.buildHlPopup();
    this.registerDomEvent(docOf(this.containerEl), "selectionchange", () => this._scheduleSelCheck());
    this.areaEl.addEventListener("mouseup", () => this._scheduleSelCheck());
    this.areaEl.addEventListener("click", (e) => {
      const refEl = e.target instanceof HTMLElement ? e.target.closest("[data-er-ref]") : null;
      if (refEl) {
        e.preventDefault();
        e.stopPropagation();
        if (followFootnote(this, refEl.getAttribute("data-er-ref"))) return;
      }
      const imgEl = e.target instanceof HTMLElement ? e.target.closest("img") : null;
      if (imgEl && imgEl.src) {
        e.preventDefault();
        openImageLightbox(imgEl.currentSrc || imgEl.src, this.app, imgEl);
        return;
      }
      const span = e.target instanceof HTMLElement ? e.target.closest(".er-hl") : null;
      if (span) {
        e.preventDefault();
        this._openHlEdit(span.getAttribute("data-hl-id"));
      } else if (this._editHlId) {
        this._hideHlPopup();
      }
    });
    this.registerDomEvent(docOf(this.containerEl), "mousedown", (e) => {
      if (!this._editHlId) return;
      const t = e.target;
      if (this.hlPopup.contains(t)) return;
      if (t instanceof HTMLElement && t.closest(".er-hl")) return;
      this._hideHlPopup();
    });
    this.areaEl.addEventListener("contextmenu", (e) => {
      const sel = selOf(this.areaEl);
      const text = sel && !sel.isCollapsed && sel.rangeCount ? sel.toString() : "";
      const flow = this.pager.flow;
      if (!text.trim() || !flow || !flow.contains(sel.getRangeAt(0).startContainer)) return;
      e.preventDefault();
      const menu = new Menu();
      menu.addItem((it) => it.setTitle(__ertr("Copy as a quote")).setIcon("text-quote").onClick(async () => {
        this._hideHlPopup();
        const md = quoteMarkdown(this.plugin, { text, block: this._pendingSel && this._pendingSel.block, page: this._pendingSel && this._pendingSel.page }, this.file);
        const okc = md && await copyToClipboard(md);
        new Notice(okc ? __ertr("Quote copied ✓ — paste it into any note") : __ertr("Could not copy"));
      }));
      menu.addItem((it) => it.setTitle(__ertr("Create new note")).setIcon("file-plus").onClick(() => {
        this._hideHlPopup();
        createNoteFromSelection(this.app, this.plugin, text, this.file);
      }));
      menu.addItem((it) => it.setTitle(__ertr("As text into the book note")).setIcon("text-quote").onClick(() => {
        this._hideHlPopup();
        sendQuoteToBookNote(this, { text, block: this._pendingSel && this._pendingSel.block });
      }));
      menu.addSeparator();
      HL_COLORS.forEach((c) => {
        menu.addItem((it) => it.setTitle(__ertr("Highlight: {0}", c.name)).onClick(() => {
          this._onSelectionCheck();
          this._applyPopupColor(c.id);
        }));
      });
      menu.showAtMouseEvent(e);
    });
    this.registerDomEvent(docOf(this.containerEl), "keydown", (e) => {
      let _a;
      if (!this.bookHtml)
        return;
      const ae = docOf(this.areaEl).activeElement;
      if (ae && (ae.tagName === "INPUT" || ae.tagName === "TEXTAREA" || ae.isContentEditable))
        return;
      if (!this.containerEl.contains(ae) && this.app.workspace.getActiveViewOfType(this.constructor) !== this)
        return;
      if (e.key === "ArrowRight" || e.key === "ArrowDown" || e.key === " ") {
        e.preventDefault();
        this.nav("next");
      }
      if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
        e.preventDefault();
        this.nav("prev");
      }
    });
    let sx = 0, sy = 0, _swipeDir = null, _longPress = false, _lpTimer = null, _hadSel = false;
    this.areaEl.addEventListener("touchstart", (e) => {
      if (e.touches.length > 1) {
        _swipeDir = "v";
        return;
      }
      sx = e.touches[0].clientX;
      sy = e.touches[0].clientY;
      _swipeDir = null;
      _longPress = false;
      const sel = selOf(this.areaEl);
      _hadSel = !!(sel && !sel.isCollapsed);
      window.clearTimeout(_lpTimer);
      _lpTimer = window.setTimeout(() => {
        _longPress = true;
      }, 350);
    }, { passive: true });
    this.areaEl.addEventListener("touchmove", (e) => {
      if (_swipeDir !== null) {
        if (_swipeDir === "h") e.preventDefault();
        return;
      }
      const dx = Math.abs(e.touches[0].clientX - sx);
      const dy = Math.abs(e.touches[0].clientY - sy);
      if (dx < 8 && dy < 8) return;
      window.clearTimeout(_lpTimer);
      const sel = selOf(this.areaEl);
      if (_longPress || _hadSel || sel && !sel.isCollapsed) {
        _swipeDir = "v";
        return;
      }
      _swipeDir = dx > dy ? "h" : "v";
      if (_swipeDir === "h") e.preventDefault();
    }, { passive: false });
    this.areaEl.addEventListener("touchend", (e) => {
      window.clearTimeout(_lpTimer);
      if (_swipeDir !== "h") return;
      const dx = e.changedTouches[0].clientX - sx;
      if (Math.abs(dx) > 44)
        dx < 0 ? this.nav("next") : this.nav("prev");
    }, { passive: true });
    this.areaEl.addEventListener("click", (e) => handleAreaNavClick(this, e));
    const armImmersive = () => {
      if (!this.plugin.settings.immersive) {
        root.removeClass("er-immersive");
        return;
      }
      root.removeClass("er-immersive");
      window.clearTimeout(this._immTimer);
      this._immTimer = window.setTimeout(() => {
        if (this.bookHtml) root.addClass("er-immersive");
      }, 2600);
    };
    root.addEventListener("pointermove", armImmersive);
    root.addEventListener("pointerdown", armImmersive);
    root.addEventListener("touchstart", armImmersive, { passive: true });
    armImmersive();
  }
  applyVars() {
    const t = erTheme(this.plugin.settings);
    const s = this.plugin.settings;
    const r = this.contentEl;
    r.style.setProperty("--er-bg", t.bg);
    r.style.setProperty("--er-text", t.text);
    r.style.setProperty("--er-ui", t.ui);
    r.style.setProperty("--er-border", t.border);
    r.style.setProperty("--er-accent", t.accent);
    r.style.setProperty("--er-muted", t.muted);
    r.toggleClass("er-eink", s.einkMode === true);
  }
  nav(dir) {
    if (!this.bookHtml)
      return;
    const _now = Date.now();
    if (this._lastNavTs && _now - this._lastNavTs < 90) return;
    this._lastNavTs = _now;
    this._lastActive = _now;
    if (this._layoutWidthStale()) {
      this.repaginate().then(() => this._navNow(dir)).catch(() => this._navNow(dir));
      return;
    }
    this._navNow(dir);
  }
  _navNow(dir) {
    if (!this.bookHtml) return;
    this._hideHlPopup();
    const [cur, total] = dir === "next" ? this.pager.next() : this.pager.prev();
    this.updateUI(cur, total);
    this.plugin.saveProgress(this.file.path, cur, total, this.pager.currentBlockIndex());
  }
  // True when the page is laid out for a different width than it is displayed at.
  // `builtWidth` is what the paginator actually measured, so this compares like
  // with like — the width the caller *intended* can differ from it.
  _layoutWidthStale() {
    if (!this.bookHtml || !this.pager || !this.pager.builtWidth) return false;
    if (this.containerEl.offsetParent === null) return false;
    if (this._staleGaveUpAt === this.pager.builtWidth) return false;
    const now = this.areaEl.clientWidth;
    if (!now) return false;
    return Math.abs(now - this.pager.builtWidth) >= 8;
  }
  // Manual save (💾 button / command): persist the current spot AND drop a
  // restore point, with a clear confirmation — like "saved" in a game.
  saveNow() {
    if (!this.bookHtml || !this.file) {
      new Notice(__ertr("Nothing to save"));
      return;
    }
    const cur = this.pager.spread, tot = this.pager.total;
    const pct = this.plugin.saveNow(this.file.path, cur, tot, this.pager.currentBlockIndex());
    new Notice(__ertr("Saved ✓ — {0}%", pct));
    if (this.panelOpen === "settings") this._renderHistory();
  }
  exportHighlights(evt) {
    if (!this.file) {
      new Notice(__ertr("No book is open"));
      return;
    }
    const list = enrichHighlights(this, this.plugin.getHighlights(this.file.path));
    exportHighlightsMenu(this.app, this.plugin, this.file, list, evt);
  }
  updateUI(cur, total) {
    /* Hide page arrows and edge-click navigation in scrolling mode. */
    if (this.contentEl) this.contentEl.toggleClass("er-scrolling", !!(this.pager && this.pager.scrollMode));
    const pct = total > 0 ? Math.round((cur + 1) / total * 100) : 0;
    this.pbarFill.style.width = `${pct}%`;
    const bookPage = currentBookPage(this);
    const where = this.ext === "pdf" ? __ertr("Spread {0} of {1}", cur + 1, total) : `${cur + 1} / ${total}`;
    this.locEl.setText(bookPage ? __ertr("p. {0}", bookPage) + " \xB7 " + where : where);
    this.pctEl.setText(`${pct}%`);
    this._readingProgress?.update(cur,total);
    renderVisibleFigures(this);
  }
  // ── Settings panel ────────────────────────────────────
  buildSettPanel() {
    const p = this.settPan;
    p.empty();
    p.createDiv("er-pan-title").setText(__ertr("Reading settings"));
    const sec = (l) => p.createDiv("er-pan-sec").setText(l);
    sec(__ertr("Theme"));
    const thRow = p.createDiv("er-theme-row");
    ["auto", "dark", "light", "sepia", "eink"].forEach((t) => {
      const btn = thRow.createDiv(`er-theme-btn er-theme-${t}`);
      btn.setText({ auto: __ertr("Match Obsidian"), dark: __ertr("Dark"), light: __ertr("Light"), sepia: __ertr("Sepia"), eink: "E-ink" }[t]);
      if (this.plugin.settings.theme === t)
        btn.addClass("active");
      btn.addEventListener("click", async () => {
        this.plugin.settings.theme = t;
        await this.plugin.saveAll();
        this.applyVars();
        if (this.bookHtml)
          await this.repaginate();
        thRow.querySelectorAll(".er-theme-btn").forEach((b) => b.removeClass("active"));
        btn.addClass("active");
      });
    });
    sec(__ertr("Font size"));
    const szRow = p.createDiv("er-sz-row");
    const szM = szRow.createDiv("er-sz-btn");
    szM.setText("A−");
    const szL = szRow.createDiv("er-sz-label");
    szL.setText(`${this.plugin.settings.fontSize}px`);
    const szP = szRow.createDiv("er-sz-btn");
    szP.setText("A+");
    const changeSz = async (d) => {
      const nv = this.plugin.settings.fontSize + d;
      if (nv < 12 || nv > 36)
        return;
      this.plugin.settings.fontSize = nv;
      szL.setText(`${nv}px`);
      await this.plugin.saveAll();
      if (this.bookHtml)
        await this.repaginate();
    };
    szM.addEventListener("click", () => changeSz(-1));
    szP.addEventListener("click", () => changeSz(1));
    const advHdr = p.createDiv("er-pan-adv-hdr");
    advHdr.createSpan({ cls: "er-pan-adv-ic", text: "⚙️" });
    advHdr.createSpan({ cls: "er-pan-adv-lbl", text: __ertr("More settings") });
    const advCar = advHdr.createSpan({ cls: "er-pan-adv-car", text: "›" });
    const advWrap = p.createDiv("er-pan-adv");
    const adv = advWrap.createDiv("er-pan-adv-body");
    const secA = (l) => adv.createDiv("er-pan-sec").setText(l);
    if (this.plugin.settings.readerAdvOpen) {
      advWrap.addClass("er-pan-adv-on");
      advCar.addClass("er-pan-adv-car-on");
    }
    advHdr.addEventListener("click", async () => {
      const on = advWrap.hasClass("er-pan-adv-on");
      advWrap.toggleClass("er-pan-adv-on", !on);
      advCar.toggleClass("er-pan-adv-car-on", !on);
      this.plugin.settings.readerAdvOpen = !on;
      await this.plugin._saveLocalData();
    });
    secA(__ertr("Font"));
    const ffRow = adv.createDiv("er-ff-row");
    ["georgia", "lora", "inter"].forEach((f) => {
      const btn = ffRow.createDiv("er-ff-btn");
      btn.setText({ georgia: "Georgia", lora: "Lora", inter: "Inter" }[f]);
      btn.style.fontFamily = FONTS[f];
      if (this.plugin.settings.fontFamily === f)
        btn.addClass("active");
      btn.addEventListener("click", async () => {
        this.plugin.settings.fontFamily = f;
        await this.plugin.saveAll();
        if (this.bookHtml)
          await this.repaginate();
        ffRow.querySelectorAll(".er-ff-btn").forEach((b) => b.removeClass("active"));
        btn.addClass("active");
      });
    });
    secA(__ertr("Line spacing"));
    const lhRow = adv.createDiv("er-lh-row");
    [1.4, 1.6, 1.8, 2.1].forEach((lh) => {
      const btn = lhRow.createDiv("er-lh-btn");
      btn.setText(`${lh}`);
      if (Math.abs(this.plugin.settings.lineHeight - lh) < 0.05)
        btn.addClass("active");
      btn.addEventListener("click", async () => {
        this.plugin.settings.lineHeight = lh;
        await this.plugin.saveAll();
        if (this.bookHtml)
          await this.repaginate();
        lhRow.querySelectorAll(".er-lh-btn").forEach((b) => b.removeClass("active"));
        btn.addClass("active");
      });
    });
    secA(__ertr("Pages side by side"));
    const colRow = adv.createDiv("er-col-row");
    [["1", __ertr("1 page")], ["2", __ertr("2 pages")]].forEach(([v, label]) => {
      const btn = colRow.createDiv("er-col-btn");
      btn.setText(label);
      if (this.plugin.settings.columns === v)
        btn.addClass("active");
      btn.addEventListener("click", async () => {
        this.plugin.settings.columns = v;
        await this.plugin.saveAll();
        if (this.bookHtml)
          await this.repaginate();
        colRow.querySelectorAll(".er-col-btn").forEach((b) => b.removeClass("active"));
        btn.addClass("active");
      });
    });
    buildReaderExtraSettings(this, adv);
    this._histRow = panelSection(this, p, {
      label: __ertr("Jump back"),
      emoji: "\u{1F516}",
      settingKey: "readerHistOpen"
    }).createDiv("er-hist-row");
    this._renderHistory();
    sec(__ertr("Actions"));
    const actRow = p.createDiv("er-act-row");
    const mkAct = (label, ic, fn) => {
      const b = actRow.createDiv("er-act-btn");
      iconLabel(b, ic, label);
      b.addEventListener("click", fn);
    };
    mkAct(__ertr("Help"), "info", () => new InfoModal(this.app, this.plugin, this.file).open());
  }
  _renderHistory() {
    const c = this._histRow;
    if (!c) return;
    c.empty();
    const list = this.file ? this.plugin.getBackups(this.file.path) : [];
    const badge = c.parentElement && c.parentElement._erCount;
    if (badge) badge.setText(list.length ? String(list.length) : "");
    if (!list.length) {
      c.createDiv("er-hist-empty").setText(__ertr("No points yet"));
      return;
    }
    [...list].reverse().slice(0, 14).forEach((snap) => {
      const chip = c.createDiv("er-hist-chip");
      if (snap.manual) chip.addClass("er-hist-manual");
      const d = new Date(snap.ts || snap.lastRead || Date.now());
      const mark = snap.manual ? "\u{1F4BE} " : "";
      chip.setText(`${mark}${snap.percent}% \xB7 ${d.toLocaleString(systemLocale(), { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}`);
      chip.addEventListener("click", () => {
        if (!this.bookHtml) return;
        const total = this.pager.total;
        let target;
        if (typeof snap.block === "number" && snap.block >= 0) {
          target = this.pager.spreadForBlock(snap.block);
        } else {
          const frac = typeof snap.pct === "number" ? snap.pct : (snap.percent || 0) / 100;
          target = Math.round(frac * Math.max(0, total - 1));
        }
        const [cur, tot] = this.pager.jumpTo(target);
        this.updateUI(cur, tot);
        if (this.file) this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
        this.closePanel();
        new Notice(__ertr("Jumped back to {0}%", snap.percent));
      });
    });
  }
  buildTocPanel() {
    this._tocRender = buildTocPanelFor(this, this.tocPan, {
      close: () => this.closePanel(),
      jump: (b) => this._jumpToBlock(b)
    });
  }
  // Find text anywhere in the open book. Results are block indexes — the same
  // anchor reading position and the contents list use — so a hit lands correctly
  // whatever the window width or column count.
  buildFindPanel() {
    buildFindPanelFor(this, this.findPan, {
      close: () => this.closePanel(),
      jump: (b) => this._jumpToBlock(b)
    });
  }
  togglePanel(name) {
    if (this.panelOpen === name) {
      this.closePanel();
      return;
    }
    this._hideHlPopup();
    if (name === "highlights") this.buildHlPanel();
    if (name === "settings") this._renderHistory();
    if (name === "toc" && this._tocRender) this._tocRender();
    this.panelOpen = name;
    this.settPan.classList.toggle("er-panel-open", name === "settings");
    this.tocPan.classList.toggle("er-panel-open", name === "toc");
    this.findPan.classList.toggle("er-panel-open", name === "find");
    this.hlPan.classList.toggle("er-panel-open", name === "highlights");
    if (this.findPan) this.findPan.classList.toggle("er-panel-open", name === "find");
    if (name === "toc" && this._tocRender) this._tocRender();
    this.overlayEl.classList.add("er-overlay-on");
  }
  closePanel() {
    this.panelOpen = null;
    this.settPan.classList.remove("er-panel-open");
    this.tocPan.classList.remove("er-panel-open");
    this.hlPan.classList.remove("er-panel-open");
    if (this.findPan) this.findPan.classList.remove("er-panel-open");
    this.overlayEl.classList.remove("er-overlay-on");
  }
  // ── Refresh: save progress + rebuild cleanly (kills stray column) ──────
  async reloadView() {
    if (!this.bookHtml || !this.file) {
      new Notice(__ertr("Nothing to refresh"));
      return;
    }
    const cur = this.pager.spread, tot = this.pager.total;
    this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
    const pct = this.pager.currentPct;
    this._hideHlPopup();
    this.closePanel();
    await this.plugin.refreshHighlights();
    this._lastWidth = this.areaEl.clientWidth;
    await this.paginate(pct);
    new Notice(__ertr("Refreshed"));
  }
  // ── Highlights: render / select / navigate ────────────
  _renderFlowHighlights() {
    if (!this.file || !this.pager.flow) return;
    const flow = this.pager.flow;
    unwrapAllHighlights(flow);
    const blocks = flow.querySelectorAll("p,h1,h2,h3,h4");
    const list = this.plugin.getHighlights(this.file.path);
    for (const hl of list) {
      const block = blocks[hl.block];
      if (!block) continue;
      const text = block.textContent;
      const loc = locateHl(text, hl);
      if (!loc) continue;
      wrapBlockRange(block, loc.start, loc.start + loc.len, { id: hl.id, color: hlColorCss(hl.color) });
    }
  }
  _scheduleSelCheck() {
    window.clearTimeout(this._selTimer);
    this._selTimer = window.setTimeout(() => this._onSelectionCheck(), 60);
  }
  _onSelectionCheck() {
    if (this._editHlId) return;
    const sel = selOf(this.areaEl);
    if (!sel || sel.isCollapsed || sel.rangeCount === 0) {
      this._hideHlPopup();
      return;
    }
    const range = sel.getRangeAt(0);
    const flow = this.pager.flow;
    if (!flow || !flow.contains(range.startContainer)) {
      this._hideHlPopup();
      return;
    }
    let node = range.startContainer;
    if (node.nodeType === Node.TEXT_NODE) node = node.parentElement;
    const block = node ? node.closest("p,h1,h2,h3,h4") : null;
    if (!block || !flow.contains(block)) {
      this._hideHlPopup();
      return;
    }
    const blocks = [...flow.querySelectorAll("p,h1,h2,h3,h4")];
    const blockIndex = blocks.indexOf(block);
    if (blockIndex < 0) {
      this._hideHlPopup();
      return;
    }
    const parts = [];
    for (let bi = blockIndex; bi < blocks.length; bi++) {
      const b = blocks[bi];
      if (bi > blockIndex && !range.intersectsNode(b)) break;
      const bText = b.textContent;
      const from = bi === blockIndex ? offsetInBlock(b, range.startContainer, range.startOffset) : 0;
      const ends = b.contains(range.endContainer);
      const to = ends ? offsetInBlock(b, range.endContainer, range.endOffset) : bText.length;
      if (to > from) {
        const seg = bText.slice(from, to);
        if (seg.trim()) {
          parts.push({
            block: bi,
            occ: countOccurrencesBefore(bText, seg, from),
            text: seg,
            pre: bText.slice(Math.max(0, from - 32), from),
            post: bText.slice(to, to + 32)
          });
        }
      }
      if (ends) break;
    }
    if (!parts.length) {
      this._hideHlPopup();
      return;
    }
    this._pendingSel = { ...parts[0], parts, text: parts.map((p) => p.text).join(" ") };
    erPaintSelection(this, range);
    this._showHlPopup(erSelectionRect(range, this.areaEl));
  }
  buildHlPopup() {
    const pop = this.hlPopup;
    pop.empty();
    pop.addEventListener("mousedown", (e) => e.preventDefault());
    addBarButtons(this, pop);
    addMoreBtn(this, pop);
  }
  _applyPopupColor(colorId) {
    let _a, _b;
    if (this._editHlId && this.file) {
      const id = this._editHlId;
      this.plugin.setHighlightColor(this.file.path, id, colorId);
      (_a = this.pager.flow) == null ? void 0 : _a.querySelectorAll(`[data-hl-id="${id}"]`).forEach((s) => {
        s.style.background = hlColorCss(colorId);
      });
      if (this.panelOpen === "highlights") this.buildHlPanel();
      this._hideHlPopup();
      return;
    }
    if (this._pendingSel && this.file) {
      const parts = this._pendingSel.parts || [this._pendingSel];
      const made = [];
      for (const part of parts) {
        const id = this._createHighlight(part, colorId);
        if (id) made.push({ ...part, id, color: colorId });
      }
      (_b = selOf(this.areaEl)) == null ? void 0 : _b.removeAllRanges();
      if (this.panelOpen === "highlights") this.buildHlPanel();
      if (this.plugin.settings.quotesToBookNote === true && made.length) {
        for (const hl of made) sendQuoteToBookNote(this, hl);
      }
    }
    this._hideHlPopup();
  }
  // Save a highlight for a pending selection and paint it in the text.
  // Returns its id — the comment button needs it, because commenting on a plain
  // selection has to create the highlight first (otherwise the note had nothing
  // to attach to and silently vanished).
  _createHighlight(sel, colorId) {
    if (!sel || !this.file) return null;
    const id = "h" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const hl = { id, color: colorId, text: sel.text, block: sel.block, occ: sel.occ, pre: sel.pre, post: sel.post, created: Date.now() };
    this.plugin.addHighlight(this.file.path, hl);
    const blocks = this.pager.flow.querySelectorAll("p,h1,h2,h3,h4");
    const block = blocks[hl.block];
    if (block) {
      const t = block.textContent;
      const loc = locateHl(t, hl);
      if (loc) wrapBlockRange(block, loc.start, loc.start + loc.len, { id: hl.id, color: hlColorCss(colorId) });
    }
    return id;
  }
  _currentHl() {
    if (this._editHlId && this.file) {
      const hl = this.plugin.getHighlights(this.file.path).find((h) => h.id === this._editHlId);
      if (hl) return { text: hl.text || "", block: hl.block, color: hl.color };
    }
    if (this._pendingSel) return { text: this._pendingSel.text || "", block: this._pendingSel.block, color: null };
    return null;
  }
  _openHlEdit(id) {
    let _a;
    const span = (_a = this.pager.flow) == null ? void 0 : _a.querySelector(`[data-hl-id="${id}"]`);
    if (!span) return;
    this._pendingSel = null;
    this._editHlId = id;
    this._showHlPopup(span.getBoundingClientRect());
  }
  _unwrapHighlight(id) {
    const flow = this.pager.flow;
    if (!flow) return;
    flow.querySelectorAll(`[data-hl-id="${id}"]`).forEach((span) => {
      const parent2 = span.parentNode;
      while (span.firstChild) parent2.insertBefore(span.firstChild, span);
      parent2.removeChild(span);
      parent2.normalize();
    });
  }
  _showHlPopup(rect) {
    const pop = this.hlPopup;
    pop.classList.add("er-hl-popup-on");
    positionHlPopup(this, rect, 210, 44);
  }
  _hideHlPopup() {
    erClearPaintedSelection();
    this._pendingSel = null;
    this._editHlId = null;
    if (this.hlPopup) this.hlPopup.classList.remove("er-hl-popup-on");
  }
  goToHighlight(id) {
    const flow = this.pager.flow;
    const span = flow == null ? void 0 : flow.querySelector(`[data-hl-id="${id}"]`);
    /* For lazy PDF pages, jump using the known paragraph index even if no painted highlight exists yet. */
    if (!span) {
      const hl = this.file ? this.plugin.getHighlights(this.file.path).find((h) => h.id === id) : null;
      if (!hl || typeof hl.block !== "number") {
        new Notice(__ertr("Highlight not found"));
        return;
      }
      const [c2, t2] = this.pager.jumpTo(this.pager.spreadForBlock(hl.block));
      this.updateUI(c2, t2);
      if (this.file) this.plugin.saveProgress(this.file.path, c2, t2, this.pager.currentBlockIndex());
      this.closePanel();
      window.requestAnimationFrame(() => {
        const later = this.pager.flow?.querySelector(`[data-hl-id="${id}"]`);
        if (later) {
          later.classList.add("er-hl-flash");
          window.setTimeout(() => later.classList.remove("er-hl-flash"), 1200);
        }
      });
      return;
    }
    const rel = span.getBoundingClientRect().left - flow.getBoundingClientRect().left;
    const spread = Math.max(0, Math.floor(rel / this.pager.sw + 1e-3));
    const [cur, tot] = this.pager.jumpTo(spread);
    this.updateUI(cur, tot);
    if (this.file) this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
    this.closePanel();
    span.classList.add("er-hl-flash");
    window.setTimeout(() => span.classList.remove("er-hl-flash"), 1200);
  }
  buildHlPanel() {
    const p = this.hlPan;
    p.empty();
    p.createDiv("er-pan-title").setText(__ertr("Highlights"));
    const list = this.file ? this.plugin.getHighlights(this.file.path) : [];
    if (!list.length) {
      p.createDiv("er-toc-empty").setText(__ertr("No highlights yet.\nSelect text and pick a color."));
      return;
    }
    const exp = p.createDiv("er-hl-export");
    iconLabel(exp, "download", __ertr("Export to notes ({0})", list.length));
    exp.setAttribute("aria-label", __ertr("Export all highlights"));
    exp.addEventListener("click", (e) => this.exportHighlights(e));
    const wrap = p.createDiv("er-toc-list");
    list.forEach((hl) => {
      const item = wrap.createDiv("er-hl-item");
      const dot = item.createDiv("er-hl-dot");
      dot.style.background = hlColorCss(hl.color);
      const body = item.createDiv("er-hl-body");
      const txt = body.createDiv("er-hl-text");
      txt.setText(hl.text.length > 160 ? hl.text.slice(0, 160) + "…" : hl.text);
      if (hl.comment) body.createDiv("er-hl-comment").setText(hl.comment);
      const showHlMenu = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!this.file) return;
        const menu = new Menu();
        menu.addItem((it) => it.setTitle(__ertr("Create note")).setIcon("file-plus").onClick(() => {
          createNoteFromSelection(this.app, this.plugin, hl.text, this.file, { extra: hlCommentMd(hl), color: hl.color, hl });
        }));
        menu.addItem((it) => it.setTitle(__ertr("As text into the book note")).setIcon("text-quote").onClick(() => {
          sendQuoteToBookNote(this, hl);
        }));
        menu.showAtMouseEvent(e);
      };
      const more = item.createDiv("er-hl-more");
      svgIcon(more, "more");
      more.setAttribute("aria-label", __ertr("More"));
      more.addEventListener("click", showHlMenu);
      const del = item.createDiv("er-hl-del");
      svgIcon(del, "trash");
      del.setAttribute("aria-label", __ertr("Delete"));
      del.addEventListener("click", (e) => {
        e.stopPropagation();
        if (!this.file) return;
        this.plugin.removeHighlight(this.file.path, hl.id);
        this._unwrapHighlight(hl.id);
        this.buildHlPanel();
      });
      item.addEventListener("click", () => this.goToHighlight(hl.id));
      item.addEventListener("contextmenu", showHlMenu);
    });
  }
  async onClose() {
    this._tts?.dispose();
    erHideVeil(this);
    let _a;
    stopReadingTimer(this);
    window.clearTimeout(this._immTimer);
    (_a = this._resizeObs) == null ? void 0 : _a.disconnect();
    window.clearTimeout(this._resizeTimer);
    window.clearTimeout(this._selTimer);
    window.clearTimeout(this._revealT);
    clearFoundIn(this);
  }
};
/* Build library categories from existing subfolders. Books in the root appear under No folder; folder paths are relative to the books folder. */
function bookRelFolder(bookPath, booksFolder) {
  const base = erPath(booksFolder);
  let rel = erPath(bookPath);
  if (base && rel.startsWith(base + "/")) rel = rel.slice(base.length + 1);
  const i = rel.lastIndexOf("/");
  return i > 0 ? rel.slice(0, i) : "";
}
function bookCategoryOf(bookPath, booksFolder) {
  const base = erPath(booksFolder);
  let rel = erPath(bookPath);
  if (base && rel.startsWith(base + "/")) rel = rel.slice(base.length + 1);
  const i = rel.indexOf("/");
  return i > 0 ? rel.slice(0, i) : "";
}
// Reading state of a book, for the status chips.
function bookStatusOf(prog) {
  if (!prog || !prog.lastRead) return "new";
  const pct = typeof prog.percent === "number" ? prog.percent : 0;
  if (pct >= 98) return "done";
  if (pct > 0) return "reading";
  return "new";
}
// The chips shown above the grid: status groups first (what you're doing right
// now matters more than where a file sits), then one chip per folder. Empty
// groups are dropped so the bar only ever offers filters that lead somewhere.
function buildLibChips(files, booksFolder, getProgress, getTags, activeChip) {
  const statuses = { reading: 0, new: 0, done: 0 };
  const folders = /* @__PURE__ */ new Map();
  const tags = /* @__PURE__ */ new Map();
  for (const f of files) {
    statuses[bookStatusOf(getProgress(f.path))]++;
    const cat = bookCategoryOf(f.path, booksFolder);
    folders.set(cat, (folders.get(cat) || 0) + 1);
    for (const t of (getTags ? getTags(f.path) : [])) tags.set(t, (tags.get(t) || 0) + 1);
  }
  const chips = [{ id: "all", label: __ertr("All"), count: files.length }];
  if (statuses.reading) chips.push({ id: "status:reading", label: __ertr("Reading"), count: statuses.reading });
  if (statuses.new) chips.push({ id: "status:new", label: __ertr("Not started"), count: statuses.new });
  if (statuses.done) chips.push({ id: "status:done", label: __ertr("Finished"), count: statuses.done });
  // Reader-assigned categories come before folders: they were chosen on purpose,
  // whereas the folder is just wherever the file happens to sit.
  for (const [t, n] of [...tags.entries()].sort((a, b) => a[0].localeCompare(b[0], systemLocale()))) {
    chips.push({ id: `tag:${t}`, label: t, count: n });
  }
  const named = [...folders.entries()].filter(([c]) => c).sort((a, b) => a[0].localeCompare(b[0], systemLocale()));
  // Subfolders of whichever folder is open, so a deep library can be walked
  // instead of only sliced at the top level. Counted the same way, and only
  // when there is more than one — a single child chip just repeats its parent.
  const openFolder = activeChip && activeChip.startsWith("folder:") ? activeChip.slice(7) : null;
  const subs = /* @__PURE__ */ new Map();
  if (openFolder) {
    for (const f of files) {
      const rel = bookRelFolder(f.path, booksFolder);
      if (rel !== openFolder && rel.startsWith(openFolder + "/")) {
        const next = openFolder + "/" + rel.slice(openFolder.length + 1).split("/")[0];
        subs.set(next, (subs.get(next) || 0) + 1);
      }
    }
  }
  /* Show folder chips only when they meaningfully divide the library, rather than duplicating All. */
  if (named.length > 1 || (named.length === 1 && folders.has(""))) {
    for (const [cat, n] of named) {
      chips.push({ id: `folder:${cat}`, label: cat, count: n });
      // The open folder's children slot in directly beneath it, labelled with
      // only their own name so the row does not fill with repeated prefixes.
      if (openFolder === cat && subs.size > 1) {
        for (const [sub, sn] of [...subs.entries()].sort((a, b) => a[0].localeCompare(b[0], systemLocale()))) {
          chips.push({ id: `folder:${sub}`, label: "└ " + sub.slice(cat.length + 1), count: sn, sub: true });
        }
      }
    }
    if (folders.get("")) chips.push({ id: "folder:", label: __ertr("No folder"), count: folders.get("") });
  }
  return chips;
}
// Apply the active chip + the search box.
function filterLibBooks(files, chipId, query, booksFolder, getProgress, getTags) {
  const needle = (query || "").trim().toLowerCase();
  return files.filter((f) => {
    if (needle && ![f.basename,...(getTags?getTags(f.path):[])].join(' ').toLowerCase().includes(needle)) return false;
    if (!chipId || chipId === "all") return true;
    if (chipId.startsWith("format:")) return chipId==='format:pdf'?f.extension==='pdf':f.extension!=='pdf';
    if (chipId.startsWith("status:")) return bookStatusOf(getProgress(f.path)) === chipId.slice(7);
    if (chipId.startsWith("folder:")) {
      /* Match folder prefixes so History also includes History/Ancient World. */
      const want = chipId.slice(7);
      const have = bookRelFolder(f.path, booksFolder);
      return want === "" ? have === "" : (have === want || have.startsWith(want + "/"));
    }
    if (chipId.startsWith("tag:")) return (getTags ? getTags(f.path) : []).includes(chipId.slice(4));
    return true;
  });
}
// Categories a reader has assigned to a book (always an array, never undefined).
function bookTagsOf(settings, bookPath) {
  const m = (settings && settings.bookTags) || {};
  const v = m[bookPath];
  return Array.isArray(v) ? v.filter(Boolean) : [];
}
// Every category used anywhere, for the "pick or type" dropdown.
function allBookTags(settings) {
  const m = (settings && settings.bookTags) || {};
  const set = /* @__PURE__ */ new Set();
  for (const k of Object.keys(m)) for (const t of (Array.isArray(m[k]) ? m[k] : [])) if (t) set.add(t);
  return [...set].sort((a, b) => a.localeCompare(b, systemLocale()));
}
/* Parse comma-separated categories such as Psychology, Business; also accept hashtags. */
function parseBookTags(raw) {
  return String(raw || "")
    .split(/[,，;；、\n]+/)
    .map((t) => t.trim().replace(/^#+/, "").trim())
    .filter(Boolean)
    .filter((t, i, a) => a.indexOf(t) === i);
}
const LibraryModal = class extends Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  async onOpen() {
    const { contentEl, modalEl } = this;
    // The class goes on the CONTAINER as well as the dialog. Every sizing rule
    // in the stylesheet is written as `.er-modal-lib .modal` — a descendant
    // selector — and with the class only on modalEl (which IS `.modal`) not one
    // of them ever matched: the library kept Obsidian's default dialog size, so
    // it never went full-bleed on a phone and never took the wide desktop size
    // either. As a view the class already sits on the container, which is why
    // the same stylesheet behaved differently there.
    this.containerEl.addClass("er-modal-lib");
    modalEl.addClass("er-modal-lib");
    contentEl.addClass("er-lib");
    // No status-bar measurement here: the library is a leaf on every platform
    // now, and a leaf's edges belong to Obsidian.
    const t = erLibTheme(this.plugin.settings);
    modalEl.style.setProperty("--er-lib-bg", t.bg);
    modalEl.style.setProperty("--er-lib-text", t.text);
    modalEl.style.setProperty("--er-lib-card", t.ui);
    modalEl.style.setProperty("--er-lib-border", t.border);
    modalEl.style.setProperty("--er-lib-accent", t.accent);
    modalEl.style.setProperty("--er-lib-muted", t.muted);
    contentEl.toggleClass('br-library-editing',!!this._libraryEditing);
    const hdr = contentEl.createDiv("er-lib-hdr");
    const brand = hdr.createDiv("er-lib-brand");
    brand.createDiv("er-lib-logo").setText("\u{1F4DA}");
    const hw = brand.createDiv("er-lib-hw");
    hw.createDiv("er-lib-title").setText(this.plugin.settings.libraryTitle || __ertr("Library"));
    hw.createDiv("er-lib-sub").setText(this.plugin.settings.librarySubtitle ?? __ertr("My reading collection"));
    const collectionHost=hdr.createDiv('br-collection-host');

    const editBooks=hdr.createEl('button',{text:__ertr(this._libraryEditing?'Done':'Edit')});
    editBooks.onclick=()=>{this._libraryEditing=!this._libraryEditing;this._librarySelected?.clear();this._refresh();};
    const readingSummary=contentEl.createEl('button',{cls:'br-library-reading-summary'});
    readingSummary.onclick=()=>openReadingInsights(this);
    readingSummary.setAttribute('aria-label',__ertr('Reading insights'));
    readingSummary.setText(__ertr('Today {0} · Total {1}',formatReadingTime(this.plugin.getTodaySeconds()),formatReadingTime(this.plugin.getTotalSeconds()))+'  ›');
    // Primary action: import .pdf / .epub / .fb2 into the books folder. Sits at the
    // head of the right-hand cluster, away from the cover-size +/- so the two "+"
    // never read as one control. Files can also be dropped anywhere on the modal.
    const addBtn = hdr.createDiv("er-lib-add");
    addBtn.setAttribute("role", "button");
    addBtn.setAttribute("tabindex", "0");
    addBtn.setAttribute("aria-label", __ertr("Add a book"));
    svgIcon(addBtn, "plus");
    addBtn.createSpan({ cls: "er-lib-add-label", text: __ertr("Add a book") });
    const doPick = () => this._pickBooks();
    addBtn.addEventListener("click", doPick);
    addBtn.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); doPick(); } });
    const batchButton=hdr.createEl('button',{cls:'br-library-batch',text:__ertr("Batch import and process")});
    batchButton.addEventListener('click',()=>this.plugin.openBatchBooks());
    this._setupDropZone();
    const search = hdr.createDiv("er-lib-search");
    const sIc = search.createDiv("er-lib-search-ic");
    svgIcon(sIc, "search");
    const input = search.createEl("input", { cls: "er-lib-search-input", attr: { type: "text", placeholder: __ertr("Search a book…"), spellcheck: "false" } });
    const count = hdr.createDiv("er-lib-count");
    // Manual size control — adjust how big the covers are, live.
    const sizeWrap = hdr.createDiv("er-lib-size");
    const applySize = () => {
      const basePx = Math.max(110, Math.min(300, this.plugin.settings.libCoverSize || 176));
      const px = this.plugin.settings.libraryLayout === 'compact' ? Math.round(basePx * 0.7) : basePx;
      if (this._grid) this._grid.style.gridTemplateColumns = `repeat(auto-fill,minmax(${px}px,1fr))`;
    };
    const mkSz = (label, d, aria) => {
      const b = sizeWrap.createDiv("er-lib-szbtn");
      b.setText(label);
      b.setAttribute("aria-label", aria);
      b.addEventListener("click", async () => {
        this.plugin.settings.libCoverSize = Math.max(110, Math.min(300, (this.plugin.settings.libCoverSize || 176) + d));
        applySize();
        window.requestAnimationFrame(() => this._sizeCovers());
        await this.plugin.saveAll();
      });
    };
    mkSz("−", -28, __ertr("Smaller covers"));
    mkSz("+", 28, __ertr("Larger covers"));
    contentEl.toggleClass('br-shelf-compact',this.plugin.settings.libraryLayout==='compact');
    const controls=contentEl.createDiv('br-shelf-controls');
    const sort=controls.createEl('select',{attr:{'aria-label':__ertr('Sort books')}});
    for(const [value,label] of [['recent','Recently read'],['title','Book title'],['added','Recently added'],['progress','Reading progress']])sort.createEl('option',{value,text:__ertr(label)});
    sort.value=this.plugin.settings.librarySort||'recent';
    sort.onchange=async()=>{this.plugin.settings.librarySort=sort.value;await this.plugin._saveLocalData();this._refresh();};
    this._librarySelected ??= new Set();
    const selection=controls.createSpan({cls:'br-selection-count'});
    this._updateLibrarySelection=()=>selection.setText(__ertr('Selected: {0}',this._librarySelected.size));this._updateLibrarySelection();
    controls.createEl('button',{text:__ertr('Select visible')}).onclick=()=>{for(const f of this._shownLibraryBooks||[])this._librarySelected.add(f.path);this._refresh();};
    controls.createEl('button',{text:__ertr('Clear all')}).onclick=()=>{this._librarySelected.clear();this._refresh();};
    controls.createEl('button',{text:__ertr('Add to bookshelves')}).onclick=()=>{if(this._librarySelected.size)openBookTags(this,[...this._librarySelected],true);else new Notice(__ertr('Select books first'));};
    const archiveMode=this.plugin.settings.libCategory==='archive';
    controls.createEl('button',{text:archiveMode?__ertr('Restore selected'):__ertr('Archive selected')}).onclick=async()=>{
      if(!this._librarySelected.size){new Notice(__ertr('Select books first'));return;}
      setArchived(this.plugin.settings,[...this._librarySelected],!archiveMode);this._librarySelected.clear();await this.plugin._saveLocalData();this._refresh();
    };
    await this.plugin.refreshProgress();
    const folder = erPath(this.plugin.settings.booksFolder);
    // Match on "<folder>/" — a bare startsWith would also pull in a sibling
    // folder that merely shares the prefix (e.g. "Books" catching "Books archive").
    const prefix = folder ? folder + "/" : "";
    const files = this.app.vault.getFiles().filter(
      (f) => (f.extension === "epub" || f.extension === "pdf" || f.extension === "fb2") && (prefix === "" || f.path.startsWith(prefix))
    );
    const livePaths=new Set(files.map(f=>f.path));
    this._librarySelected=new Set([...this._librarySelected].filter(p=>livePaths.has(p)));
    this._updateLibrarySelection();
    const currentFiles=visibleBooks(files,this.plugin.settings,false);
    const archivedFiles=visibleBooks(files,this.plugin.settings,true);
    // Category chips — folders the books live in, plus reading-state groups.
    const chipsRow = contentEl.createDiv("er-lib-chips");
    const grid = contentEl.createDiv("er-lib-grid");
    const plural = (n) => {
      const a = Math.abs(n) % 100, b = a % 10;
      if (a > 10 && a < 20) return __ertr("books");
      if (b > 1 && b < 5) return __ertr("books");
      if (b === 1) return __ertr("book");
      return __ertr("books");
    };
    this._grid = grid;
    applySize();
    const getProg = (p) => this.plugin.getProgress(p);
    const getTags = (p) => bookTagsOf(this.plugin.settings, p);
    // Remember the last chip across sessions, but fall back to "\u0412\u0441\u0435" if that
    // category no longer exists (folder renamed, last book in it finished\u2026).
    let active = this.plugin.settings.libCategory || "all";
    // The chip list depends on which chip is active \u2014 an open folder shows its
    // subfolders \u2014 so it is built with the remembered choice in hand, then the
    // choice is validated against what actually came back.
    const makeChips=()=>{
      let result=buildLibChips(currentFiles,folder,getProg,getTags,active);
      if(this.plugin.settings.libraryShowFolders!==true)result=result.filter(c=>!c.id.startsWith('folder:'));
      for(const tag of libraryTags(this.plugin.settings))if(!result.some(c=>c.id==='tag:'+tag))result.push({id:'tag:'+tag,label:tag,count:0});
      result.push({id:'format:books',label:__ertr('Books'),count:currentFiles.filter(f=>f.extension!=='pdf').length});
      result.push({id:'format:pdf',label:'PDF',count:currentFiles.filter(f=>f.extension==='pdf').length});
      result.push({id:'archive',label:__ertr('Archive'),count:archivedFiles.length});
      return result.map(c=>({...c,label:this.plugin.settings.libraryLabels?.[c.id]||c.label}));
    };
    let chips = makeChips();
    if((this.plugin.settings.libraryHiddenCollections||[]).includes(active))active="all";
    if (!chips.some((c) => c.id === active)) {
      active = "all";
      chips = makeChips();
    }
    const render = (q) => {
      grid.empty();
      const source=active==='archive'?archivedFiles:currentFiles;
      const shown=sortLibrary(filterLibBooks(source,active==='archive'?'all':active,q,folder,getProg,getTags),this.plugin.settings.librarySort,getProg,systemLocale());
      this._shownLibraryBooks=shown;this._libraryQuery=q;
      count.setText(`${shown.length} ${plural(shown.length)}`);
      if (!shown.length) {
        grid.createDiv("er-lib-noresult").setText(__ertr("Nothing found"));
        return;
      }
      for (const f of shown) this.renderCard(grid, f);
      // Re-check sizing across the modal's open animation (themes animate it, so an
      // early measurement is wrong) \u2014 the smart fallback only acts if needed.
      window.requestAnimationFrame(() => this._sizeCovers());
      [120, 350, 650].forEach((t) => window.setTimeout(() => this._sizeCovers(), t));
    };
    // The row is rebuilt on every pick, not just re-highlighted: opening a
    // folder adds its subfolders to the row, and leaving it takes them away.
    const chooseCollection=async id=>{
      this._librarySelected.clear();this.plugin.settings.libCategory=id;
      await this.plugin._saveLocalData();this._refresh();
    };
    this._disposeCollections?.();
    this._disposeCollections=mountCollections(contentEl.ownerDocument,collectionHost,{
      settings:this.plugin.settings,getItems:makeChips,save:()=>this.plugin._saveLocalData(),onClose:()=>this._refresh(),
      pick:chooseCollection,customize:()=>openShelfSettings(this),onError:e=>new Notice(__ertr('Error: {0}',e.message))
    });
    chipsRow.addClass('br-current-collection');
    chipsRow.append(collectionHost);
    const collectionSummary=collectionHost.querySelector('summary');
    collectionSummary.textContent=(chips.find(c=>c.id===active)?.label||__ertr('All'))+' ▾';
    chipsRow.createEl('button',{text:__ertr('Customize bookshelf')}).onclick=()=>openShelfSettings(this);
    input.addEventListener("input", () => render(input.value));
    input.value=this._libraryQuery||"";
    render(input.value);
    this._coverResizeObs = new ResizeObserver(() => this._sizeCovers());
    this._coverResizeObs.observe(grid);
    erAutoFocus(input, 60);
    erBlurOnTapOutside(this.contentEl, input);
  }
  // Open the OS file picker for the three supported formats, then import.
  _pickBooks() {
    const doc = docOf(this.contentEl);
    const inp = doc.createElement("input");
    inp.type = "file";
    inp.accept = ".pdf,.epub,.fb2,application/pdf,application/epub+zip";
    inp.multiple = true;
    inp.addClass("er-hidden");
    inp.addEventListener("change", async () => {
      const files = Array.from(inp.files || []);
      inp.remove();
      await this._importBooks(files);
    });
    doc.body.appendChild(inp);
    inp.click();
  }
  // Drag & drop OS files anywhere on the modal. Bound once to modalEl (which
  // survives a grid refresh), with a dashed overlay shown only while dragging.
  _setupDropZone() {
    if (this._dropBound) return;
    this._dropBound = true;
    const host = this.modalEl;
    const overlay = host.createDiv("er-lib-drop");
    const inner = overlay.createDiv("er-lib-drop-inner");
    svgIcon(inner, "plus");
    inner.createSpan({ text: __ertr("Drop the files to add them to your library") });
    let depth = 0;
    const hasFiles = (e) => !!e.dataTransfer && Array.from(e.dataTransfer.types || []).includes("Files");
    host.addEventListener("dragenter", (e) => { if (!hasFiles(e)) return; e.preventDefault(); depth++; host.addClass("er-lib-dragging"); });
    host.addEventListener("dragover", (e) => { if (!hasFiles(e)) return; e.preventDefault(); e.dataTransfer.dropEffect = "copy"; });
    host.addEventListener("dragleave", (e) => { if (!hasFiles(e)) return; depth = Math.max(0, depth - 1); if (!depth) host.removeClass("er-lib-dragging"); });
    host.addEventListener("drop", async (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      depth = 0;
      host.removeClass("er-lib-dragging");
      // Drop a FOLDER and `files` contains an entry that is not a file at all.
      // Asking it for its bytes either rejects or, on Windows, blocks the whole
      // renderer — which is the likeliest explanation for "drag and drop makes
      // Obsidian crash". The DataTransfer items know which is which, so ask
      // them and keep only real files.
      const items = Array.from(e.dataTransfer.items || []);
      const dropped = Array.from(e.dataTransfer.files || []);
      let usable = dropped;
      if (items.length === dropped.length && typeof items[0]?.webkitGetAsEntry === "function") {
        usable = dropped.filter((f, i) => {
          const entry = items[i].webkitGetAsEntry();
          return !entry || entry.isFile;
        });
        const folders = dropped.length - usable.length;
        if (folders) new Notice(__ertr("Folders were skipped — drop the book files themselves ({0})", folders));
      }
      await this._importBooks(usable);
    });
  }
  // Where to drop an imported book. The configured "books folder" wins; if it is
  // empty (the common case), land the file where most books already live so it
  // joins the existing library instead of the vault root. Only falls back to root
  // when the vault has no books yet.
  _targetDir() {
    const set = erPath(this.plugin.settings.booksFolder || "");
    if (set) return set;
    const exts = ["pdf", "epub", "fb2"];
    const counts = new Map();
    for (const f of this.app.vault.getFiles()) {
      if (!exts.includes(f.extension)) continue;
      const dir = f.parent && f.parent.path && f.parent.path !== "/" ? f.parent.path : "";
      counts.set(dir, (counts.get(dir) || 0) + 1);
    }
    let best = "", bestN = -1;
    for (const [dir, n] of counts) if (n > bestN) { best = dir; bestN = n; }
    return best;
  }
  // A collision-free destination path inside the books folder (or vault root),
  // sanitised for the filesystem and suffixed " (1)", " (2)"… if the name is taken.
  _freeBookPath(dir, name) {
    const clean = (name || "book").replace(/[\\/:*?"<>|\n\r\t]/g, "_").trim() || "book";
    const dot = clean.lastIndexOf(".");
    const base = dot > 0 ? clean.slice(0, dot) : clean;
    const ext = dot > 0 ? clean.slice(dot) : "";
    // Every constructed vault path goes through normalizePath (erPath). This one
    // was the exception, and it is the one that matters most: it is built from a
    // filename the operating system handed over, which can carry a trailing
    // space, a doubled slash or decomposed Unicode (macOS hands over NFD, the
    // vault stores NFC). Comparing an un-normalised path against the vault's
    // index can miss an existing file, and writing one can land somewhere other
    // than where it was checked for.
    const join = (b) => erPath((dir ? dir + "/" : "") + b + ext);
    let p = join(base), i = 1;
    while (this.app.vault.getAbstractFileByPath(p)) p = join(`${base} (${i++})`);
    return p;
  }
  // Import a list of picked/dropped File objects: keep only supported formats,
  // write each into the books folder as a real vault file, then refresh the grid.
  async _importBooks(fileList) {
    const exts = ["pdf", "epub", "fb2"];
    const all = fileList || [];
    // Take the extension off the END of the name rather than off the first dot,
    // and tolerate the stray whitespace some file managers hand over, so a name
    // like "The Art of War (2nd ed.).pdf " is still recognised as a PDF. The
    // MIME type is a second opinion for the two formats that have one.
    const extOf = (f) => {
      // `name` is normally there, but Electron also exposes the full `path`, and
      // a File that arrives without a usable name would otherwise be rejected as
      // "unsupported format" while sitting right there on disk.
      const raw = (f && f.name) || (f && f.path ? String(f.path).split(/[\\/]/).pop() : "");
      const n = String(raw || "").trim().replace(/[.\s]+$/, "");
      const dot = n.lastIndexOf(".");
      const e = dot > 0 ? n.slice(dot + 1).toLowerCase() : "";
      if (exts.includes(e)) return e;
      const mime = String((f && f.type) || "").toLowerCase();
      if (mime === "application/pdf") return "pdf";
      if (mime === "application/epub+zip") return "epub";
      return e;
    };
    const picked = all.filter((f) => exts.includes(extOf(f)));
    const rejected = all.filter((f) => !exts.includes(extOf(f)));
    if (rejected.length) {
      // Say WHAT was rejected and what the reader was seen as, not just that
      // something was. A reader reported files being refused as "unsupported"
      // that plainly were supported, and the old message gave nothing to go on —
      // no name, no extension, nothing to put in a bug report.
      const detail = rejected.slice(0, 5).map((f) => {
        const nm = (f && f.name) || (f && f.path) || "?";
        return `${nm} [${extOf(f) || "—"}${f && f.type ? ", " + f.type : ""}]`;
      }).join("; ");
      console.warn("Book Reader TTS: rejected on import —", rejected.map((f) => ({
        name: f && f.name, path: f && f.path, type: f && f.type, size: f && f.size, seenAs: extOf(f),
      })));
      new Notice(__ertr("Not accepted ({0}): {1}. PDF, EPUB and FB2 are supported.", rejected.length, detail), 10000);
    }
    if (!picked.length) {
      if (!rejected.length) new Notice(__ertr("No files selected"));
      return;
    }
    const dir = this._targetDir();
    if (dir && !this.app.vault.getAbstractFileByPath(dir)) {
      await this.app.vault.createFolder(dir).catch(() => {});
    }
    let ok = 0;
    const errors = [];
    for (const f of picked) {
      try {
        const buf = await f.arrayBuffer();
        await this.app.vault.createBinary(this._freeBookPath(dir, f.name), buf);
        ok++;
      } catch (err) {
        console.warn("Book Reader TTS: could not import", f && f.name, err);
        errors.push(f.name);
      }
    }
    if (ok) new Notice(__ertr("Books added: {0}", ok) + (rejected.length ? " · " + __ertr("skipped: {0}", rejected.length) : ""));
    if (errors.length) new Notice(__ertr("Could not add: {0}", errors.join(", ")));
    if (ok) this._refresh();
  }
  // Rebuild the library in place after books were added, without a modal flash.
  _refresh() {
    if (this._coverResizeObs) { try { this._coverResizeObs.disconnect(); } catch { /* optional step; a failure here must not interrupt reading */ } }
    this._disposeCollections?.();this._disposeCollections=null;
    this.contentEl.empty();
    this.onOpen();
  }
  _sizeCovers() {
    if (!this._grid) return;
    // The cover div gets its 2:3 box from CSS `aspect-ratio:2/3`. This is only a
    // FALLBACK: if a webview ever ignores aspect-ratio (height comes out far from
    // 2:3), pin an explicit px height; otherwise leave the CSS value alone so a
    // mis-timed early measurement can't squash a correct cover.
    this._grid.querySelectorAll(".er-lib-cover").forEach((c) => {
      const w = c.offsetWidth;
      if (!w) return;
      const h = c.offsetHeight;
      if (h < w * 1.35 || h > w * 1.65) c.style.setProperty("height", Math.round(w * 1.5) + "px", "important");
      else c.style.removeProperty("height");
    });
  }
  renderCard(grid, file) {
    let _a, _b;
    const prog = this.plugin.getProgress(file.path);
    const pct = (_a = prog == null ? void 0 : prog.percent) != null ? _a : 0;
    const card = grid.createDiv("er-lib-card");
    const cover = card.createDiv("er-lib-cover");
    const select=cover.createEl('input',{cls:'br-book-select',attr:{type:'checkbox','aria-label':__ertr('Select book: {0}',file.basename)}});
    select.checked=this._librarySelected?.has(file.path)||false;
    select.onclick=e=>e.stopPropagation();
    select.onchange=()=>{if(select.checked)this._librarySelected.add(file.path);else this._librarySelected.delete(file.path);this._updateLibrarySelection();};
    const fits = ((_b = this.plugin.settings.coverFits) != null ? _b : (this.plugin.settings.coverFits = {}));
    if (fits[file.path] === "fill") cover.addClass("er-fit-fill");
    const ph = cover.createDiv("er-lib-ph");
    ph.createDiv("er-lib-ph-ext").setText(file.extension.toUpperCase());
    ph.createDiv("er-lib-ph-init").setText(file.basename.slice(0, 2).toUpperCase());
    this.loadThumb(file, cover, ph);
    // Hover button: switch this cover between "\u0432\u043F\u0438\u0441\u0430\u0442\u044C" (whole cover visible,
    // contain) and "\u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C" (fill the box, cover). Applied as inline
    // background-size so it survives theme CSS.
    const fitBtn = cover.createDiv("er-lib-fitbtn");
    fitBtn.setAttribute("aria-label", __ertr("Cover fit"));
    const applyFit = () => {
      const fill = cover.hasClass("er-fit-fill");
      cover.style.setProperty("background-size", fill ? "cover" : "contain", "important");
      svgIcon(fitBtn, fill ? "cover-fit" : "cover-fill");
    };
    applyFit();
    fitBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const nowFill = !cover.hasClass("er-fit-fill");
      cover.toggleClass("er-fit-fill", nowFill);
      if (nowFill) fits[file.path] = "fill"; else delete fits[file.path];
      applyFit();
      this.plugin.saveAll();
    });
    if (pct > 0) {
      const s = cover.createDiv("er-lib-strip");
      s.createDiv("er-lib-strip-fill").style.width = `${pct}%`;
    }
    const info = card.createDiv("er-lib-info");
    info.createDiv("er-lib-book-title").setText(file.basename);
    const meta = info.createDiv("er-lib-book-meta");
    if (prog == null ? void 0 : prog.lastRead) {
      meta.setText(`${pct}% \xB7 ${new Date(prog.lastRead).toLocaleDateString(systemLocale(), { day: "numeric", month: "short" })}`);
    } else {
      meta.setText(__ertr("Not started"));
    }
    const readSeconds=this.plugin.settings.bookReadingSeconds?.[file.path]||0;
    if(readSeconds>0)info.createDiv({cls:'br-book-reading-time',text:__ertr('Read {0}',formatReadingTime(readSeconds))});
    const tagRow=info.createDiv('br-card-tags');
    for(const tag of bookTagsOf(this.plugin.settings,file.path)){
      const button=tagRow.createEl('button',{text:tag});button.onclick=async e=>{e.stopPropagation();this.plugin.settings.libCategory='tag:'+tag;this._librarySelected.clear();await this.plugin._saveLocalData();this._refresh();};
    }
    if(this.plugin.settings.bookArchives?.[file.path])info.createDiv({cls:'br-archive-badge',text:__ertr('Archived')});
    /* Provide explicit book actions on mobile, where no right mouse button exists. */
    const bookMenu = (e) => {
      e.preventDefault();
      e.stopPropagation();
      const menu = new Menu();
      /* Do not duplicate Read in the context menu; clicking the card already opens the book. */
      menu.addItem(it=>it.setTitle(__ertr('Add to bookshelves')).setIcon('tags').onClick(()=>openBookTags(this,[file.path])));
      const archived=!!this.plugin.settings.bookArchives?.[file.path];
      menu.addItem(it=>it.setTitle(archived?__ertr('Restore to shelf'):__ertr('Archive book')).setIcon(archived?'archive-restore':'archive').onClick(async()=>{setArchived(this.plugin.settings,[file.path],!archived);this._librarySelected.delete(file.path);await this.plugin._saveLocalData();this._refresh();}));
      menu.addSeparator();
      addBookFileMenu(this.app, menu, file);
      menu.addSeparator();
      menu.addItem((it) => it.setTitle(__ertr("Delete book")).setIcon("trash").onClick(() => {
        deleteBookFromVault(this.app, this.plugin, file, () => this._refresh());
      }));
      menu.showAtMouseEvent(e);
    };
    card.addEventListener("contextmenu", bookMenu);
    const moreBtn = info.createEl("button",{cls:"er-lib-morebtn",attr:{type:"button"}});
    moreBtn.setAttribute("aria-label", __ertr("Book actions"));
    moreBtn.setText("•••");
    moreBtn.addEventListener("click", bookMenu);
    card.addEventListener("click", () => {
      if(this._libraryEditing){select.checked=!select.checked;select.onchange();return;}
      this.close();
      this.plugin.openFile(file);
    });
  }
  async loadThumb(file, coverEl, ph) {
    /* Read custom cover metadata from cover or its legacy localized alias; accept URLs, vault paths and wiki links without caching so edits appear immediately. */
    const own = this.coverFromBookNote(file);
    if (own) { this.showImg(coverEl, ph, own); return; }
    // Cached cover → show immediately (this is the common path once generated).
    if (this.plugin.thumbCache[file.path]) {
      this.showImg(coverEl, ph, this.plugin.thumbCache[file.path]);
      return;
    }
    // Generate uncached covers ONE AT A TIME through a shared promise chain.
    // Firing a dozen `makePdfThumb`s at once (each loads a whole PDF — some are
    // 30–75 MB — and each used to call saveAll()) overloaded the single PDF
    // worker and raced a dozen concurrent data.json writes, which left the whole
    // library with blank covers when many books were added. Serialising fixes it.
    this._thumbQueue = (this._thumbQueue || Promise.resolve()).then(async () => {
      if (this.plugin.thumbCache[file.path]) { this.showImg(coverEl, ph, this.plugin.thumbCache[file.path]); return; }
      try {
        const url = file.extension === "pdf" ? await this.makePdfThumb(file)
          : file.extension === "fb2" ? await this.makeFb2Thumb(file)
          : await this.makeEpubThumb(file);
        if (!url) return;
        this.plugin.thumbCache[file.path] = url;
        this._thumbDirty = true;
        this.showImg(coverEl, ph, url);
      } catch (e) {
        console.warn("Book Reader TTS: cover failed for", file.path, e);
      }
    }).then(() => {
      // Persist once the chain goes idle (debounced), not after every single
      // cover — avoids racing/oversized writes to data.json.
      window.clearTimeout(this._thumbSaveT);
      this._thumbSaveT = window.setTimeout(() => { if (this._thumbDirty) { this._thumbDirty = false; this.plugin._saveThumbCache(); } }, 800);
    });
    return this._thumbQueue;
  }
  // The cover a reader chose in the book's note, or nothing.
  //
  // Three shapes are accepted, because all three are what people actually write
  // in frontmatter: a plain URL, a path to an image inside the vault, and a
  // [[wiki link]]. Anything that does not resolve simply falls through to the
  // cover embedded in the book — the point is to override it, never to break it.
  coverFromBookNote(file) {
    try {
      const name = bookNoteLinkFor(this.plugin, file);
      if (!name) return null;
      const note = resolveBookNote(this.app, name);
      if (!note) return null;
      const fm = this.app.metadataCache.getFileCache(note)?.frontmatter;
      if (!fm) return null;
      const raw = fm.cover ?? fm.\u043e\u0431\u043b\u043e\u0436\u043a\u0430 ?? fm.Cover ?? fm.\u041e\u0431\u043b\u043e\u0436\u043a\u0430;
      const val = String(Array.isArray(raw) ? raw[0] : (raw ?? "")).trim();
      if (!val) return null;
      if (/^https?:\/\//i.test(val)) return val;
      const inner = (val.match(/^!?\[\[([^\]|#]+)/) || [])[1] || val;
      const img = this.app.metadataCache.getFirstLinkpathDest(inner.trim(), note.path)
        || this.app.vault.getAbstractFileByPath(erPath(inner.trim()));
      return img instanceof TFile ? this.app.vault.getResourcePath(img) : null;
    } catch { return null; }
  }
  showImg(coverEl, ph, src) {
    if (!src) return;
    ph.addClass("er-hidden");
    // Paint the cover as the DIV's background-image (no <img> element). Themes
    // can't restyle a div's background the way they hijack `img`, so the cover
    // always fills the 2:3 box (height pinned in px by _sizeCovers). "background-
    // position:center top" keeps the title visible if the art is taller than 2:3.
    coverEl.style.setProperty("background-image", `url("${src.replace(/"/g, '\\"')}")`, "important");
    coverEl.addClass("er-cover-img");
    /* Contain shows the entire cover inside the 2:3 box, with letterboxing instead of cropping. */
    coverEl.style.setProperty("background-size", coverEl.hasClass("er-fit-fill") ? "cover" : "contain", "important");
    coverEl.addClass("er-has-cover");
  }
  async makePdfThumb(file) {
    await setupWorker(this.app);
    const buf = await this.app.vault.readBinary(file);
    const task = pdfjsLib.getDocument({
      data: buf,
      /* Disable PDF font evaluation to mitigate CVE-2024-4367. */
      isEvalSupported: false,
    });
    const doc = await task.promise;
    const page = await doc.getPage(1);
    // Render crisp (~520px wide), flattened onto white, capped so the cached
    // data-URL stays small. Old version used scale 0.5 \u2192 blurry thumbnails.
    const base = page.getViewport({ scale: 1 });
    const scale = Math.min(2.5, Math.max(1, 520 / (base.width || 400)));
    const vp = page.getViewport({ scale });
    const cv = document.createElement("canvas");
    cv.width = Math.ceil(vp.width);
    cv.height = Math.ceil(vp.height);
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, cv.width, cv.height);
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    const url = cv.toDataURL("image/jpeg", 0.85);
    /* Destroy the PDF loading task, not the document. Cleanup failures must not discard a successfully rendered cover. */
    try { await task.destroy(); } catch { /* optional step; a failure here must not interrupt reading */ }
    return url;
  }
  // FB2 keeps its cover as a base64 <binary>, so the "thumbnail" is already a
  // data URL — no rendering needed. Falls back to the first image in the file
  // when the description declares no coverpage.
  async makeFb2Thumb(file) {
    const buf = await this.app.vault.readBinary(file);
    const bytes = new Uint8Array(buf);
    if (bytes[0] === 0x50 && bytes[1] === 0x4B) throw new Error("fb2 is zipped");
    const doc = new DOMParser().parseFromString(decodeFb2(buf), "application/xml");
    const cp = doc.getElementsByTagName("coverpage")[0];
    const img = cp && cp.getElementsByTagName("image")[0];
    const id = img ? fb2Href(img) : "";
    const bins = Array.from(doc.getElementsByTagName("binary"));
    const bin = (id && bins.find((b) => b.getAttribute("id") === id)) || bins[0];
    if (!bin) throw new Error("no cover");
    const data = (bin.textContent || "").replace(/\s+/g, "");
    if (!data) throw new Error("no cover");
    return `data:${bin.getAttribute("content-type") || "image/jpeg"};base64,${data}`;
  }
  async makeEpubThumb(file) {
    const buf = await this.app.vault.readBinary(file);
    const book = ePub(buf);
    await book.ready;
    // Read the cover straight out of the unpacked EPUB.
    //
    // This used to go through book.coverUrl(), which hands back a blob: URL that
    // then had to be read with fetch(). Nothing left the device either way — the
    // blob was made from the file already in memory — but a fetch() sitting in a
    // plugin is a thing reviewers have to stop and check, and requestUrl() can't
    // read blob: URLs. Asking the archive directly removes the question: there is
    // no URL and no request, just the bytes epub.js already has.
    const coverPath = await book.loaded.cover;
    if (!coverPath) { book.destroy(); throw new Error("no cover"); }
    const archive = book.archive;
    if (!archive || typeof archive.getBase64 !== "function") {
      book.destroy();
      throw new Error("epub archive unavailable");
    }
    const dataUrl = await archive.getBase64(coverPath);
    book.destroy();
    if (!dataUrl) throw new Error("no cover");
    return dataUrl;
  }
  onClose() {
    this._disposeCollections?.();
    // Flush any covers generated this session before the library closes.
    window.clearTimeout(this._thumbSaveT);
    if (this._thumbDirty) { this._thumbDirty = false; this.plugin.saveAll(); }
    this._coverResizeObs?.disconnect();
    this.contentEl.empty();
  }
};
// ── Mobile full-screen reader modal ───────────────────────────────────────────
// ── Mobile full-screen reader modal (section-based, no CSS columns) ──────────
// The library as a TAB, not a dialog.
//
// A modal is capped by Obsidian's own sizing and cannot leave the main window.
// A leaf can: it docks, splits, resizes with the window, and — the thing that
// was actually asked for — Obsidian can move it into its own OS window, where
// it can be maximised like any other. Same code draws both: the drawing never
// cared whether it lived in a dialog, only that it had an element to draw into
// and a way to close itself.
const LIB_VIEW_TYPE = "book-reader-tts-library";
const LibraryView = class extends ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
  }
  getViewType() { return LIB_VIEW_TYPE; }
  getDisplayText() { return __ertr("Library"); }
  getIcon() { return "library"; }
  async onOpen() {
    // The two things the library's drawing expects from a dialog. `modalEl` is
    // only ever used as the host for the drag-and-drop overlay.
    this.modalEl = this.containerEl;
    this.containerEl.addClass("er-modal-lib", "er-lib-as-view");
    await LibraryModal.prototype.onOpen.call(this);
  }
  // Opening a book closes the library when it is a dialog; as a tab there is
  // nothing to close, and detaching would take the book's own tab with it on a
  // narrow layout. Staying open is also simply more useful here.
  close() { /* a tab stays put */ }
  onClose() {
    this._disposeCollections?.();
    if (this._coverResizeObs) { try { this._coverResizeObs.disconnect(); } catch { /* already gone */ } }
    this.contentEl.empty();
  }
};
// Everything the library draws lives on LibraryModal's prototype. Borrow it
// wholesale rather than duplicating 500 lines that would then drift apart.
for (const name of Object.getOwnPropertyNames(LibraryModal.prototype)) {
  if (["constructor", "onOpen", "onClose", "close"].includes(name)) continue;
  Object.defineProperty(LibraryView.prototype, name,
    Object.getOwnPropertyDescriptor(LibraryModal.prototype, name));
}
const ReaderModal = class extends Modal {
  constructor(app, plugin, file) {
    super(app);
    this.plugin  = plugin;
    this.file    = file;
    this.ext     = file.extension === "epub" ? "epub" : file.extension === "fb2" ? "fb2" : "pdf";
    // Mobile now uses the SAME horizontal page engine as the desktop view, so
    // you turn pages by swiping left/right (like a real book) instead of
    // scrolling down a long chapter.
    this.pager   = new Paginator();
    this.pager.onSpreadChange = (cur, tot) => {
      (this.updateUI || this._updateUI).call(this, cur, tot);
      if (this.file) this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
    };
    this.bookHtml = "";
    this.tocItems = [];
    this.panelOpen = null;
    this._pendingSel = null;
    this._editHlId = null;
  }
  async onOpen() {
    const { modalEl, contentEl } = this;
    // Let commands find the open mobile reader — it is a Modal, so it never
    // appears in getActiveViewOfType().
    this.plugin._openReaderModal = this;
    // Don't let Esc close the reader: it was yanking you out of the whole book
    // when you only meant to dismiss a zoomed image. Remove Obsidian's built-in
    // Esc→close handler from this modal's scope; the book is closed with the ←
    // button instead, and the image viewer is closed by ✕ / tapping outside.
    try {
      if (this.scope && Array.isArray(this.scope.keys)) {
        this.scope.keys = this.scope.keys.filter((k) => String(k && k.key).toLowerCase() !== "escape");
      }
    } catch { /* optional step; a failure here must not interrupt reading */ }
    modalEl.addClass("er-fullscreen-modal");
    // Also on the container: the mobile build gives it padding of its own, which
    // showed as grey bands down both sides of the book (8px, measured off the
    // screen). Only a rule aimed at the container can take that back.
    this.containerEl.addClass("er-fullscreen-container");
    contentEl.addClass("er-fullscreen-content");
    /* Allow a manual status-bar inset for Android devices that report zero; zero preserves automatic behavior. */
    const extraTop = Number(this.plugin.settings.mobileTopInset) || 0;
    if (extraTop > 0) contentEl.style.setProperty("--er-extra-top", extraTop + "px");
    /* Remove only this reader dialog's duplicate close controls, including newer modal-header-button and legacy modal-close-button variants. Observe late additions while preserving close buttons in other dialogs. */
    const CLOSE_BTNS = ".modal-close-button, .modal-header-button";
    const dropStrayCloses = (all) => {
      try {
        for (const b of docOf(modalEl).querySelectorAll(CLOSE_BTNS)) {
          const own = b.closest(".modal-container");
          // `all` is the sweep at open: the book is the only dialog on screen at
          // that instant, so everything goes. The previous version kept the ones
          // whose container was not the node we knew about — which is exactly the
          // case that survives if the mobile build nests the dialog differently,
          // and it did survive. Afterwards the rule tightens again.
          if (all || !own || own === this.containerEl) b.remove();
        }
      } catch { /* nothing to remove is a perfectly good outcome */ }
    };
    dropStrayCloses(true);
    // Wrapped, not passed straight in: a MutationObserver hands its callback the
    // list of records, which is truthy — the sweep-everything flag would have
    // been on for every mutation, and other dialogs would lose their ✕ too.
    this._closeWatch = new MutationObserver(() => dropStrayCloses(false));
    this._closeWatch.observe(docOf(modalEl).body, { childList: true, subtree: true });
    this._applyTheme();
    this._buildDOM();
    await this._loadBook();
    this._sessionSec = 0;
    this._running = false;
    if(this.pager)startTimerSession(this);
    updateTimerBtn(this);
    // Re-flow the pages when the viewport changes (e.g. phone rotation, keyboard).
    this._lastW = this.areaEl.clientWidth;
    this._resizeObs = new ResizeObserver(() => {
      window.clearTimeout(this._rsT);
      this._rsT = window.setTimeout(() => {
        // Rotation changes the strip (an iPhone has none in landscape). Settle it
        // first, then decide about re-flowing — the strip is part of the height
        // the columns are measured against.
        // (the status bar strip is pure CSS now — nothing to re-measure)
        const w = this.areaEl ? this.areaEl.clientWidth : 0;
        if (w && Math.abs(w - (this._lastW || 0)) > 4) { this._lastW = w; this._repaginate(); }
      }, 180);
    });
    this._resizeObs.observe(this.areaEl);
  }
  _applyTheme() {
    const t = erTheme(this.plugin.settings);
    const m = this.modalEl;
    m.style.setProperty("--er-bg", t.bg);
    m.style.setProperty("--er-text", t.text);
    m.style.setProperty("--er-ui", t.ui);
    m.style.setProperty("--er-border", t.border);
    m.style.setProperty("--er-accent", t.accent);
    m.style.setProperty("--er-muted", t.muted);
    m.style.background = t.bg;
  }
  _buildDOM() {
    const root = this.contentEl;
    root.empty();
    const pb = root.createDiv("er-pbar");
    this.pbarFill = pb.createDiv("er-pbar-fill");
    const top = root.createDiv("er-top");
    mountSpeech(this, root, top); mountReadingControls(this, root, top);
    const lb  = top.createDiv("er-ibtn");
    svgIcon(lb, "arrow-left");
    lb.setAttribute("aria-label", __ertr("Close the book"));
    lb.addEventListener("click", () => this.close());
    this.titleEl = top.createDiv("er-top-title");
    this.titleEl.setText(this.file.basename);
    const tr     = top.createDiv("er-top-right");
    /* Move secondary mobile toolbar actions into an overflow menu so the title has room. */
    const moreBtn = tr.createDiv("er-ibtn er-b-more");
    svgIcon(moreBtn, "more-horizontal");
    moreBtn.setAttribute("aria-label", __ertr("More"));
    moreBtn.addEventListener("click", (e) => {
      const menu = new Menu();
      menu.addItem((it) => it.setTitle(__ertr("Search the book")).setIcon("search").onClick(() => {
        this._togglePanel("find");
        if (this._findInput) erAutoFocus(this._findInput, 80);
      }));
      menu.addItem((it) => it.setTitle(__ertr("Table of contents")).setIcon("list").onClick(() => this._togglePanel("toc")));
      menu.addItem((it) => it.setTitle(__ertr("Highlights")).setIcon("highlighter").onClick(() => this._togglePanel("highlights")));
      menu.addItem((it) => it.setTitle(__ertr("Save position")).setIcon("save").onClick(() => this.saveNow()));
      /* Offer manual reflow on mobile for layout recovery when reopening does not help. */
      menu.addItem((it) => it.setTitle(__ertr("Re-flow the book")).setIcon("refresh-cw").onClick(async () => {
        await this._repaginate();
        new Notice(__ertr("The book has been re-flowed"));
      }));
      menu.addItem((it) => it.setTitle(__ertr("Reading settings")).setIcon("sliders").onClick(() => new ReadSettingsModal(this.app, this).open()));
      addBookFileMenu(this.app, menu, this.file);
      menu.addSeparator();
      menu.addItem((it) => it.setTitle(__ertr("Close the book")).setIcon("x").onClick(() => this.close()));
      menu.showAtMouseEvent(e);
    });
    /* Keep one back action; place help in settings and less frequent actions in the overflow menu. */
    this.areaEl = root.createDiv("er-area er-marea");
    if ((this.plugin.settings.navMode || "buttons") === "click") root.addClass("er-navclick");
    // Bottom reading-goal progress bar removed by request; the ▶ timer stays in the top bar.
    const bot = root.createDiv("er-bot");
    const pv  = bot.createDiv("er-navbtn");
    svgIcon(pv, "chevron-left");
    pv.addEventListener("click", () => this._nav("prev"));
    const center = bot.createDiv("er-bot-center");
    this.locEl = center.createDiv("er-loc er-loc-clickable");
    this.locEl.setAttribute("aria-label", __ertr("Go to page"));
    this.locEl.addEventListener("click", () => {
      if (!this.file || !this.pager || !this.pager.total) return;
      new GoToPageModal(this.app, this.pager.total, this.pager.spread, (n) => {
        const [cur, tot] = this.pager.jumpTo(n - 1);
        this._updateUI(cur, tot);
        this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
      }).open();
    });
    this.pctEl = center.createDiv("er-pct");
    this.pctEl.setText("0%");
    mountReadingProgress(this, bot,()=>toggleTimerSession(this));
    const nx = bot.createDiv("er-navbtn");
    svgIcon(nx, "chevron-right");
    nx.addEventListener("click", () => this._nav("next"));
    this.overlayEl = root.createDiv("er-overlay");
    this.overlayEl.addEventListener("click", () => this._closePanel());
    this.settPan = root.createDiv("er-panel");
    this.tocPan  = root.createDiv("er-panel er-toc-panel");
    this.hlPan   = root.createDiv("er-panel er-toc-panel er-hl-panel");
    this.findPan = root.createDiv("er-panel er-toc-panel er-find-panel");
    this._buildSettPanel();
    this._buildTocPanel();
    this._buildHlPanel();
    this._buildFindPanel();
    this.hlPopup = root.createDiv("er-hl-popup");
    this._buildHlPopup();
    this._selHandler = () => this._scheduleSelCheck();
    this._selDoc = docOf(this.areaEl);
    this._selDoc.addEventListener("selectionchange", this._selHandler);
    this.areaEl.addEventListener("click", (e) => {
      // A footnote reference wins over everything else on the page: the reader
      // tapped a number, not the paragraph behind it.
      const refEl = e.target instanceof HTMLElement ? e.target.closest("[data-er-ref]") : null;
      if (refEl) {
        e.preventDefault();
        e.stopPropagation();
        if (followFootnote(this, refEl.getAttribute("data-er-ref"))) return;
      }
      const imgEl = e.target instanceof HTMLElement ? e.target.closest("img") : null;
      if (imgEl && imgEl.src) { e.preventDefault(); openImageLightbox(imgEl.currentSrc || imgEl.src, this.app, imgEl); return; }
      const span = e.target instanceof HTMLElement ? e.target.closest(".er-hl") : null;
      if (span) { e.preventDefault(); this._openHlEdit(span.getAttribute("data-hl-id")); }
      else if (this._editHlId) this._hideHlPopup();
    });
    // Horizontal swipe = turn page. A long-press (start a selection) or an active
    // selection must NOT be hijacked, so the user can still select text.
    let sx = 0, sy = 0, dir = null, longPress = false, lpTimer = null, hadSel = false;
    this.areaEl.addEventListener("touchstart", e => {
      if (e.touches.length > 1) { dir = "v"; return; }
      sx = e.touches[0].clientX; sy = e.touches[0].clientY; dir = null; longPress = false;
      const sel = selOf(this.areaEl);
      hadSel = !!(sel && !sel.isCollapsed);
      window.clearTimeout(lpTimer);
      lpTimer = window.setTimeout(() => { longPress = true; }, 350);
    }, { passive: true });
    this.areaEl.addEventListener("touchmove", e => {
      if (dir) { if (dir === "h") e.preventDefault(); return; }
      const dx = Math.abs(e.touches[0].clientX - sx), dy = Math.abs(e.touches[0].clientY - sy);
      if (dx < 8 && dy < 8) return;
      window.clearTimeout(lpTimer);
      const sel = selOf(this.areaEl);
      if (longPress || hadSel || (sel && !sel.isCollapsed)) { dir = "v"; return; }
      dir = dx > dy ? "h" : "v";
      if (dir === "h") e.preventDefault();
    }, { passive: false });
    this.areaEl.addEventListener("touchend", e => {
      window.clearTimeout(lpTimer);
      if (dir !== "h") return;
      const dx = e.changedTouches[0].clientX - sx;
      if (Math.abs(dx) > 44) this._nav(dx < 0 ? "next" : "prev");
    }, { passive: true });
    /* Turn pages by tapping their left or right side when click navigation is enabled. */
    this.areaEl.addEventListener("click", (e) => handleAreaNavClick(this, e));
    // Immersive chrome, on the phone as well.
    //
    // The setting promises the bars dim out of the way while you read, and on a
    // phone it did nothing at all: the desktop arms it from `pointermove`, and a
    // finger does not move a pointer. A touch is what wakes it here — and the
    // whole point of a phone reader is that the book is the screen.
    const armImmersive = () => {
      const root = this.contentEl;
      if (!root) return;
      if (!this.plugin.settings.immersive) { root.removeClass("er-immersive"); return; }
      root.removeClass("er-immersive");
      window.clearTimeout(this._immTimer);
      this._immTimer = window.setTimeout(() => {
        if (this.bookHtml && this.contentEl) this.contentEl.addClass("er-immersive");
      }, 2600);
    };
    this._armImmersive = armImmersive;
    this.contentEl.addEventListener("touchstart", armImmersive, { passive: true });
    this.contentEl.addEventListener("pointerdown", armImmersive);
    armImmersive();
  }
  // Settings changes (theme/font/size/line-height) → rebuild the pages, keeping
  // the current reading %. (Named _applyContentStyle for the panel callers.)
  async _applyContentStyle() {
    await this._repaginate();
  }
  async _repaginate(anchor = null) {
    if (!this.bookHtml || !this.areaEl || !this.areaEl.clientWidth) return;
    // Anchor on the paragraph, not the percentage — see the desktop repaginate().
    // Here it matters on font-size changes and screen rotation.
    const savedBlock = Number.isInteger(anchor) ? anchor : this.pager.currentBlockIndex();
    const savedPct = this.pager.currentPct;
    // Re-flowing necessarily lays the book out from spread 0 before it can jump
    // back to where the reader was. Unhidden, that is a page they can see change
    // twice — the same flicker the opening sequence hides for the same reason.
    this.areaEl.addClass("er-booting");
    erShowVeil(this);
    const [, total] = await this.pager.build(this.areaEl, this.bookHtml, this.plugin.settings, 0);
    const target = (typeof savedBlock === "number" && savedBlock >= 0)
      ? this.pager.spreadForBlock(savedBlock)
      : Math.round(savedPct * Math.max(0, total - 1));
    this._renderFlowHighlights();
    this.pager.jumpTo(target);
    const [cur, tot] = this.pager.restoreBlockPosition(savedBlock);
    erRevealWhenSettled(this);
    this._updateUI(cur, tot);
    // Everything below is tied to the block elements that were just replaced:
    // the spread numbers in the contents list, the search corpus, and the
    // highlight ranges painted over the old nodes.
    if (this._tocRender) this._tocRender();
    this._findCorpus = null;
    if (this._foundQuery) this._markFound(this._foundQuery);
  }
  async _loadBook() {
    this.areaEl.empty();
    const loading = this.areaEl.createDiv("er-loading");
    loading.addClass("er-centered");
    loading.createDiv("er-spin");
    const loadText = loading.createDiv("er-loading-text");
    loadText.setText(__ertr("Loading the book…"));
    await new Promise((r) => window.requestAnimationFrame(r));
    await new Promise((r) => window.requestAnimationFrame(r));
    try {
      this._pdfLazy?.destroy?.();
      this._pdfLazy = null;
      if (this.ext === "epub") {
        this.bookHtml = await extractEpub(this.file, this.app);
      } else if (this.ext === "fb2") {
        this.bookHtml = await extractFb2(this.file, this.app);
      } else {
        const res = await extractPdf(this.file, this.app, this.plugin.settings, (i, n) => loadText.setText(__ertr("Preparing the book… {0}%", (Math.round(i / n * 100)))));
        this.bookHtml = res.html;
        this._pdfLazy = res.lazy;
        this._pdfOutline = res.outline;
      }
      // TOC anchored to the global block index \u2192 tap jumps to that page.
      this.tocItems = buildTocItems(this.bookHtml, this._pdfOutline);
      this._buildTocPanel();
      await this.plugin.refreshHighlights();
      await this.plugin.refreshProgress();
      const saved = this.plugin.getProgress(this.file.path);
      if(saved?.pct>0&&this.plugin.readerSync?.remotePositions.delete(this.file.path))new Notice(__ertr('Continuing from synced reading position: {0}%',saved.percent));
      const pct = (saved == null ? void 0 : saved.pct) != null ? saved.pct : 0;
      this.areaEl.addClass("er-booting");
      erShowVeil(this);
      // Ceiling on the hold. If anything between here and the jump throws, the
      // book must still appear — a blank page is far worse than a visible jump.
      window.setTimeout(() => {
        if (this.areaEl) this.areaEl.removeClass("er-booting");
        erHideVeil(this);
      }, 3000);
      await this.pager.build(this.areaEl, this.bookHtml, this.plugin.settings, 0);
      const hasBlock = saved && typeof saved.block === "number" && saved.block >= 0;
      const target = hasBlock
        ? this.pager.spreadForBlock(saved.block)
        : Math.round(pct * Math.max(0, this.pager.total - 1));
      this._renderFlowHighlights();
      const [cur, tot] = this.pager.jumpTo(target);
      this._updateUI(cur, tot);
      // Not one frame — the dialog can still be settling on a phone, and a
      // re-flow landing after the reveal is a page the reader watches change.
      erRevealWhenSettled(this);
      if (hasBlock) this._flashBlock(saved.block);
      // Same as desktop: the panel was built before a file existed, so rebuild it
      // now that the per-book settings have a book to bind to.
      this._buildSettPanel();
      // First open of this book → offer to set up its note. Mobile never asked
      // at all before, so a phone-only reader had no way into this.
      this._maybePromptBookNote(this.file);
    } catch (e) {
      console.error("ReaderModal:", e);
      this.areaEl.empty();
      this.areaEl.createEl("p", { cls: "er-load-error", text: __ertr("Error: {0}", e.message) });
    }
  }
  // First open of a book \u2192 the setup screen (create / pick / skip). Same rules as
  // the desktop view: never for a book that already has a note, never twice.
  _maybePromptBookNote(file) {
    const s = this.plugin.settings;
    if (!file) return;
    if (!s.bookNoteLinks) s.bookNoteLinks = {};
    if (!s.bookNotePrompted) s.bookNotePrompted = {};
    const action = bookNoteAction(s, file.path);
    if (action === "linked" || action === "prompted" || action === "quiet") return;
    if (action === "auto") {
      s.bookNotePrompted[file.path] = true;
      this.plugin.ensureBookNote(file).then((note) => {
        if (note) new Notice(__ertr("Book note created: {0}", note.basename));
      });
      return;
    }
    new BookSetupModal(this.app, this.plugin, file, () => {}).open();
  }
  // Jump to the page holding a global block index, flash it, save the position.
  _jumpToBlock(block, flash = true) {
    if (!this.bookHtml) return;
    const [cur, tot] = this.pager.jumpTo(this.pager.spreadForBlock(block));
    this._updateUI(cur, tot);
    if (this.file) this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
    if (flash) this._flashBlock(block);
  }
  // Briefly highlight the paragraph the reader resumed at.
  // Jump to a paragraph as soon as the book is laid out. Called from a backlink,
  // which arrives while the book is still being built, so it waits for the
  // pager rather than assuming the text is already there. Gives up after a few
  // seconds instead of polling forever on a book that failed to open.
  // Land on a PDF page once the book is laid out. Pages are marked in the flow
  // with data-pdf-page-no, so this is a lookup rather than a guess.
  jumpToPdfPageWhenReady(pageNo) {
    let tries = 0;
    const tick = () => {
      const flow = this.pager && this.pager.flow;
      if (flow && this.pager.total) {
        const el = flow.querySelector(`[data-pdf-page-no="${pageNo}"]`);
        if (el) {
          const x = el.getBoundingClientRect().left - flow.getBoundingClientRect().left;
          const stride = this.pager.sw / (this.pager.cols || 1);
          const spread = Math.floor(Math.round(x / stride) / (this.pager.cols || 1));
          const [cur, tot] = this.pager.jumpTo(Math.max(0, Math.min(spread, this.pager.total - 1)));
          (this.updateUI || this._updateUI).call(this, cur, tot);
          return;
        }
      }
      if (++tries > 40) return;
      window.setTimeout(tick, 100);
    };
    tick();
  }
  jumpToBlockWhenReady(idx) {
    let tries = 0;
    const tick = () => {
      if (this.pager && this.pager.flow && this.pager.total) {
        const [cur, tot] = this.pager.jumpTo(this.pager.spreadForBlock(idx));
        (this.updateUI || this._updateUI).call(this, cur, tot);
        this._flashBlock(idx);
        return;
      }
      if (++tries > 40) return;
      window.setTimeout(tick, 100);
    };
    tick();
  }
  _flashBlock(idx) {
    const el = this.pager.blockEl(idx);
    if (!el) return;
    el.classList.remove("er-resume-flash");
    void el.offsetWidth;
    el.classList.add("er-resume-flash");
    window.setTimeout(() => el.classList.remove("er-resume-flash"), 2400);
  }
  _nav(dir) {
    if (!this.bookHtml) return;
    // Anti-double-turn guard — see ReaderView.nav() for the full rationale.
    // Collapses the iOS ghost-click / duplicate touch that flips two pages per swipe.
    const _now = Date.now();
    if (this._lastNavTs && _now - this._lastNavTs < 90) return;
    this._lastNavTs = _now;
    this._lastActive = _now;
    this._hideHlPopup();
    const [cur, total] = dir === "next" ? this.pager.next() : this.pager.prev();
    this._updateUI(cur, total);
    this.plugin.saveProgress(this.file.path, cur, total, this.pager.currentBlockIndex());
  }
  saveNow() {
    if (!this.bookHtml || !this.file) { new Notice(__ertr("Nothing to save")); return; }
    const pct = this.plugin.saveNow(this.file.path, this.pager.spread, this.pager.total, this.pager.currentBlockIndex());
    new Notice(__ertr("Saved ✓ — {0}%", (pct)));
    if (this.panelOpen === "settings") this._renderHistory();
  }
  exportHighlights(evt) {
    if (!this.file) { new Notice(__ertr("No book is open")); return; }
    // Chapter + page are computed from the CURRENT layout, so they are attached
    // here rather than stored with the highlight.
    const list = enrichHighlights(this, this.plugin.getHighlights(this.file.path));
    exportHighlightsMenu(this.app, this.plugin, this.file, list, evt);
  }
  _updateUI(cur, total) {
    if (this.contentEl) this.contentEl.toggleClass("er-scrolling", !!(this.pager && this.pager.scrollMode));
    cur = cur != null ? cur : this.pager.spread;
    total = total != null ? total : this.pager.total;
    const pct = total > 0 ? Math.round((cur + 1) / total * 100) : 0;
    this.pbarFill.style.width = `${pct}%`;
    const bookPage = currentBookPage(this);
    this.locEl.setText(bookPage ? __ertr("p. {0}", bookPage) + " · " + `${cur + 1} / ${total}` : `${cur + 1} / ${total}`);
    this.pctEl.setText(`${pct}%`);
    this._readingProgress?.update(cur,total);
    renderVisibleFigures(this);
  }
  _buildSettPanel() {
    const p = this.settPan;
    p.empty();
    p.createDiv("er-pan-title").setText(__ertr("Settings"));
    const sec = l => p.createDiv("er-pan-sec").setText(l);
    sec(__ertr("Theme"));
    const thRow = p.createDiv("er-theme-row");
    ["auto","dark","light","sepia","eink"].forEach(t => {
      const btn = thRow.createDiv(`er-theme-btn er-theme-${t}`);
      btn.setText({ auto:__ertr("Match Obsidian"), dark:__ertr("Dark"), light:__ertr("Light"), sepia:"Sepia", eink:"E-ink" }[t]);
      if (this.plugin.settings.theme === t) btn.addClass("active");
      btn.addEventListener("click", async () => {
        this.plugin.settings.theme = t;
        await this.plugin.saveAll();
        /* Apply theme colors without rebuilding the book. */
        this._applyTheme();
        thRow.querySelectorAll(".er-theme-btn").forEach(b => b.removeClass("active"));
        btn.addClass("active");
      });
    });
    sec(__ertr("Font size"));
    const szRow = p.createDiv("er-sz-row");
    const szMinus = szRow.createDiv("er-sz-btn"); szMinus.setText("A\u2212");
    this.szLabel = szRow.createDiv("er-sz-label");
    this.szLabel.setText(`${this.plugin.settings.fontSize}px`);
    const szPlus = szRow.createDiv("er-sz-btn"); szPlus.setText("A+");
    const chSz = async d => {
      this.plugin.settings.fontSize = Math.min(32, Math.max(12, this.plugin.settings.fontSize + d));
      this.szLabel.setText(`${this.plugin.settings.fontSize}px`);
      await this.plugin.saveAll();
      this._applyContentStyle();
    };
    szMinus.addEventListener("click", () => chSz(-1));
    szPlus.addEventListener("click",  () => chSz(+1));
    // Progressive disclosure: theme and text size are what readers actually
    // touch mid-book; the rest is set once and then forgotten. One toggle, one
    // level deep — nesting further is where options stop being findable.
    const advHdr = p.createDiv("er-pan-adv-hdr");
    advHdr.createSpan({ cls: "er-pan-adv-ic", text: "\u2699\uFE0F" });
    advHdr.createSpan({ cls: "er-pan-adv-lbl", text: __ertr("More settings") });
    const advCar = advHdr.createSpan({ cls: "er-pan-adv-car", text: "\u203A" });
    const advWrap = p.createDiv("er-pan-adv");
    const adv = advWrap.createDiv("er-pan-adv-body");
    const secA = (l) => adv.createDiv("er-pan-sec").setText(l);
    if (this.plugin.settings.readerAdvOpen) { advWrap.addClass("er-pan-adv-on"); advCar.addClass("er-pan-adv-car-on"); }
    advHdr.addEventListener("click", async () => {
      const on = advWrap.hasClass("er-pan-adv-on");
      advWrap.toggleClass("er-pan-adv-on", !on);
      advCar.toggleClass("er-pan-adv-car-on", !on);
      this.plugin.settings.readerAdvOpen = !on;
      await this.plugin._saveLocalData();
    });
    secA(__ertr("Font"));
    const ffRow = adv.createDiv("er-ff-row");
    Object.keys(FONTS).forEach(ff => {
      const btn = ffRow.createDiv("er-ff-btn");
      btn.setText(ff); btn.style.fontFamily = FONTS[ff];
      if (this.plugin.settings.fontFamily === ff) btn.addClass("active");
      btn.addEventListener("click", async () => {
        this.plugin.settings.fontFamily = ff;
        await this.plugin.saveAll();
        this._applyContentStyle();
        ffRow.querySelectorAll(".er-ff-btn").forEach(b => b.removeClass("active"));
        btn.addClass("active");
      });
    });
    secA(__ertr("Line spacing"));
    const lhRow = adv.createDiv("er-lh-row");
    [1.4,1.6,1.8,2.1].forEach(lh => {
      const btn = lhRow.createDiv("er-lh-btn");
      btn.setText(`${lh}`);
      if (Math.abs(this.plugin.settings.lineHeight - lh) < 0.05) btn.addClass("active");
      btn.addEventListener("click", async () => {
        this.plugin.settings.lineHeight = lh;
        await this.plugin.saveAll();
        this._applyContentStyle();
        lhRow.querySelectorAll(".er-lh-btn").forEach(b => b.removeClass("active"));
        btn.addClass("active");
      });
    });
    buildReaderExtraSettings(this, adv);
    this._histRow = panelSection(this, p, {
      label: __ertr("Jump back"), emoji: "🔖", settingKey: "readerHistOpen",
    }).createDiv("er-hist-row");
    this._renderHistory();
    p.createDiv("er-pan-sec").setText(__ertr("Actions"));
    const actRow = p.createDiv("er-act-row");
    const actBtn = actRow.createDiv("er-act-btn");
    iconLabel(actBtn, "info", __ertr("Help"));
    actBtn.addEventListener("click", () => { this._closePanel(); new InfoModal(this.app, this.plugin, this.file).open(); });
  }
  _renderHistory() {
    const c = this._histRow;
    if (!c) return;
    c.empty();
    const list = this.file ? this.plugin.getBackups(this.file.path) : [];
    // Keep the collapsed header's counter in step with the list inside it.
    const badge = c.parentElement && c.parentElement._erCount;
    if (badge) badge.setText(list.length ? String(list.length) : "");
    if (!list.length) { c.createDiv("er-hist-empty").setText(__ertr("No points yet")); return; }
    [...list].reverse().slice(0, 14).forEach((snap) => {
      const chip = c.createDiv("er-hist-chip");
      if (snap.manual) chip.addClass("er-hist-manual");
      const d = new Date(snap.ts || snap.lastRead || Date.now());
      const mark = snap.manual ? "💾 " : "";
      chip.setText(`${mark}${snap.percent}% · ${d.toLocaleString(systemLocale(), { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}`);
      chip.addEventListener("click", () => {
        if (!this.bookHtml) return;
        this._closePanel();
        if (typeof snap.block === "number" && snap.block >= 0) {
          this._jumpToBlock(snap.block);
        } else {
          const frac = typeof snap.pct === "number" ? snap.pct : (snap.percent || 0) / 100;
          const [cur, tot] = this.pager.jumpTo(Math.round(frac * Math.max(0, this.pager.total - 1)));
          this._updateUI(cur, tot);
          if (this.file) this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
        }
        new Notice(__ertr("Jumped back to {0}%", (snap.percent)));
      });
    });
  }
  _buildTocPanel() {
    this._tocRender = buildTocPanelFor(this, this.tocPan, {
      close: () => this._closePanel(),
      jump: (b) => this._jumpToBlock(b),
    });
  }
  _buildFindPanel() {
    buildFindPanelFor(this, this.findPan, {
      close: () => this._closePanel(),
      jump: (b) => this._jumpToBlock(b),
    });
  }
  _markFound(query) { markFoundIn(this, query); }
  _clearFound() { clearFoundIn(this); }
  _togglePanel(name) {
    if (this.panelOpen === name) { this._closePanel(); return; }
    this._hideHlPopup();
    if (name === "highlights") this._buildHlPanel();
    if (name === "settings") this._renderHistory();
    this.panelOpen = name;
    this.settPan.classList.toggle("er-panel-open", name === "settings");
    this.tocPan.classList.toggle("er-panel-open", name === "toc");
    this.hlPan.classList.toggle("er-panel-open", name === "highlights");
    this.overlayEl.classList.add("er-overlay-on");
  }
  _closePanel() {
    this.panelOpen = null;
    this.settPan.classList.remove("er-panel-open");
    this.tocPan.classList.remove("er-panel-open");
    this.hlPan.classList.remove("er-panel-open");
    // Guarded: the mobile reader has no search panel.
    if (this.findPan) this.findPan.classList.remove("er-panel-open");
    this.overlayEl.classList.remove("er-overlay-on");
  }
  // ── Highlights (mobile) ───────────────────────────────
  // Now identical to the desktop flow model: highlights are addressed by the
  // GLOBAL block index inside the single paginated flow (no per-section offset).
  _renderFlowHighlights() {
    if (!this.file || !this.pager.flow) return;
    unwrapAllHighlights(this.pager.flow);
    const blocks = this.pager.flow.querySelectorAll("p,h1,h2,h3,h4");
    const list = this.plugin.getHighlights(this.file.path);
    for (const hl of list) {
      const block = blocks[hl.block];
      if (!block) continue;
      const text = block.textContent;
      const loc = locateHl(text, hl);
      if (!loc) continue;
      wrapBlockRange(block, loc.start, loc.start + loc.len, { id: hl.id, color: hlColorCss(hl.color) });
    }
  }
  _scheduleSelCheck() {
    window.clearTimeout(this._selTimer);
    this._selTimer = window.setTimeout(() => this._onSelectionCheck(), 80);
  }
  _onSelectionCheck() {
    if (this._editHlId) return;
    const sel = selOf(this.areaEl);
    if (!sel || sel.isCollapsed || sel.rangeCount === 0) { this._hideHlPopup(); return; }
    const range = sel.getRangeAt(0);
    const flow = this.pager.flow;
    if (!flow || !flow.contains(range.startContainer)) { this._hideHlPopup(); return; }
    let node = range.startContainer;
    if (node.nodeType === Node.TEXT_NODE) node = node.parentElement;
    const block = node ? node.closest("p,h1,h2,h3,h4") : null;
    if (!block || !flow.contains(block)) { this._hideHlPopup(); return; }
    const blocks = [...flow.querySelectorAll("p,h1,h2,h3,h4")];
    const blockIndex = blocks.indexOf(block);
    if (blockIndex < 0) { this._hideHlPopup(); return; }
    // A selection can cross paragraphs, and it used to be cut off at the end of
    // the first one: dragging across three paragraphs coloured one and threw the
    // rest away. Each paragraph the range touches becomes its own segment — a
    // highlight is anchored to a block, so a multi-paragraph highlight is simply
    // several of them sharing a colour.
    const parts = [];
    for (let bi = blockIndex; bi < blocks.length; bi++) {
      const b = blocks[bi];
      if (bi > blockIndex && !range.intersectsNode(b)) break;
      const bText = b.textContent;
      const from = bi === blockIndex ? offsetInBlock(b, range.startContainer, range.startOffset) : 0;
      const ends = b.contains(range.endContainer);
      const to = ends ? offsetInBlock(b, range.endContainer, range.endOffset) : bText.length;
      if (to > from) {
        const seg = bText.slice(from, to);
        if (seg.trim()) {
          parts.push({
            block: bi,
            occ: countOccurrencesBefore(bText, seg, from),
            text: seg,
            pre: bText.slice(Math.max(0, from - 32), from),
            post: bText.slice(to, to + 32),
          });
        }
      }
      if (ends) break;
    }
    if (!parts.length) { this._hideHlPopup(); return; }
    // The first segment stays the head, so everything that reads _pendingSel
    // (comments, notes, the translator) keeps working unchanged; the rest ride
    // along in `parts`, and only the colouring walks them.
    this._pendingSel = { ...parts[0], parts, text: parts.map((p) => p.text).join(" ") };
    erPaintSelection(this, range);
    this._showHlPopup(erSelectionRect(range, this.areaEl));
  }
  _buildHlPopup() {
    const pop = this.hlPopup;
    pop.empty();
    pop.addEventListener("mousedown", (e) => e.preventDefault());
    // A thought in the margin. Distinct from "create a note": this stays WITH the
    // highlight instead of becoming a separate file — for "he contradicts himself
    // here", which does not deserve its own note.
    addBarButtons(this, pop);
    addMoreBtn(this, pop);
  }
  _applyPopupColor(colorId) {
    if (this._editHlId && this.file) {
      const id = this._editHlId;
      this.plugin.setHighlightColor(this.file.path, id, colorId);
      this.pager.flow?.querySelectorAll(`[data-hl-id="${id}"]`).forEach((s) => { s.style.background = hlColorCss(colorId); });
      if (this.panelOpen === "highlights") this._buildHlPanel();
      this._hideHlPopup();
      return;
    }
    if (this._pendingSel && this.file) {
      // One highlight per paragraph the selection covered.
      const parts = this._pendingSel.parts || [this._pendingSel];
      for (const part of parts) this._createHighlight(part, colorId);
      selOf(this.areaEl)?.removeAllRanges();
      if (this.panelOpen === "highlights") this._buildHlPanel();
    }
    this._hideHlPopup();
  }
  // Same as in the desktop reader: needed so a comment can create the highlight
  // it hangs on. Returns the new id.
  _createHighlight(sel, colorId) {
    if (!sel || !this.file) return null;
    const id = "h" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const hl = { id, color: colorId, text: sel.text, block: sel.block, occ: sel.occ, pre: sel.pre, post: sel.post, created: Date.now() };
    this.plugin.addHighlight(this.file.path, hl);
    const blocks = this.pager.flow ? this.pager.flow.querySelectorAll("p,h1,h2,h3,h4") : [];
    const block = blocks[hl.block];
    if (block) {
      const t = block.textContent;
      const loc = locateHl(t, hl);
      if (loc) wrapBlockRange(block, loc.start, loc.start + loc.len, { id: hl.id, color: hlColorCss(colorId) });
    }
    return id;
  }
  _currentHl() {
    if (this._editHlId && this.file) {
      const hl = this.plugin.getHighlights(this.file.path).find((h) => h.id === this._editHlId);
      if (hl) return { text: hl.text || "", block: hl.block, color: hl.color };
    }
    if (this._pendingSel) return { text: this._pendingSel.text || "", block: this._pendingSel.block, color: null };
    return null;
  }
  _openHlEdit(id) {
    const span = this.pager.flow?.querySelector(`[data-hl-id="${id}"]`);
    if (!span) return;
    this._pendingSel = null;
    this._editHlId = id;
    this._showHlPopup(span.getBoundingClientRect());
  }
  _unwrapHighlight(id) {
    const flow = this.pager.flow;
    if (!flow) return;
    flow.querySelectorAll(`[data-hl-id="${id}"]`).forEach((span) => {
      const parent = span.parentNode;
      while (span.firstChild) parent.insertBefore(span.firstChild, span);
      parent.removeChild(span);
      parent.normalize();
    });
  }
  _showHlPopup(rect) {
    const pop = this.hlPopup;
    pop.classList.add("er-hl-popup-on");
    positionHlPopup(this, rect, 230, 46);
  }
  _hideHlPopup() {
    erClearPaintedSelection();
    this._pendingSel = null;
    this._editHlId = null;
    if (this.hlPopup) this.hlPopup.classList.remove("er-hl-popup-on");
  }
  goToHighlight(id) {
    const hl = this.file ? this.plugin.getHighlights(this.file.path).find((h) => h.id === id) : null;
    if (!hl) return;
    this._closePanel();
    const [cur, tot] = this.pager.jumpTo(this.pager.spreadForBlock(hl.block));
    this._updateUI(cur, tot);
    if (this.file) this.plugin.saveProgress(this.file.path, cur, tot, this.pager.currentBlockIndex());
    window.requestAnimationFrame(() => {
      const span = this.pager.flow?.querySelector(`[data-hl-id="${id}"]`);
      if (span) {
        span.classList.add("er-hl-flash");
        window.setTimeout(() => span.classList.remove("er-hl-flash"), 1200);
      }
    });
  }
  _buildHlPanel() {
    const p = this.hlPan;
    p.empty();
    p.createDiv("er-pan-title").setText(__ertr("Highlights"));
    const list = this.file ? this.plugin.getHighlights(this.file.path) : [];
    if (!list.length) { p.createDiv("er-toc-empty").setText(__ertr("No highlights yet.\nSelect text and pick a color.")); return; }
    const exp = p.createDiv("er-hl-export");
    iconLabel(exp, "download", __ertr("Export to notes ({0})", list.length));
    exp.setAttribute("aria-label", __ertr("Export all highlights"));
    exp.addEventListener("click", (e) => this.exportHighlights(e));
    const wrap = p.createDiv("er-toc-list");
    list.forEach((hl) => {
      const item = wrap.createDiv("er-hl-item");
      const dot = item.createDiv("er-hl-dot");
      dot.style.background = hlColorCss(hl.color);
      // Quote + comment share one column (er-hl-body) so the comment stacks UNDER
      // the quote. Without the wrapper both were flex siblings of the row, and the
      // comment's long word squeezed the quote down to one letter per line.
      const body = item.createDiv("er-hl-body");
      const txt = body.createDiv("er-hl-text");
      txt.setText(hl.text.length > 160 ? hl.text.slice(0, 160) + "…" : hl.text);
      if (hl.comment) body.createDiv("er-hl-comment").setText(hl.comment);
      // Export just this one highlight — via the ⋯ button, tap-and-hold or right-click.
      const showHlMenu = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!this.file) return;
        const menu = new Menu();
        menu.addItem((it) => it.setTitle(__ertr("Create note")).setIcon("file-plus").onClick(() => {
          createNoteFromSelection(this.app, this.plugin, hl.text, this.file, { extra: hlCommentMd(hl), color: hl.color, hl });
        }));
        menu.addItem((it) => it.setTitle(__ertr("As text into the book note")).setIcon("text-quote").onClick(() => {
          sendQuoteToBookNote(this, hl);
        }));
        menu.showAtMouseEvent(e);
      };
      const more = item.createDiv("er-hl-more");
      svgIcon(more, "more");
      more.setAttribute("aria-label", __ertr("More"));
      more.addEventListener("click", showHlMenu);
      const del = item.createDiv("er-hl-del");
      svgIcon(del, "trash");
      del.addEventListener("click", (e) => {
        e.stopPropagation();
        if (!this.file) return;
        this.plugin.removeHighlight(this.file.path, hl.id);
        this._unwrapHighlight(hl.id);
        this._buildHlPanel();
      });
      item.addEventListener("click", () => this.goToHighlight(hl.id));
      item.addEventListener("contextmenu", showHlMenu);
    });
  }
  onClose() {
    this._tts?.dispose();
    stopReadingTimer(this);
    if (this.plugin._openReaderModal === this) this.plugin._openReaderModal = null;
    // The search paint is a document-level highlight; it would outlive the book.
    clearFoundIn(this);
    if (this._selHandler) (this._selDoc || document).removeEventListener("selectionchange", this._selHandler);
    this._resizeObs?.disconnect();
    this._pdfLazy?.destroy?.();
    this._pdfLazy = null;
    window.clearTimeout(this._rsT);
    window.clearTimeout(this._selTimer);
    window.clearTimeout(this._immTimer);
    window.clearTimeout(this._revealT);
    this._closeWatch?.disconnect();
    this.contentEl.empty();
  }
};
// One group of settings, in its own window.
//
// A settings page long enough to scroll is a page nobody reads: the option you
// need is buried among twenty you set once a year and never think about again.
// The handful of controls touched while actually reading stay on the tab; the
// rest move behind a button, grouped by the job they belong to.
const SettingsGroupModal = class extends Modal {
  constructor(app, title, build) {
    super(app);
    this.title = title;
    this.build = build;
  }
  onOpen() {
    this.modalEl.addClass("er-settings-group");
    this.draw();
  }
  draw() {
    const c = this.contentEl;
    // The scrolling box itself is rebuilt below, so the position has to be
    // carried over by hand rather than left to the browser.
    const was = this.bodyEl ? this.bodyEl.scrollTop : 0;
    c.empty();
    c.createEl("h3", { text: this.title });
    this.bodyEl = c.createDiv("er-group-body");
    // Rebuilt on every redraw, because some of these settings decide whether
    // the others exist at all.
    this.build(this.bodyEl, () => this.draw());
    const row = c.createDiv("er-group-actions");
    // "Done" rather than "Save": every control here writes the moment it is
    // touched, exactly as it did on the settings page.
    const done = row.createEl("button", { cls: "mod-cta", text: __ertr("Done") });
    done.addEventListener("click", () => this.close());
    if (was) this.bodyEl.scrollTop = was;
  }
  onClose() { this.contentEl.empty(); }
};
const SettingsTab = class extends PluginSettingTab {
  // A row that stands for a whole group: name, one line on what is inside, and
  // the button that opens it.
  _group(c, { name, desc, build }) {
    new Setting(c)
      .setName(name)
      .setDesc(desc)
      .addButton((b) => b
        .setButtonText(__ertr("Configure"))
        .onClick(() => new SettingsGroupModal(this.app, name, build).open()));
  }
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  // Rebuild the page (needed when labels themselves change, e.g. the UI language)
  // while keeping the reader where they were — a plain display() drops the scroll
  // position back to the top, which felt like the settings "forgot" the place.
  _redraw() {
    const el = this.containerEl;
    const scroller = el.scrollHeight > el.clientHeight ? el : (el.closest(".vertical-tab-content") || el.parentElement || el);
    const y = scroller.scrollTop;
    this.display();
    scroller.scrollTop = y;
    window.requestAnimationFrame(() => { scroller.scrollTop = y; });
  }
  // Settings are split across tabs rather than one long scroll. Each tab is a
  // whole job ("I'm setting up notes", "I'm changing how pages turn"), so the
  // reader only ever faces the handful of options that belong to what they came
  // to do — instead of scanning ~20 unrelated rows to find one.
  display() {
    const { containerEl: c } = this;
    c.empty();
    c.createEl("h2", { text: "Book Reader TTS" });
    mountSyncSettings(c,this.plugin);
    const TABS = [
      { id: "read", label: __ertr("Reading") },
      { id: "look", label: __ertr("Appearance") },
      { id: "notes", label: __ertr("Notes") },
      { id: "translate", label: __ertr("Translation") },
      { id: "data", label: __ertr("Data") },
      { id: "about", label: __ertr("About") }
    ];
    if (!this._tab || !TABS.some((t) => t.id === this._tab)) this._tab = "read";
    // Language sits ABOVE the tabs, not inside the last one.
    //
    // It used to live at the bottom of "About", which is the last place someone
    // who cannot read the interface would look — several readers said switching
    // to English was hard to find, and one gave up and asked in a comment.
    // A setting whose whole purpose is "I do not understand this screen" has to
    // be visible from every screen.
    new Setting(c).setName(__ertr("Interface language")).setDesc(__ertr("Follows Obsidian's language, with the device language as fallback. Reopen the reader after changing language. Unsupported languages use English."));
    const bar = c.createDiv("er-set-tabs");
    TABS.forEach((t) => {
      const el = bar.createDiv("er-set-tab");
      el.setText(t.label);
      if (t.id === this._tab) el.addClass("er-set-tab-on");
      el.addEventListener("click", () => { this._tab = t.id; this.display(); });
    });
    const body = c.createDiv("er-set-body");
    if (this._tab === "read") this._tabReading(body);
    else if (this._tab === "look") this._groupAppearance(body);
    else if (this._tab === "notes") this._tabNotes(body);
    else if (this._tab === "translate") this._tabTranslate(body);
    else if (this._tab === "data") this._tabData(body);
    else this._tabAbout(body);
  }
  // Lifetime reading stats. Built with createEl rather than innerHTML — no user
  // text is interpolated and store review flags raw HTML.
  _statsCard(c) {
    const st = readingStats(this.plugin.settings.readingLog, this.plugin.settings.lifetimeSeconds, readerTodayKey());
    const card = c.createDiv({ cls: "er-stats" });

    const head = card.createDiv({ cls: "er-stats-head" });
    const total = head.createDiv({ cls: "er-stats-total" });
    total.createDiv({ cls: "er-stats-big", text: fmtReadTime(st.total) });
    total.createDiv({ cls: "er-stats-cap", text: __ertr("all-time with books") });
    /* Hide an empty reading streak instead of showing zero days. */
    if (st.streak > 0) {
      const fl = head.createDiv({ cls: "er-stats-streak" });
      fl.createSpan({ cls: "er-stats-flame", text: "🔥" });
      fl.createSpan({ text: __ertr("{0}-day streak", st.streak) });
    }

    const grid = card.createDiv({ cls: "er-stats-grid" });
    const cell = (label, value) => {
      const d = grid.createDiv({ cls: "er-stats-cell" });
      d.createDiv({ cls: "er-stats-val", text: value });
      d.createDiv({ cls: "er-stats-lab", text: label });
    };
    cell(__ertr("today"), fmtReadTime(st.today));
    cell(__ertr("days with a book"), st.daysRead ? String(st.daysRead) : "—");
    cell(__ertr("daily average"), fmtReadTime(st.avgPerDay));
    cell(__ertr("best day"), fmtReadTime(st.best));

    // Two weeks at a glance. Bars are relative to the best day in the window, so
    // the shape stays readable whether you read 10 minutes a day or three hours.
    const peak = st.recent.reduce((a, r) => Math.max(a, r.sec), 0);
    if (peak > 0) {
      const chart = card.createDiv({ cls: "er-stats-chart" });
      const bars = chart.createDiv({ cls: "er-stats-bars" });
      for (const r of st.recent) {
        const col = bars.createDiv({ cls: "er-stats-bar" + (r.sec > 0 ? " is-read" : "") });
        const fill = col.createDiv({ cls: "er-stats-fill" });
        // Any reading at all keeps a visible stub, so a short day isn't invisible.
        fill.style.height = r.sec > 0 ? Math.max(8, Math.round(r.sec / peak * 100)) + "%" : "2px";
        col.setAttr("aria-label", r.key + " — " + fmtReadTime(r.sec));
        col.setAttr("title", r.key + " — " + fmtReadTime(r.sec));
      }
      const legend = chart.createDiv({ cls: "er-stats-legend" });
      legend.createSpan({ text: __ertr("14 days ago") });
      legend.createSpan({ text: __ertr("today") });
    } else {
      card.createDiv({ cls: "er-stats-empty", text: __ertr("Open a book and start the timer ▶ — your reading history will appear here.") });
    }
  }

  /* Reading settings. */
  _tabReading(c) {
    this._statsCard(c);
    new Setting(c)
      .setName(__ertr("Line width"))
      .setDesc(__ertr("Longest line, in characters. On a wide monitor a full-width line runs past 150 characters and the eye loses its place returning to the next one — the comfortable range is 60-90. The spare width becomes margin; how the book is split into pages does not change."))
      .addDropdown((d) => d
        .addOption("0", __ertr("Full width"))
        .addOption("60", "60")
        .addOption("70", "70")
        .addOption("80", "80")
        .addOption("90", "90")
        .setValue(String(this.plugin.settings.maxLineCh || 0))
        .onChange(async (v) => {
          this.plugin.settings.maxLineCh = Number(v) || 0;
          await this.plugin.saveAll();
          for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
            const view = leaf.view;
            if (view && view.bookHtml) view.repaginate();
          }
        }));
    new Setting(c)
      .setName(__ertr("Page turning"))
      .setDesc(__ertr("\"Buttons\" — arrows/keys/swipe. \"By click\" — clicking the left/right part of the page turns back/forward (the center stays free for selecting text)."))
      .addDropdown((d) => d
        .addOption("buttons", __ertr("Buttons"))
        .addOption("click", __ertr("By mouse click"))
        .setValue(this.plugin.settings.navMode || "buttons")
        .onChange(async (v) => { this.plugin.settings.navMode = v; await this.plugin.saveAll(); }));
    new Setting(c)
      .setName(__ertr("Page-turn animation"))
      .setDesc(__ertr("The page slides sideways as it turns — that movement is what shows the book moved, and which way. Independent of the system's \"reduce motion\" setting: that one drops decoration, this is feedback. Turn it off if you prefer pages to switch instantly."))
      .addToggle((t) => t.setValue(this.plugin.settings.pageTurnAnimation !== false).onChange(async (v) => {
        this.plugin.settings.pageTurnAnimation = v;
        await this.plugin.saveAll();
        for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
          const view = leaf.view;
          if (view && view.pager && view.pager.flow) {
            view.pager.animate = v;
            view.pager.flow.toggleClass("er-flow-anim", v);
          }
        }
      }));
    new Setting(c)
      .setName(__ertr("How to read"))
      .setDesc(__ertr("\"Pages\" splits the text into spreads you turn like a book. \"Scrolling\" is one long column you move with a finger or the wheel, like a web page; many people read for longer that way, because the text does not stop at the edge of a page. While scrolling, your place is remembered by the paragraph at the TOP edge of the screen — and the surest way is to mark it yourself: \"⋯\" → \"Save position\". Reopen the book to apply."))
      .addDropdown((d) => d
        .addOption("pages", __ertr("In pages"))
        .addOption("scroll", __ertr("By scrolling"))
        .setValue(this.plugin.settings.readMode || "pages")
        .onChange(async (v) => {
          this.plugin.settings.readMode = v;
          await this.plugin.saveAll();
          for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
            const view = leaf.view;
            if (view && view.bookHtml) view.repaginate();
          }
        }));
    // Appearance used to hang off this tab as a button that opened a window.
    // It is a section of its own now — a whole group of settings behind one row
    // reads as an afterthought, and "how the page looks" is not an afterthought.
    c.createEl("div", { cls: "er-set-note", text: __ertr("How the page looks lives in the Appearance tab. Font, size and line height are set in the book itself — the sliders icon at the top of the reader.") });
  }
  // Where the breakdown is fetched from. In its own window because it is set up
  // once and then never touched, and because the key field has no business
  // sitting next to the reading options.
  _groupAi(c, redraw) {
    const s = this.plugin.settings;
    const cfg = aiConfig(s);
    new Setting(c)
      .setName(__ertr("Service"))
      .addDropdown((d) => {
        for (const [id, p] of Object.entries(AI_PROVIDERS)) d.addOption(id, p.label);
        d.setValue(s.aiProvider || "eltonlabs").onChange(async (v) => {
          s.aiProvider = v;
          // The model belongs to the provider: carrying one service's model
          // name over to another fails on the first request with a bare 404.
          s.aiModel = "";
          await this.plugin.saveAll();
          redraw();
        });
      });
    if (AI_PROVIDERS[s.aiProvider || "eltonlabs"].needsKey) {
      new Setting(c)
        .setName(__ertr("Key"))
        .setDesc(__ertr("Kept in the plugin's settings, inside your vault. If the vault syncs, the key travels with it — worth knowing."))
        .addText((t) => {
          t.inputEl.type = "password";
          t.setPlaceholder("sk-…").setValue(s.aiKey || "").onChange(async (v) => {
            s.aiKey = v.trim();
            await this.plugin.saveAll();
          });
        });
    }
    new Setting(c)
      .setName(__ertr("Model"))
      .setDesc(__ertr("Empty — this service's default model: {0}", cfg.model))
      .addText((t) => t.setPlaceholder(cfg.model).setValue(s.aiModel || "").onChange(async (v) => {
        s.aiModel = v.trim();
        await this.plugin.saveAll();
      }));
    new Setting(c)
      .setName(__ertr("Your own system prompt"))
      .setDesc(__ertr("What exactly to do with the passage. Empty — the built-in breakdown: translation, hard words, phrasing, etymology. Your own text replaces it entirely, both for the breakdown and for the questions you type in the breakdown window."))
      .addTextArea((t) => {
        t.inputEl.rows = 6;
        t.inputEl.addClass("er-ai-sys");
        t.setPlaceholder(__ertr("For example: explain it in plain words and give two examples from real life."))
          .setValue(s.aiSystem || "").onChange(async (v) => {
            s.aiSystem = v;
            await this.plugin.saveAll();
          });
      });
    new Setting(c)
      .setName(__ertr("Answer in"))
      .setDesc(__ertr("Which language to write the breakdown in. The book's own language is detected."))
      .addText((t) => t.setPlaceholder(__ertr("Follow system")).setValue(s.aiInto === "auto" ? "" : s.aiInto || "").onChange(async (v) => {
        s.aiInto = v.trim() || "auto";
        await this.plugin.saveAll();
      }));
    c.createEl("div", {
      cls: "er-set-note",
      text: cfg.id === "local"
        ? __ertr("Local model: nothing leaves the device, but Ollama or LM Studio has to be running on this machine.")
        : __ertr("The selected passage is sent to {0}. Everything else in the reader works offline.", cfg.base),
    });
  }
  // Set once and forgotten: kept out of the tab so what remains there is only
  // what a reader reaches for mid-book. Same controls, same behaviour.
  _groupAppearance(c) {
    c.createEl("h3", { text: __ertr("Modes") });
    new Setting(c)
      .setName(__ertr("A separate look on each device"))
      .setDesc(__ertr("Font size, theme, typeface, line spacing, column count and alignment are remembered separately for computer, tablet and phone. The settings live in one synced file, but each device reads its own part, so a large size on the phone no longer makes the text enormous on the computer. Folders, templates and reading progress stay shared. This device: {0}.",
        __ertr({ desktop: "computer", tablet: "tablet", phone: "phone" }[erDeviceKey()])))
      .addToggle((t) => t.setValue(this.plugin.settings.perDevice === true).onChange(async (v) => {
        this.plugin.settings.perDevice = v;
        // Turning it ON adopts whatever is on screen right now as this device's
        // look, so nothing changes under the reader at the moment of the click.
        await this.plugin.saveAll();
        this.display();
      }));
    new Setting(c)
      .setName(__ertr("E-ink reader mode"))
      .setDesc(__ertr("For Obsidian on an Android e-ink reader. Removes animations, fades, shadows and blur — they leave ghosting on such a screen. Pure black on white, hard borders, bigger buttons, page turns that jump instead of sliding."))
      .addToggle((t) => t.setValue(this.plugin.settings.einkMode === true).onChange(async (v) => {
        this.plugin.settings.einkMode = v;
        // The e-ink palette is part of the mode; switching back restores light.
        if (v) this.plugin.settings.theme = "eink";
        else if (this.plugin.settings.theme === "eink") this.plugin.settings.theme = "auto";
        await this.plugin.saveAll();
        for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
          const view = leaf.view;
          if (view && view.applyVars) { view.applyVars(); if (view.bookHtml) view.repaginate(); }
        }
      }));
    c.createEl("h3", { text: __ertr("Text on the page") });
    new Setting(c)
      .setName(__ertr("Text alignment"))
      .setDesc(__ertr("How text is aligned in the reading column. You can also change it on the fly from the reading-settings panel (sliders icon) inside a book. Reopen the book to apply."))
      .addDropdown((d) => d
        .addOption("left", __ertr("Left"))
        .addOption("justify", __ertr("Justify"))
        .addOption("center", __ertr("Center"))
        .addOption("right", __ertr("Right"))
        .setValue(this.plugin.settings.textAlign || "left")
        .onChange(async (v) => { this.plugin.settings.textAlign = v; await this.plugin.saveAll(); }));
    new Setting(c)
      .setName(__ertr("Text position on the page"))
      .setDesc(__ertr("When a page isn't filled (at the end of a chapter, for instance), the text needn't stay pinned to the top. Can also be changed on the fly from the reading-settings panel."))
      .addDropdown((d) => d
        .addOption("top", __ertr("Top"))
        .addOption("center", __ertr("Center"))
        .addOption("bottom", __ertr("Bottom"))
        .setValue(this.plugin.settings.vAlign || "top")
        .onChange(async (v) => { this.plugin.settings.vAlign = v; await this.plugin.saveAll(); }));
    new Setting(c)
      .setName(__ertr("Show pictures from the book"))
      .setDesc(__ertr("Show illustrations and diagrams above extracted PDF text. Scanned pages remain full-page images. Reopen the book to apply."))
      .addToggle((t) => t.setValue(this.plugin.settings.pdfShowFiguresOnTextPages === true).onChange(async (v) => {
        this.plugin.settings.pdfShowFiguresOnTextPages = v;
        await this.plugin.saveAll();
      }));
    new Setting(c)
      .setName(__ertr("Immersive"))
      .setDesc(__ertr("The top and bottom bars gently dim after a couple of seconds without mouse movement and instantly return when you move — so nothing distracts from the text."))
      .addToggle((t) => t.setValue(this.plugin.settings.immersive !== false).onChange(async (v) => {
        this.plugin.settings.immersive = v; await this.plugin.saveAll();
      }));
    if (Platform.isMobile) {
      new Setting(c)
        .setName(__ertr("Top inset on mobile"))
        .setDesc(__ertr("Normally the system reports the height of the status bar and the reader's top bar starts below it. Some Android skins (Samsung One UI, for one) do not, and the bar slides under the clock. Then type the height here in pixels, usually 24-48. Zero means trust the system. Reopen the book to apply."))
        .addText((t) => t
          .setPlaceholder("0")
          .setValue(String(this.plugin.settings.mobileTopInset || 0))
          .onChange(async (v) => {
            const n = Math.max(0, Math.min(120, Number(String(v).replace(/[^\d]/g, "")) || 0));
            this.plugin.settings.mobileTopInset = n;
            await this.plugin.saveAll();
          }));
    }
  }
  /* Note settings. */
  _tabNotes(c) {
    c.createEl("h3", { text: __ertr("Where notes go") });
    new Setting(c)
      .setName(__ertr("Folder for new notes"))
      .setDesc(__ertr("Where SEPARATE notes go — the ones you make from a passage with \"Create note\". One highlight, one file. Empty means the vault root. Not the same as the book-notes folder below, which holds one shared note per book."))
      .addText((t) => { t.setPlaceholder("Inbox").setValue(this.plugin.settings.notesFolder || "");
        attachPathInput(this.app, t, async (v) => {
          this.plugin.settings.notesFolder = v;
          await this.plugin.saveAll();
        }); });
    new Setting(c)
      .setName(__ertr("Keep notes next to the book"))
      .setDesc(__ertr("A note made from a highlight is created in the same folder as the book, instead of the shared notes folder. If you picked a folder by hand in the create dialog, your choice wins. A book in the vault root falls back to the folder set above."))
      .addToggle((t) => t.setValue(this.plugin.settings.notesNextToBook === true).onChange(async (v) => {
        this.plugin.settings.notesNextToBook = v;
        await this.plugin.saveAll();
      }));
    new Setting(c)
      .setName(__ertr("Where a new note opens"))
      .setDesc(__ertr("\"Beside the book\" splits the pane so the book stays in view. \"In a new tab\" opens on top — the book stays open but leaves the screen."))
      .addDropdown((d) => d
        .addOption("split", __ertr("Beside the book"))
        .addOption("tab", __ertr("In a new tab"))
        .addOption("none", __ertr("Don't open it"))
        .setValue(this.plugin.settings.noteOpenMode || "split")
        .onChange(async (v) => { this.plugin.settings.noteOpenMode = v; await this.plugin.saveAll(); }));
    new Setting(c)
      .setName(__ertr("Ask for the note title"))
      .setDesc(__ertr("Show an editable title dialog when creating a note. Off by default; enable automatic short titles below to save quietly."))
      .addToggle((t) => t.setValue(this.plugin.settings.askNoteTitle !== false).onChange(async (v) => {
        this.plugin.settings.askNoteTitle = v;
        await this.plugin.saveAll();
        this._redraw();
      }));
    // Only meaningful when the dialog is off — otherwise the reader decides each time.
    if (this.plugin.settings.askNoteTitle === false) {
      new Setting(c)
        .setName(__ertr("Short titles, no questions"))
        .setDesc(__ertr("The title is chosen automatically: the passage's first sentence, or its opening cut on a word boundary. Off — the whole passage goes into the filename, as before."))
        .addToggle((t) => t.setValue(this.plugin.settings.shortNoteTitles !== false).onChange(async (v) => {
          this.plugin.settings.shortNoteTitles = v;
          await this.plugin.saveAll();
        }));
    }    c.createEl("h3", { text: __ertr("Quotes and highlights") });
    new Setting(c)
      .setName(__ertr("Default highlight colour"))
      .setDesc(__ertr("Which colour to use when you comment on a passage without picking a colour first. A comment can only be stored on a highlight, so one is created for you."))
      .addDropdown((d) => {
        HL_COLORS.forEach((col) => d.addOption(col.id, col.name));
        d.setValue(this.plugin.settings.defaultHlColor || HL_COLORS[0].id)
          .onChange(async (v) => { this.plugin.settings.defaultHlColor = v; await this.plugin.saveAll(); });
      });
    // A multi-line field does not belong in the right-hand column of a settings
    // row. Obsidian lays that column out beside the name and description, so a
    // template box wide enough to read squeezed its own title down to a few
    // clipped letters — and the drag handle in the corner had nowhere to go.
    // The row is stacked instead: title and explanation on top, field the full
    // width underneath, resizable downwards like any textarea should be.
    const tpl = new Setting(c)
      .setName(__ertr("Shape of a copied quote"))
      .setDesc(__ertr("What the \"Copy as a quote\" button puts on the clipboard. Available: {text}, {book}, {page}, {link}, {comment}. Empty means the default shape."))
      .addTextArea((t) => {
        t.setPlaceholder(QUOTE_TEMPLATE_DEFAULT)
          .setValue(this.plugin.settings.quoteTemplate || "")
          .onChange(async (v) => {
            this.plugin.settings.quoteTemplate = v;
            await this.plugin.saveAll();
          });
        t.inputEl.rows = 4;
        t.inputEl.addClass("er-tpl-input");
      });
    new Setting(c)
      .setName(__ertr("Link back to the book under each quote"))
      .setDesc(__ertr("Every exported quote gets a link that opens the book at the exact paragraph the quote came from. Works from any note."))
      .addToggle((t) => t.setValue(this.plugin.settings.quoteBacklinks !== false).onChange(async (v) => {
        this.plugin.settings.quoteBacklinks = v;
        await this.plugin.saveAll();
      }));
    new Setting(c)
      .setName(__ertr("Wording of that link"))
      .setDesc(__ertr("The text the link is labelled with in the note. Empty means the standard «{0}».", __ertr("↪ to this spot in the book")))
      .addText((t) => t
        .setPlaceholder(__ertr("↪ to this spot in the book"))
        .setValue(this.plugin.settings.quoteBacklinkLabel || "")
        .onChange(async (v) => {
          this.plugin.settings.quoteBacklinkLabel = v;
          await this.plugin.saveAll();
        }));
    new Setting(c)
      .setName(__ertr("Keep highlight color on export"))
      .setDesc(__ertr("Each quote is wrapped in a colored <mark> — the highlight color shows in the finished note (in reading mode and live preview, no plugins needed). Turn it off if you want plain quotes without HTML."))
      .addToggle((t) => t.setValue(this.plugin.settings.exportColors !== false).onChange(async (v) => {
        this.plugin.settings.exportColors = v;
        await this.plugin.saveAll();
      }));    c.createEl("h3", { text: __ertr("The book note") });
    new Setting(c)
      .setName(__ertr("A separate note per book"))
      .setDesc(__ertr("On a book's first open, a note named after the book is created (in the book-notes folder, else in the notes folder) and linked to it. Off by default. Where quotes go is a separate setting below."))
      .addToggle((t) => t.setValue(this.plugin.settings.autoBookNote === true).onChange(async (v) => {
        this.plugin.settings.autoBookNote = v;
        await this.plugin.saveAll();
        if (v) new Notice(__ertr("This is an early version of the feature — check the result on a couple of books first. The note is created once, on a book's first open."), 6e3);
      }));
    new Setting(c)
      .setName(__ertr("Quotes straight into the book note"))
      .setDesc(__ertr("Every new highlight is appended to this book's note as you make it — with the chapter, the page number and a link back to the spot in the text. No separate file per quote. The book needs a note linked to it: either by the setting above, or by hand through \"⋯\" → \"Book note\". Off by default."))
      .addToggle((t) => t.setValue(this.plugin.settings.quotesToBookNote === true).onChange(async (v) => {
        this.plugin.settings.quotesToBookNote = v;
        await this.plugin.saveAll();
      }));
    new Setting(c)
      .setName(__ertr("Book-notes folder (for links)"))
      .setDesc(__ertr("Where BOOK notes live — one per book, collecting every quote from it. This folder fills the picker when you link a note to a book, and is where an automatically created one goes. Empty means any note in the vault can be picked."))
      .addText((t) => { t.setPlaceholder(__ertr("3. Resources/Book base")).setValue(this.plugin.settings.bookNotesFolder || "");
        attachPathInput(this.app, t, async (v) => {
          this.plugin.settings.bookNotesFolder = v;
          await this.plugin.saveAll();
        }); });
    new Setting(c)
      .setName(__ertr("Progress in the book note's properties"))
      .setDesc(__ertr("Adds reading-progress (a percentage) and reading-updated (a date) to the book note's properties. Same numbers as the progress file, in a form Bases understands, so you can build tables and sort by them. Nothing else in the note is touched."))
      .addToggle((t) => t.setValue(this.plugin.settings.progressToFrontmatter === true).onChange(async (v) => {
        this.plugin.settings.progressToFrontmatter = v;
        await this.plugin.saveAll();
      }));
    tpl.settingEl.addClass("er-set-stacked");
    c.createEl("h3", { text: __ertr("Template") });
    new Setting(c)
      .setName(__ertr("Note template"))
      .setDesc(__ertr("Path to your (Templater) template applied to each new highlight note. Empty — the note is created without a template, with just the quote. Example: 0. Files/4. Templates/Default template.md"))
      .addText((t) => t.setPlaceholder(__ertr("Templates/Template.md")).setValue(this.plugin.settings.noteTemplate || "").onChange(async (v) => {
        this.plugin.settings.noteTemplate = v.trim();
        await this.plugin.saveAll();
      }));
    new Setting(c)
      .setName(__ertr("Keep «What's new» as a note"))
      .setDesc(__ertr("After the plugin updates, a note listing the changes appears in your vault, next to the reader's other notes. The «What's new» window shows once; the note stays."))
      .addToggle((t) => t.setValue(this.plugin.settings.whatsNewNote !== false).onChange(async (v) => {
        this.plugin.settings.whatsNewNote = v;
        await this.plugin.saveAll();
      }));
    c.createEl("div", { cls: "er-set-note", text: __ertr("Tip: the template can be overridden per book — open the book, press (i) at the top and set your template in the \"Template for this book\" field (handy if different genres need different formatting).") });  }
  /* Translation settings. */
  _tabTranslate(c) {
    new Setting(c)
      .setName(__ertr("AI passage breakdown"))
      .setDesc(__ertr("Adds a ✨ button to the selection popup: it opens a conversation about the passage. One tap asks for a breakdown — translation, hard words, phrasing, etymology — or you can simply ask in your own words and keep asking. It never asks on its own: the passage is sent to the service you choose only when you send a message. Off until you set that up."))
      .addToggle((t) => t.setValue(this.plugin.settings.aiEnabled === true).onChange(async (v) => {
        this.plugin.settings.aiEnabled = v;
        await this.plugin.saveAll();
        this.display();
      }));
    if (this.plugin.settings.aiEnabled) {
      this._group(c, {
        name: __ertr("Where breakdowns come from"),
        desc: __ertr("Service, key and model. A local model needs no key and sends nothing to the internet."),
        build: (b, redraw) => this._groupAi(b, redraw),
      });
    }
    new Setting(c)
      .setName(__ertr("Translate button in the selection popup"))
      .setDesc(__ertr("Adds a translate button to the popup that appears when you select text. The translation is shown next to the original; you can copy it or save it into a note under the quote. Reopen the book for the button to appear."))
      .addToggle((t) => t.setValue(this.plugin.settings.translateEnabled === true).onChange(async (v) => {
        this.plugin.settings.translateEnabled = v;
        await this.plugin.saveAll();
        if (v) new Notice(__ertr("This is an early version of the feature. Translation uses the free Google Translate: it needs internet, is rate-limited, and the selected fragment is sent to Google's servers. Not intended for large volumes yet."), 1e4);
      }));
    new Setting(c)
      .setName(__ertr("Translate into"))
      .setDesc(__ertr("The language to translate the selected fragment into. The source language is detected automatically."))
      .addDropdown((d) => d
        .addOption("auto", __ertr("Follow system"))
        .addOption("zh-CN", __ertr("Chinese"))
        .addOption("ja", __ertr("Japanese"))
        .addOption("ru", __ertr("Russian"))
        .addOption("en", __ertr("English"))
        .addOption("de", __ertr("German"))
        .addOption("fr", __ertr("French"))
        .addOption("es", __ertr("Spanish"))
        .setValue(this.plugin.settings.translateTo || "auto")
        .onChange(async (v) => { this.plugin.settings.translateTo = v; await this.plugin.saveAll(); }));
    c.createEl("div", { cls: "er-set-note", text: __ertr("Translation is a separate network request to Google. If you need the book's text to stay on your device, leave this off: everything else in the reader works fully offline.") });
  }
  /* Data settings. */
  _tabData(c) {
    new Setting(c).setName(__ertr("Books folder")).setDesc(__ertr("Empty = the whole vault")).addText((t) => {
      t.setPlaceholder("0. Files/3. PDF-files").setValue(this.plugin.settings.booksFolder);
      attachPathInput(this.app, t, async (v) => {
        this.plugin.settings.booksFolder = v;
        await this.plugin._saveLocalData();
        await this.plugin.saveAll();
      });
    });
    new Setting(c)
      .setName(__ertr("Reading-data folder"))
      .setDesc(__ertr("Where reading progress, highlights and rescue backups are kept (tts-reader-progress.json, tts-reader-highlights.json). Empty — next to the books (in the \"Books folder\"). The files sync along with the vault."))
      .addText((t) => { t.setPlaceholder(__ertr("Next to the books")).setValue(this.plugin.settings.dataFolder || "");
        attachPathInput(this.app, t, async (v) => {
          this.plugin.settings.dataFolder = v;
          await this.plugin._saveLocalData();
          await this.plugin.saveAll();
        }); });

    c.createEl("h3", { text: __ertr("Syncing across devices") });
    const syncInfo = c.createEl("div", { cls: "er-set-note" });
    const progPath = this.plugin._progressFilePath();
    const hlPath = this.plugin._highlightsFilePath();
    // Built as nodes rather than as a string. The two paths come from the
    // user's own settings, and pasting them into markup meant a folder named
    // with a stray angle bracket was parsed as HTML rather than shown. Text
    // nodes cannot be misread as markup, whatever the folder is called.
    {
      const line = (parts) => {
        const d = syncInfo.createDiv();
        for (const p of parts) {
          if (typeof p === "string") d.appendText(p);
          else d.createEl(p.tag, { text: p.text });
        }
        return d;
      };
      line([
        { tag: "span", text: __ertr("Reading progress and highlights are stored ") },
        { tag: "b", text: __ertr("as files right in the vault") },
        __ertr(", next to the books:"),
      ]);
      for (const path of [progPath, hlPath]) line(["• ", { tag: "code", text: path }]);
      line([
        __ertr("So they travel between PC and phone by "),
        { tag: "b", text: __ertr("any") },
        __ertr(" means you use to sync the vault itself (Obsidian Sync, iCloud, Google Drive, Remotely Save and so on). The position is anchored by paragraph number, so PC and phone find the same spot at any screen size."),
      ]);
      line([
        __ertr("Appearance settings and the cover cache are local (in the plugin's "),
        { tag: "code", text: "data.json" },
        __ertr(") and are intentionally not synced."),
      ]);
    }
    new Setting(c)
      .setName(__ertr("Sync method"))
      .setDesc(__ertr("Tells the plugin how eagerly to re-read the progress files when opening a book."))
      .addDropdown((d) => d
        .addOption("auto", __ertr("Auto (recommended)"))
        .addOption("obsidian", "Obsidian Sync")
        .addOption("remotely", "Remotely Save / self-hosted")
        .addOption("cloud", __ertr("iCloud / Google Drive / folder"))
        .addOption("none", __ertr("No syncing"))
        .setValue(this.plugin.settings.syncMode || "auto")
        .onChange(async (v) => {
          this.plugin.settings.syncMode = v;
          await this.plugin.saveAll();
          this._redraw();
        }));
    if (this.plugin.settings.syncMode === "cloud") {
      c.createEl("div", { cls: "er-set-note", text: __ertr("Cloud folders (iCloud/Drive) update with a delay. If you only read on one device there will be no conflicts: the plugin re-reads progress every time a book is opened and carefully merges highlights.") });
    }

    c.createEl("h3", { text: __ertr("Cleanup") });
    const thumbSet = new Setting(c).setName(__ertr("Cover cache")).setDesc(__ertr("Saved: {0}", (Object.keys(this.plugin.thumbCache).length))).addButton((b) => b.setButtonText(__ertr("Clear")).onClick(async () => {
      this.plugin.thumbCache = {};
      await this.plugin._saveThumbCache();
      new Notice(__ertr("Cache cleared"));
      thumbSet.setDesc(__ertr("Saved: {0}", 0));
    }));
    const progSet = new Setting(c).setName(__ertr("Progress")).setDesc(__ertr("Books: {0}", (Object.keys(this.plugin.progress).length))).addButton((b) => b.setButtonText(__ertr("Clear")).setWarning().onClick(async () => {
      this.plugin.progress = {};
      await this.plugin.saveAll();
      new Notice(__ertr("Progress cleared"));
      progSet.setDesc(__ertr("Books: {0}", 0));
    }));
    const hlCount = Object.values(this.plugin.highlights).reduce((s, a) => s + (Array.isArray(a) ? a.length : 0), 0);
    const hlSet = new Setting(c).setName(__ertr("Highlights")).setDesc(__ertr("Total: {0}", (hlCount))).addButton((b) => b.setButtonText(__ertr("Clear all")).setWarning().onClick(async () => {
      this.plugin.highlights = {};
      await this.plugin._saveHighlightsToVault();
      new Notice(__ertr("Highlights cleared"));
      hlSet.setDesc(__ertr("Total: {0}", 0));
    }));
    // What the reader remembers ABOUT each book, as opposed to their progress in
    // it: which note it's linked to, its category, its template override, and
    // whether the setup screen has already been shown. None of the buttons above
    // touch any of that — so "I cleared everything and it still won't ask me
    // again" was a real dead end (and the only way out was renaming the file).
    const memCount = () => {
      const s = this.plugin.settings;
      return new Set([].concat(
        Object.keys(s.bookNoteLinks || {}),
        Object.keys(s.bookNotePrompted || {}),
        Object.keys(s.bookTags || {}),
        Object.keys(s.bookTemplates || {})
      )).size;
    };
    const memSet = new Setting(c)
      .setName(__ertr("What the reader remembers"))
      .setDesc(__ertr("Books: {0}. Linked notes, categories, per-book templates and the \"already asked about a note\" marks. The notes themselves are NOT deleted. Opening a book will not show a note prompt.", memCount()));
    let armed = false;
    memSet.addButton((b) => b.setButtonText(__ertr("Forget all books")).setWarning().onClick(async () => {
      // Two taps: this wipes links the reader made by hand, and an accidental
      // click would mean re-linking every book.
      if (!armed) {
        armed = true;
        b.setButtonText(__ertr("Really forget?"));
        window.setTimeout(() => { if (armed) { armed = false; b.setButtonText(__ertr("Forget all books")); } }, 4e3);
        return;
      }
      armed = false;
      b.setButtonText(__ertr("Forget all books"));
      const s = this.plugin.settings;
      s.bookNoteLinks = {};
      s.bookNotePrompted = {};
      s.bookTags = {};
      s.bookTemplates = {};
      await this.plugin.saveAll();
      new Notice(__ertr("Book links cleared; your notes are preserved"));
      memSet.setDesc(__ertr("Books: {0}. Linked notes, categories, per-book templates and the \"already asked about a note\" marks. The notes themselves are NOT deleted — the reader just forgets the links and will ask about a note again when you open each book.", 0));
    }));
  }
  /* About this plugin. */
  _tabAbout(c) {
    // The language picker used to live here, at the bottom of the last tab.
    // It now sits above the tab bar, visible from every screen — see display().
    new Setting(c)
      .setName(__ertr("Feedback and bugs"))
      .setDesc(__ertr("Everything you would like changed or fixed is collected in the Telegram bot @book_in_obsidian_bot. Send it an ordinary message — no GitHub account and no form needed."))
      .addButton((b) => b.setCta().setButtonText(__ertr("Message the bot")).onClick(() => {
        window.open("https://t.me/book_in_obsidian_bot", "_blank");
      }));
    new Setting(c)
      .setName(__ertr("Plugin guide"))
      .setDesc(__ertr("A short guide to reading, listening, notes and syncing."))
      .addButton((b) => b.setButtonText(__ertr("Open the guide")).onClick(() => new OnboardingModal(this.app, this.plugin).open()));
    new Setting(c)
      .setName(__ertr("What's new"))
      .setDesc(__ertr("Changes from recent versions."))
      .addButton((b) => b.setButtonText(__ertr("Show")).onClick(() => {
        new WhatsNewModal(this.app, this.plugin, WHATS_NEW.slice(0, 4)).open();
      }));
    const about = c.createEl("div", { cls: "er-set-note" });
    about.createEl("b", { text: "Book Reader TTS" });
    about.appendText(__ertr(" — version {0}. Author: Elton.", this.plugin.manifest.version));
    about.createEl("br");
    about.appendText(__ertr("Feedback: "));
    about.createEl("a", { text: "@book_in_obsidian_bot", href: "https://t.me/book_in_obsidian_bot" });
    about.createEl("br");
    about.createEl("a", { text: "t.me/eltonlabs", href: "https://t.me/eltonlabs" });
  }
};
export default EltonReader;
