import {Modal,Notice,Setting} from 'obsidian';
import {t} from './i18n.js';
import {readingInsights} from './reading-insights.js';
import {formatReadingTime} from './reading-progress.js';
import {parseTags,libraryTags,tagsFor,editTags,renameTag,removeTag,setCollectionMembership} from './library-core.js';

export function openShelfSettings(view) { new ShelfSettings(view).open(); }
export function openReadingInsights(view) { new ReadingInsights(view).open(); }
class ReadingInsights extends Modal {
 constructor(view){super(view.app);this.view=view;}
 onOpen(){
  const c=this.contentEl;c.addClass('br-insights');const stats=readingInsights(this.view.plugin.settings);
  c.createEl('h2',{text:t('Reading insights')});
  c.createEl('p',{cls:'br-insight-caption',text:t('Your reading this week')});
  const cards=c.createDiv('br-insight-cards');
  for(const [label,value]of [[t('Today'),formatReadingTime(stats.today)],[t('Last 7 days'),formatReadingTime(stats.week)],[t('Total reading'),formatReadingTime(stats.total)],[t('Reading streak'),t('{0} days',stats.streak)]]){
   const card=cards.createDiv('br-insight-card');card.createEl('small',{text:label});card.createEl('strong',{text:value});
  }
  c.createEl('h3',{text:t('Last 7 days')});
  const chart=c.createDiv('br-insight-chart');const max=Math.max(1,...stats.days.map(x=>x.seconds));
  for(const d of stats.days){const column=chart.createDiv('br-insight-day');column.setAttribute('aria-label',`${d.date}: ${formatReadingTime(d.seconds)}`);column.createEl('small',{text:formatReadingTime(d.seconds)});const track=column.createDiv('br-insight-track');track.createDiv('br-insight-bar').style.height=`${d.seconds/max*100}%`;column.createEl('small',{text:d.date.slice(5)});}
  c.createEl('p',{text:stats.previous>0?t('{0}% compared with the previous 7 days',`${stats.week>=stats.previous?'+':''}${Math.round((stats.week-stats.previous)/stats.previous*100)}`):t('Not enough previous-week data for a comparison')});
  c.createEl('p',{text:t('Read on {0} of the last 7 days',stats.activeDays)});
  c.createEl('h3',{text:t('Most-read books by time')});
  if(!stats.ranked.length)c.createEl('p',{text:t('Open a book to start recording per-book reading time')});
  c.createEl('small',{cls:'br-insight-caption',text:t('Reading time is recorded on this device while the reader is in the foreground.')});
  for(const book of stats.ranked.slice(0,8)){const row=c.createDiv('br-insight-book');const file=this.app.vault.getAbstractFileByPath(book.path);row.createSpan({text:file?.basename||book.path.split('/').pop()});row.createEl('strong',{text:formatReadingTime(book.seconds)});}
 }
 onClose(){this.contentEl.empty();}
}
export function openBookTags(view,paths,append=false) { new BookTags(view,paths,append).open(); }
class ShelfSettings extends Modal {
 constructor(view){super(view.app);this.view=view;}
 onOpen(){
  const c=this.contentEl,s=this.view.plugin.settings;c.addClass('br-shelf-dialog');c.createEl('h2',{text:t('Customize bookshelf')});
  const draft={...s,libraryLabels:{...s.libraryLabels}};
  new Setting(c).setName(t('Library title')).addText(x=>x.setValue(s.libraryTitle||'').setPlaceholder(t('Library')).onChange(v=>draft.libraryTitle=v.trim()));
  new Setting(c).setName(t('Library subtitle')).addText(x=>x.setValue(s.librarySubtitle??'').setPlaceholder(t('My reading collection')).onChange(v=>draft.librarySubtitle=v.trim()));
  new Setting(c).setName(t('Show folder filters')).setDesc(t('Folder names are separate from your custom tags.')).addToggle(x=>x.setValue(s.libraryShowFolders===true).onChange(v=>draft.libraryShowFolders=v));
  new Setting(c).setName(t('Shelf layout')).addDropdown(x=>x.addOption('grid',t('Covers')).addOption('compact',t('Compact covers')).setValue(s.libraryLayout||'grid').onChange(v=>draft.libraryLayout=v));
  new Setting(c).addButton(b=>b.setButtonText(t('Save')).setCta().onClick(async()=>{try{for(const key of ['libraryTitle','librarySubtitle','libraryShowFolders','libraryLayout','libraryLabels'])s[key]=draft[key];await this.view.plugin._saveLocalData();this.close();this.view._refresh();}catch(e){new Notice(t('Error: {0}',e.message));}}));

 }
 onClose(){this.contentEl.empty();}
}
class BookTags extends Modal {
 constructor(view,paths,append){super(view.app);this.view=view;this.paths=paths;}
 onOpen(){
  const c=this.contentEl,s=this.view.plugin.settings;c.addClass('br-shelf-dialog');
  c.createEl('h2',{text:t('Add to bookshelves')});
  c.createEl('p',{text:t('A book can belong to several shelves. Uncheck a shelf to remove membership; the book file stays in place.')});
  const changes=new Map(),names=new Set(libraryTags(s));
  const list=c.createDiv('br-membership-list');
  const draw=()=>{list.empty();
   if(!names.size)list.createEl('p',{text:t('Create your first bookshelf below.')});
   for(const name of names){
    const row=list.createEl('label',{cls:'br-membership-row'});
    const box=row.createEl('input',{attr:{type:'checkbox'}});
    const count=this.paths.filter(path=>tagsFor(s,path).includes(name)).length;
    box.checked=changes.has(name)?changes.get(name):count===this.paths.length;
    box.indeterminate=!changes.has(name)&&count>0&&count<this.paths.length;
    row.createSpan({text:name});
    box.onchange=()=>{changes.set(name,box.checked);box.indeterminate=false;};
   }
  };draw();
  const form=c.createEl('form',{cls:'br-tag-create'});
  const input=form.createEl('input',{attr:{placeholder:t('New collection'),'aria-label':t('New collection')}});
  form.createEl('button',{text:t('Create and select'),attr:{type:'submit'}});
  form.onsubmit=e=>{e.preventDefault();const parsed=parseTags(input.value);
   if(parsed.length!==1){new Notice(t('Enter one collection name'));return;}
   names.add(parsed[0]);changes.set(parsed[0],true);input.value='';draw();
  };
  new Setting(c).addButton(b=>b.setButtonText(t('Cancel')).onClick(()=>this.close())).addButton(b=>b.setButtonText(t('Save')).setCta().onClick(async()=>{
   const oldTags=JSON.parse(JSON.stringify(s.bookTags||{})),oldNames=[...(s.libraryTagNames||[])];
   b.setDisabled(true);
   try{setCollectionMembership(s,this.paths,changes);await this.view.plugin._saveLocalData();this.close();this.view._refresh();}
   catch(e){s.bookTags=oldTags;s.libraryTagNames=oldNames;new Notice(t('Error: {0}',e.message));b.setDisabled(false);}
  }));
 }
 onClose(){this.contentEl.empty();}
}
